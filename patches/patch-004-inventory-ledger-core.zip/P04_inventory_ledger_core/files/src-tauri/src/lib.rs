mod commands;
mod core;
mod domain;

pub fn run() {
    tauri::Builder::default()
        .setup(|app| {
            let handle = app.handle().clone();
            core::db::initialize(&handle).expect("failed to initialize local workspace core");
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::bootstrap::bootstrap_app,
            commands::business::save_business_profile,
            commands::business::create_business_workspace,
            commands::business::switch_active_business,
            commands::settings::save_workspace_configuration,
            commands::catalog::load_catalog_workspace,
            commands::catalog::save_catalog_category,
            commands::catalog::save_catalog_unit,
            commands::catalog::save_catalog_item,
            commands::catalog::set_catalog_item_archived,
            commands::inventory::load_inventory_workspace,
            commands::inventory::record_inventory_movement,
            commands::inventory::save_inventory_stock_rule,
            commands::data_center::create_backup_snapshot,
            commands::data_center::export_foundation_snapshot,
            commands::data_center::preview_import_bundle
        ])
        .run(tauri::generate_context!())
        .expect("error while running local business manager");
}
