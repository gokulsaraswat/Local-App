# Rollback Notes

This patch does not change the database schema, so rollback is file-based.

## Recommended rollback

1. restore your project from source control, or
2. restore overwritten files from:

```text
.patch-backups/P006_dashboard_daily_ops_mvp/
```

## Notes

- no SQL rollback is required
- no table/data migration rollback is required
- if you created new backups or exports while testing Patch 6, those local artifacts remain on disk unless you remove them manually
