import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
let ts = null;
try {
  ts = require("typescript");
} catch {
  ts = null;
}

const requiredFiles = [
  "package.json",
  "src/shared/types.ts",
  "src/modules/dashboard/DashboardPage.tsx",
  "src/modules/shell/AppShell.tsx",
  "src-tauri/src/core/dashboard.rs",
  "src-tauri/src/domain/bootstrap.rs",
  "src-tauri/src/core/patching.rs"
];

const requiredSnippets = [
  ["package.json", '"validate:patch6": "node scripts/validate-patch6.mjs"'],
  ["src/shared/types.ts", "export interface DashboardDailySummary"],
  ["src/shared/types.ts", "export interface DashboardRecentTransaction"],
  ["src/shared/types.ts", "export interface DashboardLowStockAlert"],
  ["src/modules/dashboard/DashboardPage.tsx", "Patch 6 daily ops MVP"],
  ["src/modules/dashboard/DashboardPage.tsx", "Quick actions"],
  ["src/modules/dashboard/DashboardPage.tsx", "Recent transactions"],
  ["src/modules/dashboard/DashboardPage.tsx", "Low-stock alerts"],
  ["src/modules/shell/AppShell.tsx", "Daily ops MVP ready"],
  ["src-tauri/src/core/dashboard.rs", "build_ops_snapshot"],
  ["src-tauri/src/core/dashboard.rs", "list_recent_transactions"],
  ["src-tauri/src/commands/bootstrap.rs", "dashboard::build_daily_summary"],
  ["src-tauri/src/core/patching.rs", "P006_dashboard_daily_ops_mvp"],
  ["src-tauri/src/core/patching.rs", 'APP_VERSION: &str = "0.6.0"'],
  ["src-tauri/src/core/migrations.rs", "CURRENT_SCHEMA_VERSION: i64 = 5"]
];

let hasError = false;

for (const relativePath of requiredFiles) {
  const fullPath = path.resolve(relativePath);
  if (!fs.existsSync(fullPath)) {
    console.error(`[ERROR] Missing required file: ${relativePath}`);
    hasError = true;
  }
}

for (const [relativePath, snippet] of requiredSnippets) {
  const fullPath = path.resolve(relativePath);
  if (!fs.existsSync(fullPath)) continue;
  const contents = fs.readFileSync(fullPath, "utf8");
  if (!contents.includes(snippet)) {
    console.error(`[ERROR] Expected snippet not found in ${relativePath}: ${snippet}`);
    hasError = true;
  }
}

for (const relativePath of ["package.json", "src-tauri/tauri.conf.json"]) {
  try {
    JSON.parse(fs.readFileSync(path.resolve(relativePath), "utf8"));
  } catch (error) {
    hasError = true;
    console.error(
      `[ERROR] Invalid JSON in ${relativePath}: ${error instanceof Error ? error.message : String(error)}`
    );
  }
}

function walk(dir) {
  const output = [];
  if (!fs.existsSync(dir)) return output;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      output.push(...walk(fullPath));
      continue;
    }
    if (/\.(ts|tsx)$/.test(entry.name)) {
      output.push(fullPath);
    }
  }
  return output;
}

if (ts) {
  for (const fullPath of walk(path.resolve("src"))) {
    const source = fs.readFileSync(fullPath, "utf8");
    const scriptKind = fullPath.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
    const sourceFile = ts.createSourceFile(
      fullPath,
      source,
      ts.ScriptTarget.Latest,
      true,
      scriptKind
    );
    if (sourceFile.parseDiagnostics.length > 0) {
      hasError = true;
      console.error(`[ERROR] TypeScript parse diagnostics in ${path.relative(process.cwd(), fullPath)}`);
      for (const diagnostic of sourceFile.parseDiagnostics) {
        console.error(ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n"));
      }
    }
  }
} else {
  console.warn("[WARN] typescript module not installed; skipping TS parse diagnostics.");
}

if (hasError) {
  process.exit(1);
}

console.log("[OK] Patch 6 structural validation passed.");
