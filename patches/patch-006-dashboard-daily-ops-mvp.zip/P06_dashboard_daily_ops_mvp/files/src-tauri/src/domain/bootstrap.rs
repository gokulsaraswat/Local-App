use super::models::{
    AppBootstrap, AppInfo, BackupRecord, BusinessProfile, BusinessSettings,
    BusinessWorkspaceSummary, CatalogSummary, DashboardDailySummary, DashboardLowStockAlert,
    DashboardOpsSnapshot, DashboardRecentTransaction, DashboardShellData, InventorySummary,
    KpiCard, ModuleFlags, ModuleStatus, PatchRecord, PosSummary, ReceiptProfile, RecentActivity,
    SequenceCounter, StorageStatus, TaxProfile,
};

fn active_module_count(module_flags: &ModuleFlags) -> usize {
    [
        module_flags.restaurant_enabled,
        module_flags.retail_enabled,
        module_flags.inventory_enabled,
        module_flags.services_enabled,
        module_flags.customers_enabled,
        module_flags.suppliers_enabled,
        module_flags.expenses_enabled,
        module_flags.reporting_enabled,
        module_flags.data_center_enabled,
    ]
    .into_iter()
    .filter(|enabled| *enabled)
    .count()
}

#[allow(clippy::too_many_arguments)]
pub fn compose_dashboard(
    business_workspaces: &[BusinessWorkspaceSummary],
    active_business: &BusinessProfile,
    active_modules: &ModuleFlags,
    active_sequences: &[SequenceCounter],
    backups: &[BackupRecord],
    recent_activity: Vec<RecentActivity>,
    patch_history: &[PatchRecord],
    storage: &StorageStatus,
    catalog_summary: &CatalogSummary,
    inventory_summary: &InventorySummary,
    pos_summary: &PosSummary,
    daily_summary: DashboardDailySummary,
    recent_transactions: Vec<DashboardRecentTransaction>,
    low_stock_alerts: Vec<DashboardLowStockAlert>,
    ops_snapshot: DashboardOpsSnapshot,
) -> DashboardShellData {
    DashboardShellData {
        hero_title: "Daily operations dashboard is ready".into(),
        hero_body: format!(
            "Patch 6 turns the local foundation into a practical daily workspace for {} with today’s sales pulse, recent transactions, low-stock watchlists, due tracking, and quick actions for checkout, stock updates, backup, and export.",
            active_business.name
        ),
        kpis: vec![
            KpiCard {
                id: "workspace-count".into(),
                label: "Business workspaces".into(),
                value: business_workspaces.len().to_string(),
                note: "Each business keeps isolated profiles, settings, sequences, and local data boundaries.".into(),
            },
            KpiCard {
                id: "catalog-items".into(),
                label: "Active catalog items".into(),
                value: catalog_summary.active_items.to_string(),
                note: format!(
                    "{} categories support menu, stock, and service records inside the local catalog.",
                    catalog_summary.category_count
                ),
            },
            KpiCard {
                id: "tracked-stock".into(),
                label: "Tracked stock items".into(),
                value: inventory_summary.total_tracked_items.to_string(),
                note: format!(
                    "{} items are currently at or below reorder level.",
                    inventory_summary.low_stock_items
                ),
            },
            KpiCard {
                id: "inventory-movements".into(),
                label: "Inventory movements".into(),
                value: inventory_summary.movement_count.to_string(),
                note: "Opening balances, manual adjustments, and POS deductions share one movement ledger.".into(),
            },
            KpiCard {
                id: "completed-sales".into(),
                label: "Completed sales".into(),
                value: pos_summary.completed_sale_count.to_string(),
                note: format!(
                    "{} held carts remain available to resume locally.",
                    pos_summary.held_sale_count
                ),
            },
            KpiCard {
                id: "average-sale-value".into(),
                label: "Average sale value".into(),
                value: format!("{} {:.2}", active_business.currency_code, pos_summary.average_sale_value),
                note: "Useful for monitoring bill size before customer profiles and advanced reports arrive.".into(),
            },
            KpiCard {
                id: "module-count".into(),
                label: "Active modules".into(),
                value: active_module_count(active_modules).to_string(),
                note: "Workspace, catalog, inventory, POS, dashboard, and data-center foundations are active offline.".into(),
            },
            KpiCard {
                id: "backup-count".into(),
                label: "Local backups".into(),
                value: backups.len().to_string(),
                note: format!(
                    "{} export bundles are recorded under {}.",
                    storage.export_count, storage.export_dir
                ),
            },
            KpiCard {
                id: "sequence-count".into(),
                label: "Sequence counters".into(),
                value: active_sequences.len().to_string(),
                note: "Sale and hold numbering are ready for future purchasing, returns, and customer-linked flows.".into(),
            },
            KpiCard {
                id: "patch-count".into(),
                label: "Applied patches".into(),
                value: patch_history.len().to_string(),
                note: "Patch history stays in the local database for upgrade traceability and rollback planning.".into(),
            },
        ],
        recent_activity,
        module_statuses: vec![
            ModuleStatus {
                id: "workspace".into(),
                label: "Workspace core".into(),
                status: "active-foundation".into(),
                note: "Multi-business profiles, settings, tax defaults, receipts, and sequence counters remain active.".into(),
            },
            ModuleStatus {
                id: "catalog".into(),
                label: "Catalog".into(),
                status: "active-foundation".into(),
                note: "Products, menu items, services, categories, units, and barcodes are available locally.".into(),
            },
            ModuleStatus {
                id: "inventory".into(),
                label: "Inventory ledger".into(),
                status: "active-foundation".into(),
                note: "Stock movements, on-hand balances, reorder alerts, and POS deductions are tracked per business.".into(),
            },
            ModuleStatus {
                id: "pos".into(),
                label: "POS / billing".into(),
                status: "active-foundation".into(),
                note: "Cart building, held carts, sale completion, payment capture, receipt rendering, and recent sale history are available offline.".into(),
            },
            ModuleStatus {
                id: "dashboard".into(),
                label: "Daily ops dashboard".into(),
                status: "active-foundation".into(),
                note: "Today’s sales pulse, low-stock watchlists, pending dues, and backup visibility now sit in one home screen.".into(),
            },
            ModuleStatus {
                id: "customers".into(),
                label: "Customers".into(),
                status: "coming-next".into(),
                note: "The next patch can add customer profiles, sale linking, notes, and repeat-buyer support on top of the current POS workflow.".into(),
            },
        ],
        daily_summary,
        recent_transactions,
        low_stock_alerts,
        ops_snapshot,
    }
}

#[allow(clippy::too_many_arguments)]
pub fn build_app_bootstrap(
    app_info: AppInfo,
    active_business: BusinessProfile,
    business_settings: BusinessSettings,
    active_tax_profile: TaxProfile,
    active_receipt_profile: ReceiptProfile,
    active_module_flags: ModuleFlags,
    active_sequences: Vec<SequenceCounter>,
    businesses: Vec<BusinessProfile>,
    business_workspaces: Vec<BusinessWorkspaceSummary>,
    patch_history: Vec<PatchRecord>,
    backups: Vec<BackupRecord>,
    storage: StorageStatus,
    recent_activity: Vec<RecentActivity>,
    catalog_summary: CatalogSummary,
    inventory_summary: InventorySummary,
    pos_summary: PosSummary,
    dashboard_daily_summary: DashboardDailySummary,
    dashboard_recent_transactions: Vec<DashboardRecentTransaction>,
    dashboard_low_stock_alerts: Vec<DashboardLowStockAlert>,
    dashboard_ops_snapshot: DashboardOpsSnapshot,
) -> AppBootstrap {
    let dashboard = compose_dashboard(
        &business_workspaces,
        &active_business,
        &active_module_flags,
        &active_sequences,
        &backups,
        recent_activity,
        &patch_history,
        &storage,
        &catalog_summary,
        &inventory_summary,
        &pos_summary,
        dashboard_daily_summary,
        dashboard_recent_transactions,
        dashboard_low_stock_alerts,
        dashboard_ops_snapshot,
    );

    AppBootstrap {
        app_info,
        active_business,
        business_settings,
        active_tax_profile,
        active_receipt_profile,
        active_module_flags,
        active_sequences,
        businesses,
        business_workspaces,
        patch_history,
        backups,
        storage,
        catalog_summary,
        inventory_summary,
        pos_summary,
        dashboard,
    }
}
