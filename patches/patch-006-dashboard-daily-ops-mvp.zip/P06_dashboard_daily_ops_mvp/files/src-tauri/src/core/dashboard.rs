use rusqlite::{params, Connection, OptionalExtension, Row};

use crate::domain::models::{
    CatalogSummary, DashboardDailySummary, DashboardLowStockAlert, DashboardOpsSnapshot,
    DashboardRecentTransaction, InventorySummary, PosSummary,
};

use super::error::to_command_error;

fn recent_transaction_from_row(row: &Row) -> rusqlite::Result<DashboardRecentTransaction> {
    Ok(DashboardRecentTransaction {
        sale_id: row.get(0)?,
        sale_number: row.get(1)?,
        payment_status: row.get(2)?,
        total_amount: row.get(3)?,
        amount_paid: row.get(4)?,
        balance_due: row.get(5)?,
        item_count: row.get::<_, i64>(6)? as usize,
        completed_at: row.get(7)?,
    })
}

fn low_stock_alert_from_row(row: &Row) -> rusqlite::Result<DashboardLowStockAlert> {
    let stock_quantity: f64 = row.get(5)?;
    let reorder_level: f64 = row.get(6)?;
    Ok(DashboardLowStockAlert {
        item_id: row.get(0)?,
        item_name: row.get(1)?,
        sku: row.get(2)?,
        category_name: row.get(3)?,
        unit_code: row.get(4)?,
        stock_quantity,
        reorder_level,
        shortage_quantity: (reorder_level - stock_quantity).max(0.0),
        updated_at: row.get(7)?,
    })
}

pub fn build_daily_summary(
    catalog_summary: &CatalogSummary,
    inventory_summary: &InventorySummary,
    pos_summary: &PosSummary,
) -> DashboardDailySummary {
    DashboardDailySummary {
        today_sale_count: pos_summary.today_sale_count,
        today_gross_sales: pos_summary.today_gross_sales,
        today_collected_amount: pos_summary.today_collected_amount,
        today_due_amount: pos_summary.today_due_amount,
        held_sale_count: pos_summary.held_sale_count,
        low_stock_count: inventory_summary.low_stock_items,
        average_sale_value: pos_summary.average_sale_value,
        total_tracked_items: inventory_summary.total_tracked_items,
        active_catalog_items: catalog_summary.active_items,
    }
}

pub fn list_recent_transactions(
    conn: &Connection,
    business_id: &str,
    limit: usize,
) -> Result<Vec<DashboardRecentTransaction>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, sale_number, payment_status, total_amount, amount_paid, balance_due, item_count, completed_at
             FROM sales
             WHERE business_id = ?1
               AND sale_status = 'completed'
             ORDER BY completed_at DESC, created_at DESC
             LIMIT ?2",
        )
        .map_err(|error| to_command_error("failed to prepare recent transaction query", error))?;

    let rows = stmt
        .query_map(params![business_id, limit as i64], recent_transaction_from_row)
        .map_err(|error| to_command_error("failed to query recent transactions", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map recent transactions", error))
}

pub fn list_low_stock_alerts(
    conn: &Connection,
    business_id: &str,
    limit: usize,
) -> Result<Vec<DashboardLowStockAlert>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT
                i.id,
                i.name,
                i.sku,
                c.name,
                u.code,
                i.stock_quantity,
                i.reorder_level,
                i.updated_at
             FROM catalog_items i
             LEFT JOIN catalog_categories c ON c.id = i.category_id
             LEFT JOIN catalog_units u ON u.id = i.unit_id
             WHERE i.business_id = ?1
               AND i.archived_at IS NULL
               AND i.item_kind = 'stock'
               AND i.track_stock = 1
               AND i.reorder_level > 0
               AND i.stock_quantity <= i.reorder_level
             ORDER BY
                (i.reorder_level - i.stock_quantity) DESC,
                i.updated_at DESC,
                i.name COLLATE NOCASE ASC
             LIMIT ?2",
        )
        .map_err(|error| to_command_error("failed to prepare low stock alert query", error))?;

    let rows = stmt
        .query_map(params![business_id, limit as i64], low_stock_alert_from_row)
        .map_err(|error| to_command_error("failed to query low stock alerts", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map low stock alerts", error))
}

pub fn build_ops_snapshot(
    conn: &Connection,
    business_id: &str,
) -> Result<DashboardOpsSnapshot, String> {
    let (open_due_sale_count, open_due_amount): (usize, f64) = conn
        .query_row(
            "SELECT COUNT(*), COALESCE(SUM(balance_due), 0)
             FROM sales
             WHERE business_id = ?1
               AND sale_status = 'completed'
               AND balance_due > 0.000001",
            params![business_id],
            |row| Ok((row.get::<_, i64>(0)? as usize, row.get(1)?)),
        )
        .map_err(|error| to_command_error("failed to summarize open dues", error))?;

    let backup_count: usize = conn
        .query_row("SELECT COUNT(*) FROM backup_records", [], |row| {
            row.get::<_, i64>(0)
        })
        .map_err(|error| to_command_error("failed to count backups", error))?
        as usize;

    let export_count: usize = conn
        .query_row("SELECT COUNT(*) FROM export_jobs", [], |row| row.get::<_, i64>(0))
        .map_err(|error| to_command_error("failed to count exports", error))?
        as usize;

    let last_backup_at = conn
        .query_row(
            "SELECT created_at FROM backup_records ORDER BY created_at DESC LIMIT 1",
            [],
            |row| row.get::<_, String>(0),
        )
        .optional()
        .map_err(|error| to_command_error("failed to load last backup timestamp", error))?;

    let last_export_at = conn
        .query_row(
            "SELECT COALESCE(completed_at, created_at) FROM export_jobs ORDER BY COALESCE(completed_at, created_at) DESC LIMIT 1",
            [],
            |row| row.get::<_, String>(0),
        )
        .optional()
        .map_err(|error| to_command_error("failed to load last export timestamp", error))?;

    let last_sale_at = conn
        .query_row(
            "SELECT completed_at
             FROM sales
             WHERE business_id = ?1
               AND sale_status = 'completed'
             ORDER BY completed_at DESC, created_at DESC
             LIMIT 1",
            params![business_id],
            |row| row.get::<_, String>(0),
        )
        .optional()
        .map_err(|error| to_command_error("failed to load last sale timestamp", error))?;

    Ok(DashboardOpsSnapshot {
        open_due_sale_count,
        open_due_amount,
        backup_count,
        export_count,
        last_backup_at,
        last_export_at,
        last_sale_at,
    })
}
