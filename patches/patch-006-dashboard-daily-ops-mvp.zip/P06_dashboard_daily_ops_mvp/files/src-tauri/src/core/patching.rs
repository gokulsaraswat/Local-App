use chrono::Utc;
use rusqlite::{params, Connection};
use serde_json::json;

use super::migrations::CURRENT_SCHEMA_VERSION;

struct PatchDefinition {
    patch_id: &'static str,
    patch_name: &'static str,
    schema_version: i64,
    notes: &'static str,
}

const PATCHES: [PatchDefinition; 6] = [
    PatchDefinition {
        patch_id: "P001_foundation_base_structure",
        patch_name: "Foundation Base Structure",
        schema_version: 1,
        notes: "Initial desktop foundation with local storage, business/settings shell, backup/export foundation.",
    },
    PatchDefinition {
        patch_id: "P002_multi_business_workspace_settings_core",
        patch_name: "Multi-Business Workspace & Settings Core",
        schema_version: 2,
        notes: "Adds multi-business switching, business-scoped settings profiles, normalized module flags, receipt profiles, tax profiles, and sequence counters.",
    },
    PatchDefinition {
        patch_id: "P003_catalog_core",
        patch_name: "Catalog Core",
        schema_version: 3,
        notes: "Adds categories, units, item master data, barcode foundations, and catalog-aware export scope for local businesses.",
    },
    PatchDefinition {
        patch_id: "P004_inventory_ledger_core",
        patch_name: "Inventory Ledger Core",
        schema_version: 4,
        notes: "Adds stock movement history, on-hand stock balances, reorder monitoring, and inventory-aware export data.",
    },
    PatchDefinition {
        patch_id: "P005_pos_checkout_core",
        patch_name: "POS Checkout Core",
        schema_version: 5,
        notes: "Adds local checkout with held carts, completed sales, payment capture, receipt-ready sale history, and stock deduction through the existing inventory ledger.",
    },
    PatchDefinition {
        patch_id: "P006_dashboard_daily_ops_mvp",
        patch_name: "Dashboard & Daily Ops MVP",
        schema_version: 5,
        notes: "Elevates the home screen into a daily operations workspace with today’s sales pulse, quick actions, recent transactions, low-stock watchlists, due tracking, and backup/export visibility.",
    },
];

pub const PATCH_ID: &str = "P006_dashboard_daily_ops_mvp";
pub const PATCH_NAME: &str = "Dashboard & Daily Ops MVP";
pub const APP_VERSION: &str = "0.6.0";

pub fn register_patch(conn: &Connection) -> rusqlite::Result<()> {
    for patch in PATCHES {
        let now = Utc::now().to_rfc3339();
        let manifest = json!({
            "patch_id": patch.patch_id,
            "patch_name": patch.patch_name,
            "schema_version": patch.schema_version,
            "applied_at": now.clone(),
            "notes": patch.notes,
        });

        conn.execute(
            "INSERT OR IGNORE INTO patch_history (patch_id, patch_name, schema_version, applied_at, manifest_json)
             VALUES (?1, ?2, ?3, ?4, ?5)",
            params![
                patch.patch_id,
                patch.patch_name,
                patch.schema_version,
                now,
                manifest.to_string()
            ],
        )?;
    }

    let now = Utc::now().to_rfc3339();

    conn.execute(
        "INSERT INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        params![
            "schema_version",
            CURRENT_SCHEMA_VERSION.to_string(),
            now.clone()
        ],
    )?;

    conn.execute(
        "INSERT INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        params!["patch_level", PATCH_ID, now.clone()],
    )?;

    conn.execute(
        "INSERT INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        params!["app_version", APP_VERSION, now],
    )?;

    Ok(())
}
