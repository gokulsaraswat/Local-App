use tauri::AppHandle;

use crate::{
    core::{catalog, dashboard, db, error::CommandResult, inventory, pos},
    domain::bootstrap::build_app_bootstrap,
};

#[tauri::command]
pub fn bootstrap_app(app: AppHandle) -> CommandResult<crate::domain::models::AppBootstrap> {
    db::with_connection(&app, |conn, paths| {
        let app_info = db::load_app_info(conn)?;
        let active_business = db::get_active_business(conn)?;
        let business_settings = db::get_business_settings(conn, &active_business.id)?;
        let active_tax_profile = db::get_default_tax_profile(conn, &active_business.id)?;
        let active_receipt_profile = db::get_default_receipt_profile(conn, &active_business.id)?;
        let active_module_flags = db::get_module_flags(conn, &active_business.id)?;
        let active_sequences = db::list_sequence_counters(conn, &active_business.id)?;
        let businesses = db::list_businesses(conn)?;
        let business_workspaces = db::list_business_workspace_summaries(conn)?;
        let patch_history = db::list_patch_history(conn)?;
        let backups = db::list_backups(conn)?;
        let storage = db::build_storage_status(conn, paths)?;
        let recent_activity = db::list_recent_activity(conn, 10)?;
        let catalog_summary = catalog::build_catalog_summary(conn, &active_business.id)?;
        let inventory_summary = inventory::build_inventory_summary(conn, &active_business.id)?;
        let pos_summary = pos::build_pos_summary(conn, &active_business.id)?;
        let dashboard_daily_summary =
            dashboard::build_daily_summary(&catalog_summary, &inventory_summary, &pos_summary);
        let dashboard_recent_transactions =
            dashboard::list_recent_transactions(conn, &active_business.id, 8)?;
        let dashboard_low_stock_alerts =
            dashboard::list_low_stock_alerts(conn, &active_business.id, 8)?;
        let dashboard_ops_snapshot = dashboard::build_ops_snapshot(conn, &active_business.id)?;

        Ok(build_app_bootstrap(
            app_info,
            active_business,
            business_settings,
            active_tax_profile,
            active_receipt_profile,
            active_module_flags,
            active_sequences,
            businesses,
            business_workspaces,
            patch_history,
            backups,
            storage,
            recent_activity,
            catalog_summary,
            inventory_summary,
            pos_summary,
            dashboard_daily_summary,
            dashboard_recent_transactions,
            dashboard_low_stock_alerts,
            dashboard_ops_snapshot,
        ))
    })
}
