import { useState } from "react";
import { useAppState } from "../../app/AppProvider";
import type { NavPage } from "../../shared/types";
import {
  classNames,
  formatCurrency,
  formatDateTime,
  formatModuleList,
  formatQuantity,
  titleCaseWords
} from "../../shared/utils";

interface DashboardPageProps {
  onNavigate: (page: NavPage) => void;
}

type QuickActionDefinition = {
  id: string;
  label: string;
  note: string;
  buttonLabel: string;
  tone: "primary" | "secondary";
  run: () => Promise<void>;
};

function paymentStatusTone(value: string): "success" | "warning" | "neutral" {
  const normalized = value.trim().toLowerCase();
  if (normalized === "paid") return "success";
  if (normalized === "partial" || normalized === "due") return "warning";
  return "neutral";
}

export function DashboardPage({ onNavigate }: DashboardPageProps) {
  const { data, createBackup, exportFoundation } = useAppState();
  const [actionStatus, setActionStatus] = useState("");
  const [busyActionId, setBusyActionId] = useState<string | null>(null);

  if (!data) return null;

  const quickActions: QuickActionDefinition[] = [
    {
      id: "open-pos",
      label: "Start checkout",
      note: "Open the POS workspace to create a bill, resume a held cart, or print the latest receipt.",
      buttonLabel: "Open POS",
      tone: "primary",
      run: async () => onNavigate("pos")
    },
    {
      id: "open-inventory",
      label: "Record stock movement",
      note: "Jump to the inventory ledger to record stock in, stock out, or a manual adjustment.",
      buttonLabel: "Open Inventory",
      tone: "secondary",
      run: async () => onNavigate("inventory")
    },
    {
      id: "open-catalog",
      label: "Review catalog",
      note: "Open the catalog workspace to add an item, adjust prices, or archive unused products.",
      buttonLabel: "Open Catalog",
      tone: "secondary",
      run: async () => onNavigate("catalog")
    },
    {
      id: "create-backup",
      label: "Create backup snapshot",
      note: "Write a local backup snapshot immediately before making larger business changes.",
      buttonLabel: "Create Backup",
      tone: "secondary",
      run: async () => {
        setActionStatus("Creating local backup snapshot…");
        const backup = await createBackup();
        setActionStatus(`Backup created: ${backup.fileName}`);
      }
    },
    {
      id: "export-foundation",
      label: "Export workspace bundle",
      note: "Write a local export bundle for transfer, preview, restore preparation, or machine migration.",
      buttonLabel: "Export Bundle",
      tone: "secondary",
      run: async () => {
        setActionStatus("Exporting local workspace bundle…");
        const targetPath = await exportFoundation();
        setActionStatus(`Export written to: ${targetPath}`);
      }
    },
    {
      id: "open-settings",
      label: "Review workspace settings",
      note: "Open settings to adjust tax defaults, receipt options, themes, and enabled modules.",
      buttonLabel: "Open Settings",
      tone: "secondary",
      run: async () => onNavigate("settings")
    }
  ];

  async function handleQuickAction(action: QuickActionDefinition) {
    setBusyActionId(action.id);
    try {
      await action.run();
      if (action.id.startsWith("open-")) {
        setActionStatus(`${action.label} ready.`);
      }
    } catch (error) {
      setActionStatus(
        error instanceof Error ? error.message : "Quick action failed."
      );
    } finally {
      setBusyActionId(null);
    }
  }

  const currencyCode = data.activeBusiness.currencyCode;

  return (
    <div className="page-grid">
      <section className="hero-card">
        <div>
          <div className="section-kicker">Patch 6 daily ops MVP</div>
          <h2>{data.dashboard.heroTitle}</h2>
          <p>{data.dashboard.heroBody}</p>
        </div>
        <div className="hero-actions">
          <button
            className="primary-button"
            type="button"
            onClick={() => onNavigate("pos")}
          >
            Open POS
          </button>
          <button
            className="secondary-button"
            type="button"
            onClick={() => onNavigate("inventory")}
          >
            Open Inventory
          </button>
          <button
            className="secondary-button"
            type="button"
            onClick={() => onNavigate("data-center")}
          >
            Open Data Center
          </button>
        </div>
      </section>

      <section className="dashboard-summary-grid">
        <div className="summary-chip">
          <strong>{data.dashboard.dailySummary.todaySaleCount}</strong>
          <span>Sales today</span>
        </div>
        <div className="summary-chip">
          <strong>
            {formatCurrency(data.dashboard.dailySummary.todayGrossSales, currencyCode)}
          </strong>
          <span>Gross today</span>
        </div>
        <div className="summary-chip">
          <strong>
            {formatCurrency(data.dashboard.dailySummary.todayCollectedAmount, currencyCode)}
          </strong>
          <span>Collected today</span>
        </div>
        <div className="summary-chip">
          <strong>
            {formatCurrency(data.dashboard.dailySummary.todayDueAmount, currencyCode)}
          </strong>
          <span>Due today</span>
        </div>
        <div className="summary-chip">
          <strong>{data.dashboard.dailySummary.heldSaleCount}</strong>
          <span>Held carts</span>
        </div>
        <div className="summary-chip">
          <strong>{data.dashboard.dailySummary.lowStockCount}</strong>
          <span>Low-stock alerts</span>
        </div>
        <div className="summary-chip">
          <strong>
            {formatCurrency(data.dashboard.dailySummary.averageSaleValue, currencyCode)}
          </strong>
          <span>Average sale value</span>
        </div>
        <div className="summary-chip">
          <strong>{data.dashboard.dailySummary.activeCatalogItems}</strong>
          <span>Active catalog items</span>
        </div>
      </section>

      <section className="split-grid dashboard-primary-grid">
        <article className="card">
          <div className="card-header">
            <h3>Quick actions</h3>
            <span className="pill success">Daily use</span>
          </div>
          <p className="card-note">
            Common local actions are kept one click away so staff can move between
            checkout, stock updates, backup, and export without hunting through the shell.
          </p>
          <div className="dashboard-actions-grid">
            {quickActions.map((action) => (
              <div className="dashboard-action-card" key={action.id}>
                <strong>{action.label}</strong>
                <p className="card-note">{action.note}</p>
                <button
                  className={action.tone === "primary" ? "primary-button" : "secondary-button"}
                  type="button"
                  disabled={busyActionId === action.id}
                  onClick={() => void handleQuickAction(action)}
                >
                  {busyActionId === action.id ? "Working…" : action.buttonLabel}
                </button>
              </div>
            ))}
          </div>
          <div className="status-banner">{actionStatus || "No quick action run yet."}</div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Operations watch</h3>
            <span
              className={classNames(
                "pill",
                data.dashboard.opsSnapshot.openDueSaleCount > 0 ? "warning" : "success"
              )}
            >
              {data.dashboard.opsSnapshot.openDueSaleCount > 0 ? "Needs follow-up" : "In good shape"}
            </span>
          </div>
          <div className="dashboard-watch-grid">
            <div className="dashboard-watch-card">
              <span>Open dues across sales</span>
              <strong>
                {formatCurrency(data.dashboard.opsSnapshot.openDueAmount, currencyCode)}
              </strong>
              <small>
                {data.dashboard.opsSnapshot.openDueSaleCount} completed sale
                {data.dashboard.opsSnapshot.openDueSaleCount === 1 ? "" : "s"} still have a balance due.
              </small>
            </div>
            <div className="dashboard-watch-card">
              <span>Latest backup</span>
              <strong>
                {data.dashboard.opsSnapshot.lastBackupAt
                  ? formatDateTime(data.dashboard.opsSnapshot.lastBackupAt)
                  : "None yet"}
              </strong>
              <small>
                {data.dashboard.opsSnapshot.backupCount} snapshot
                {data.dashboard.opsSnapshot.backupCount === 1 ? "" : "s"} recorded in local storage.
              </small>
            </div>
            <div className="dashboard-watch-card">
              <span>Latest export bundle</span>
              <strong>
                {data.dashboard.opsSnapshot.lastExportAt
                  ? formatDateTime(data.dashboard.opsSnapshot.lastExportAt)
                  : "None yet"}
              </strong>
              <small>
                {data.dashboard.opsSnapshot.exportCount} export job
                {data.dashboard.opsSnapshot.exportCount === 1 ? "" : "s"} logged for transfer or restore prep.
              </small>
            </div>
            <div className="dashboard-watch-card">
              <span>Most recent sale</span>
              <strong>
                {data.dashboard.opsSnapshot.lastSaleAt
                  ? formatDateTime(data.dashboard.opsSnapshot.lastSaleAt)
                  : "No completed sales yet"}
              </strong>
              <small>
                {data.dashboard.dailySummary.totalTrackedItems} tracked stock item
                {data.dashboard.dailySummary.totalTrackedItems === 1 ? "" : "s"} remain under inventory monitoring.
              </small>
            </div>
          </div>
        </article>
      </section>

      <section className="card">
        <div className="card-header">
          <h3>Business KPIs</h3>
          <span className="pill neutral">Operational pulse</span>
        </div>
        <div className="card-grid card-grid-5">
          {data.dashboard.kpis.map((kpi) => (
            <article className="card dashboard-kpi-card" key={kpi.id}>
              <div className="card-label">{kpi.label}</div>
              <div className="kpi-value">{kpi.value}</div>
              <p className="card-note">{kpi.note}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="split-grid dashboard-secondary-grid">
        <article className="card">
          <div className="card-header">
            <h3>Recent transactions</h3>
            <span className="pill neutral">
              {data.dashboard.recentTransactions.length} recent
            </span>
          </div>
          <div className="stack-list">
            {data.dashboard.recentTransactions.length > 0 ? (
              data.dashboard.recentTransactions.map((sale) => (
                <div className="list-row dashboard-transaction-row" key={sale.saleId}>
                  <div>
                    <div className="dashboard-transaction-title-row">
                      <strong>{sale.saleNumber}</strong>
                      <span className={`pill ${paymentStatusTone(sale.paymentStatus)}`}>
                        {titleCaseWords(sale.paymentStatus)}
                      </span>
                    </div>
                    <div className="muted-text">
                      {sale.itemCount} item{sale.itemCount === 1 ? "" : "s"} · paid {formatCurrency(sale.amountPaid, currencyCode)} · due {formatCurrency(sale.balanceDue, currencyCode)}
                    </div>
                  </div>
                  <div className="dashboard-transaction-meta">
                    <strong>{formatCurrency(sale.totalAmount, currencyCode)}</strong>
                    <span className="muted-text">{formatDateTime(sale.completedAt)}</span>
                  </div>
                </div>
              ))
            ) : (
              <p className="muted-text">
                No completed sales have been recorded yet. Use the POS workspace to create the first sale.
              </p>
            )}
          </div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Low-stock alerts</h3>
            <span
              className={classNames(
                "pill",
                data.dashboard.lowStockAlerts.length > 0 ? "warning" : "success"
              )}
            >
              {data.dashboard.lowStockAlerts.length > 0 ? "Needs restock" : "No urgent alerts"}
            </span>
          </div>
          <div className="stack-list">
            {data.dashboard.lowStockAlerts.length > 0 ? (
              data.dashboard.lowStockAlerts.map((item) => (
                <div className="list-row dashboard-low-stock-row" key={item.itemId}>
                  <div>
                    <strong>{item.itemName}</strong>
                    <div className="muted-text">
                      {[item.categoryName, item.sku, item.unitCode].filter(Boolean).join(" · ") || "Uncategorized stock item"}
                    </div>
                  </div>
                  <div className="dashboard-transaction-meta">
                    <strong>
                      {formatQuantity(item.stockQuantity)} / {formatQuantity(item.reorderLevel)}
                    </strong>
                    <span className="muted-text">
                      Short by {formatQuantity(item.shortageQuantity)} · updated {formatDateTime(item.updatedAt)}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p className="muted-text">
                No tracked stock items are currently at or below their reorder levels.
              </p>
            )}
          </div>
        </article>
      </section>

      <section className="split-grid dashboard-secondary-grid">
        <article className="card">
          <div className="card-header">
            <h3>Business workspaces</h3>
            <span className="pill success">
              {data.businessWorkspaces.length} configured
            </span>
          </div>
          <div className="stack-list">
            {data.businessWorkspaces.map((workspace) => (
              <div className="list-row" key={workspace.businessId}>
                <div>
                  <strong>
                    {workspace.name}
                    {workspace.businessId === data.activeBusiness.id ? " · active" : ""}
                  </strong>
                  <div className="muted-text">
                    {workspace.code} · {workspace.currencyCode} · {workspace.timezone}
                  </div>
                  <div className="tag-list compact-tags">
                    {workspace.activeModules.map((module) => (
                      <span className="tag" key={`${workspace.businessId}-${module}`}>
                        {titleCaseWords(module)}
                      </span>
                    ))}
                  </div>
                </div>
                <span className="muted-text">{workspace.nextSaleSequence}</span>
              </div>
            ))}
          </div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Current business configuration</h3>
            <span className="pill neutral">{data.activeBusiness.code}</span>
          </div>
          <div className="detail-list">
            <div>
              <span>Theme</span>
              <code>{data.businessSettings.theme}</code>
            </div>
            <div>
              <span>Tax profile</span>
              <code>
                {data.activeTaxProfile.name} · {data.activeTaxProfile.taxLabel} · {data.activeTaxProfile.defaultRate}%
              </code>
            </div>
            <div>
              <span>Receipt profile</span>
              <code>
                {data.activeReceiptProfile.name} · {data.activeReceiptProfile.paperWidth}
              </code>
            </div>
            <div>
              <span>Enabled modules</span>
              <code>{formatModuleList(data.businessWorkspaces.find((workspace) => workspace.businessId === data.activeBusiness.id)?.activeModules ?? [])}</code>
            </div>
            <div>
              <span>Next sale number</span>
              <code>{data.businessWorkspaces.find((workspace) => workspace.businessId === data.activeBusiness.id)?.nextSaleSequence ?? "Pending"}</code>
            </div>
            <div>
              <span>Storage</span>
              <code>{data.storage.dataDir}</code>
            </div>
          </div>
        </article>
      </section>

      <section className="split-grid dashboard-secondary-grid">
        <article className="card">
          <div className="card-header">
            <h3>Recent local activity</h3>
            <span className="pill neutral">{data.dashboard.recentActivity.length} rows</span>
          </div>
          <div className="stack-list">
            {data.dashboard.recentActivity.length > 0 ? (
              data.dashboard.recentActivity.map((activity) => (
                <div className="list-row" key={activity.id}>
                  <div>
                    <strong>
                      {activity.category} · {activity.level}
                    </strong>
                    <div className="muted-text">{activity.message}</div>
                  </div>
                  <span className="muted-text">{formatDateTime(activity.createdAt)}</span>
                </div>
              ))
            ) : (
              <p className="muted-text">No local activity has been logged yet.</p>
            )}
          </div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Module status</h3>
          </div>
          <div className="stack-list">
            {data.dashboard.moduleStatuses.map((module) => (
              <div className="list-row" key={module.id}>
                <div>
                  <strong>{module.label}</strong>
                  <div className="muted-text">{module.note}</div>
                </div>
                <span className={`pill ${module.status === "planned" ? "warning" : module.status === "coming-next" ? "warning" : "success"}`}>
                  {module.status === "coming-next"
                    ? "Coming next"
                    : titleCaseWords(module.status)}
                </span>
              </div>
            ))}
          </div>
        </article>
      </section>
    </div>
  );
}
