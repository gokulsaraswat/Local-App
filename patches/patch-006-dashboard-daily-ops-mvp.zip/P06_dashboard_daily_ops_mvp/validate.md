# Validation Checklist

- [ ] Patch applies cleanly on top of a Patch 5 project
- [ ] `npm install` completes
- [ ] `npm run validate:patch6` passes
- [ ] `npm run tauri dev` launches the desktop shell
- [ ] Dashboard shows daily summary chips
- [ ] Dashboard shows quick actions
- [ ] Dashboard shows recent transactions
- [ ] Dashboard shows low-stock alerts when applicable
- [ ] Backup quick action creates a local snapshot and refreshes the dashboard
- [ ] Export quick action creates a local bundle and refreshes the dashboard
- [ ] Sidebar and header show Patch 6 daily-ops messaging
