# Migration Notes

Patch 6 does not include a new SQL migration file.

## Database impact

- `PRAGMA user_version` stays at `5`
- no tables are added
- no columns are added
- no indexes are added

## Runtime metadata updates

On app startup after Patch 6 is applied:

- `patch_history` receives `P006_dashboard_daily_ops_mvp`
- `app_meta.patch_level` is updated to `P006_dashboard_daily_ops_mvp`
- `app_meta.app_version` is updated to `0.6.0`

## Derived dashboard data

The new dashboard views are computed from existing tables introduced in earlier patches:

- `sales`
- `sale_holds`
- `backup_records`
- `export_jobs`
- `catalog_items`
- `inventory_stock_movements`
