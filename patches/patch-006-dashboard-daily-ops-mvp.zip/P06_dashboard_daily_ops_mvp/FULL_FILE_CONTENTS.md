# FILE: PATCH-6-README.md

```
# Patch 6 - Dashboard & Daily Ops MVP

Patch ID: `P006_dashboard_daily_ops_mvp`

## Goal

Turn the existing local foundation into a more practical daily-use home workspace by improving the dashboard and surfacing operational data that a restaurant, cafe, bakery, retail store, or inventory-led business needs during routine day-to-day work.

## What this patch adds

- stronger dashboard/home workspace
- daily sales pulse cards
- recent transaction list
- low-stock alert watchlist
- open-due visibility for completed sales with outstanding balance
- quick actions for POS, inventory, catalog, settings, backup, and export
- latest backup / export / sale visibility
- updated app shell messaging for the daily operations milestone
- patch metadata bumped to Patch 6 / version 0.6.0

## What this patch does not add

- no customer module yet
- no returns/refunds yet
- no supplier or purchasing module yet
- no schema changes or new database tables
- no advanced reporting module yet

## Data model impact

This patch does **not** change the SQLite schema.

It adds richer in-memory/bootstrap dashboard view models:

- `DashboardDailySummary`
- `DashboardRecentTransaction`
- `DashboardLowStockAlert`
- `DashboardOpsSnapshot`

These are derived from existing Patch 1-5 tables and returned through the bootstrap payload.

## Files changed in this patch

- `package.json`
- `scripts/validate-patch6.mjs`
- `src/app/AppProvider.tsx`
- `src/modules/dashboard/DashboardPage.tsx`
- `src/modules/shell/AppShell.tsx`
- `src/shared/types.ts`
- `src/styles.css`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src-tauri/src/commands/bootstrap.rs`
- `src-tauri/src/core/dashboard.rs`
- `src-tauri/src/core/mod.rs`
- `src-tauri/src/core/patching.rs`
- `src-tauri/src/domain/bootstrap.rs`
- `src-tauri/src/domain/models.rs`

## Apply instructions

### macOS / Linux

```bash
./apply_patch.sh /path/to/patch5-project
```

### Windows PowerShell

```powershell
./apply_patch.ps1 -TargetDir C:/path/to/patch5-project
```

### Direct Node

```bash
node apply_patch.mjs /path/to/patch5-project --install
```

## Post-apply steps

```bash
npm install
npm run validate:patch6
npm run tauri dev
```

## Validation focus

After applying Patch 6:

1. the app should open with Patch 6 / version 0.6.0 visible
2. the dashboard should show daily summary chips
3. the dashboard should show recent transactions
4. the dashboard should show low-stock alerts when present
5. quick actions should navigate correctly
6. backup/export quick actions should update dashboard visibility after refresh
7. the app shell should show the new daily-ops messaging and header chips

## Migration notes

No SQL migration is included.

- schema version remains `5`
- Patch 6 is registered in `patch_history`
- `app_meta.patch_level` becomes `P006_dashboard_daily_ops_mvp`
- `app_meta.app_version` becomes `0.6.0`

## Rollback notes

- restore from your source control state, or
- restore overwritten files from `.patch-backups/P006_dashboard_daily_ops_mvp/`
- no schema rollback is required because this patch does not alter the database structure

```


# FILE: PATCH_NOTES.md

```
# Patch Notes

## Added

- `src-tauri/src/core/dashboard.rs`
- `scripts/validate-patch6.mjs`

## Updated

- frontend dashboard with daily summary, quick actions, recent transactions, and low-stock watchlists
- app shell labels and operational status chips
- Rust bootstrap composition for richer dashboard data
- patch registration metadata for Patch 6 / version 0.6.0

## No schema migration

Patch 6 intentionally does not add or modify SQLite tables. It derives daily ops data from existing Patch 1-5 tables.

```


# FILE: TREE.txt

```
.
PATCH-6-README.md
PATCH_NOTES.md
TREE.txt
apply_patch.mjs
apply_patch.ps1
apply_patch.sh
files
files/package.json
files/scripts
files/scripts/validate-patch6.mjs
files/src
files/src-tauri
files/src-tauri/Cargo.toml
files/src-tauri/src
files/src-tauri/src/commands
files/src-tauri/src/commands/bootstrap.rs
files/src-tauri/src/core
files/src-tauri/src/core/dashboard.rs
files/src-tauri/src/core/mod.rs
files/src-tauri/src/core/patching.rs
files/src-tauri/src/domain
files/src-tauri/src/domain/bootstrap.rs
files/src-tauri/src/domain/models.rs
files/src-tauri/tauri.conf.json
files/src/app
files/src/app/AppProvider.tsx
files/src/modules
files/src/modules/dashboard
files/src/modules/dashboard/DashboardPage.tsx
files/src/modules/shell
files/src/modules/shell/AppShell.tsx
files/src/shared
files/src/shared/types.ts
files/src/styles.css
migrations
migrations/MIGRATION_NOTES.md
patch-manifest.json
rollback.md
validate.md

```


# FILE: apply_patch.mjs

```
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const manifestPath = path.join(__dirname, "patch-manifest.json");
const filesDir = path.join(__dirname, "files");
const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));

const args = process.argv.slice(2);
const force = args.includes("--force");
const install = args.includes("--install");
const targetArg = args.find((arg) => !arg.startsWith("--"));
const targetPath = path.resolve(targetArg || process.cwd());
const patchBackupRoot = path.join(targetPath, ".patch-backups", manifest.patch_id);
const patchMetaRoot = path.join(targetPath, ".patch-meta");

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function listFilesRecursively(dir, prefix = "") {
  const results = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const entryRel = path.join(prefix, entry.name);
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...listFilesRecursively(full, entryRel));
    } else {
      results.push(entryRel);
    }
  }
  return results;
}

function readFileOrNull(filePath) {
  if (!fs.existsSync(filePath)) return null;
  return fs.readFileSync(filePath);
}

function sameFile(a, b) {
  if (a === null || b === null) return false;
  return Buffer.compare(a, b) === 0;
}

function validatePatch5Base() {
  const packageJsonPath = path.join(targetPath, "package.json");
  const patchingPath = path.join(targetPath, "src-tauri", "src", "core", "patching.rs");
  const posPagePath = path.join(targetPath, "src", "modules", "pos", "PosPage.tsx");
  const migration5Path = path.join(
    targetPath,
    "src-tauri",
    "src",
    "core",
    "migrations",
    "005_pos_checkout_core.sql"
  );

  if (!fs.existsSync(packageJsonPath) || !fs.existsSync(patchingPath) || !fs.existsSync(posPagePath) || !fs.existsSync(migration5Path)) {
    throw new Error(
      "Patch 6 expects an existing Patch 5 project. Missing package.json, patching.rs, PosPage.tsx, or migration 005."
    );
  }

  const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, "utf8"));
  const patchingSource = fs.readFileSync(patchingPath, "utf8");
  const looksLikePatch5 =
    String(packageJson.version || "").startsWith("0.5") ||
    patchingSource.includes("P005_pos_checkout_core");

  if (!looksLikePatch5 && !force) {
    throw new Error(
      "Target project does not look like a Patch 5 base. Re-run with --force only if you are sure."
    );
  }
}

function backupExistingFile(relativePath, existingContents) {
  const backupPath = path.join(patchBackupRoot, relativePath);
  ensureDir(path.dirname(backupPath));
  fs.writeFileSync(backupPath, existingContents);
}

function copyFile(relativePath) {
  const source = path.join(filesDir, relativePath);
  const target = path.join(targetPath, relativePath);
  ensureDir(path.dirname(target));

  const incoming = fs.readFileSync(source);
  const existing = readFileOrNull(target);

  if (existing !== null && !sameFile(existing, incoming)) {
    backupExistingFile(relativePath, existing);
  }

  fs.writeFileSync(target, incoming);
}

function loadAppliedPatches(metaFile) {
  if (!fs.existsSync(metaFile)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(metaFile, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function maybeRunInstall() {
  if (!install) return;

  const npmCommand = process.platform === "win32" ? "npm.cmd" : "npm";
  const result = spawnSync(npmCommand, ["install"], {
    cwd: targetPath,
    stdio: "inherit",
    shell: false
  });

  if (result.status !== 0) {
    throw new Error("npm install failed after applying the patch");
  }
}

function main() {
  if (!fs.existsSync(filesDir)) {
    throw new Error(`Patch bundle is missing files directory: ${filesDir}`);
  }

  ensureDir(targetPath);
  ensureDir(patchMetaRoot);
  validatePatch5Base();

  const fileList = listFilesRecursively(filesDir);
  for (const relativePath of fileList) {
    copyFile(relativePath);
  }

  const appliedPatchesFile = path.join(patchMetaRoot, "applied-patches.json");
  const appliedPatches = loadAppliedPatches(appliedPatchesFile).filter(
    (entry) => entry && entry.patchId !== manifest.patch_id
  );
  appliedPatches.push({
    patchId: manifest.patch_id,
    patchName: manifest.patch_name,
    appliedAt: new Date().toISOString(),
    fileCount: fileList.length,
    dependencies: manifest.dependencies
  });
  fs.writeFileSync(appliedPatchesFile, JSON.stringify(appliedPatches, null, 2) + "\n");

  fs.writeFileSync(
    path.join(patchMetaRoot, "last-applied.json"),
    JSON.stringify(
      {
        patchId: manifest.patch_id,
        patchName: manifest.patch_name,
        targetPath,
        appliedAt: new Date().toISOString(),
        fileCount: fileList.length,
        installRan: install
      },
      null,
      2
    ) + "\n"
  );

  maybeRunInstall();

  console.log(`[OK] Applied ${manifest.patch_id} to ${targetPath}`);
  console.log(`[INFO] Files copied: ${fileList.length}`);
  console.log(`[INFO] Backups stored in ${patchBackupRoot}`);
}

try {
  main();
} catch (error) {
  console.error(`[ERROR] ${error instanceof Error ? error.message : String(error)}`);
  process.exit(1);
}

```


# FILE: apply_patch.ps1

```
param(
  [string]$TargetDir = "."
)

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
node "$scriptRoot/apply_patch.mjs" $TargetDir --install

```


# FILE: apply_patch.sh

```
#!/usr/bin/env bash
set -euo pipefail

TARGET_DIR="${1:-.}"
node "$(cd "$(dirname "$0")" && pwd)/apply_patch.mjs" "$TARGET_DIR" --install

```


# FILE: files/package.json

```
{
  "name": "local-first-business-manager",
  "private": true,
  "version": "0.6.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview",
    "tauri": "tauri",
    "typecheck": "tsc --noEmit",
    "validate:patch3": "node scripts/validate-patch3.mjs",
    "validate:patch4": "node scripts/validate-patch4.mjs",
    "validate:patch5": "node scripts/validate-patch5.mjs",
    "validate:patch6": "node scripts/validate-patch6.mjs"
  },
  "dependencies": {
    "@tauri-apps/api": "^2.0.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@tauri-apps/cli": "^2.0.0",
    "@types/react": "^18.3.7",
    "@types/react-dom": "^18.3.3",
    "@vitejs/plugin-react": "^4.3.3",
    "typescript": "^5.6.3",
    "vite": "^5.4.10"
  }
}

```


# FILE: files/scripts/validate-patch6.mjs

```
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
let ts = null;
try {
  ts = require("typescript");
} catch {
  ts = null;
}

const requiredFiles = [
  "package.json",
  "src/shared/types.ts",
  "src/modules/dashboard/DashboardPage.tsx",
  "src/modules/shell/AppShell.tsx",
  "src-tauri/src/core/dashboard.rs",
  "src-tauri/src/domain/bootstrap.rs",
  "src-tauri/src/core/patching.rs"
];

const requiredSnippets = [
  ["package.json", '"validate:patch6": "node scripts/validate-patch6.mjs"'],
  ["src/shared/types.ts", "export interface DashboardDailySummary"],
  ["src/shared/types.ts", "export interface DashboardRecentTransaction"],
  ["src/shared/types.ts", "export interface DashboardLowStockAlert"],
  ["src/modules/dashboard/DashboardPage.tsx", "Patch 6 daily ops MVP"],
  ["src/modules/dashboard/DashboardPage.tsx", "Quick actions"],
  ["src/modules/dashboard/DashboardPage.tsx", "Recent transactions"],
  ["src/modules/dashboard/DashboardPage.tsx", "Low-stock alerts"],
  ["src/modules/shell/AppShell.tsx", "Daily ops MVP ready"],
  ["src-tauri/src/core/dashboard.rs", "build_ops_snapshot"],
  ["src-tauri/src/core/dashboard.rs", "list_recent_transactions"],
  ["src-tauri/src/commands/bootstrap.rs", "dashboard::build_daily_summary"],
  ["src-tauri/src/core/patching.rs", "P006_dashboard_daily_ops_mvp"],
  ["src-tauri/src/core/patching.rs", 'APP_VERSION: &str = "0.6.0"'],
  ["src-tauri/src/core/migrations.rs", "CURRENT_SCHEMA_VERSION: i64 = 5"]
];

let hasError = false;

for (const relativePath of requiredFiles) {
  const fullPath = path.resolve(relativePath);
  if (!fs.existsSync(fullPath)) {
    console.error(`[ERROR] Missing required file: ${relativePath}`);
    hasError = true;
  }
}

for (const [relativePath, snippet] of requiredSnippets) {
  const fullPath = path.resolve(relativePath);
  if (!fs.existsSync(fullPath)) continue;
  const contents = fs.readFileSync(fullPath, "utf8");
  if (!contents.includes(snippet)) {
    console.error(`[ERROR] Expected snippet not found in ${relativePath}: ${snippet}`);
    hasError = true;
  }
}

for (const relativePath of ["package.json", "src-tauri/tauri.conf.json"]) {
  try {
    JSON.parse(fs.readFileSync(path.resolve(relativePath), "utf8"));
  } catch (error) {
    hasError = true;
    console.error(
      `[ERROR] Invalid JSON in ${relativePath}: ${error instanceof Error ? error.message : String(error)}`
    );
  }
}

function walk(dir) {
  const output = [];
  if (!fs.existsSync(dir)) return output;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      output.push(...walk(fullPath));
      continue;
    }
    if (/\.(ts|tsx)$/.test(entry.name)) {
      output.push(fullPath);
    }
  }
  return output;
}

if (ts) {
  for (const fullPath of walk(path.resolve("src"))) {
    const source = fs.readFileSync(fullPath, "utf8");
    const scriptKind = fullPath.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
    const sourceFile = ts.createSourceFile(
      fullPath,
      source,
      ts.ScriptTarget.Latest,
      true,
      scriptKind
    );
    if (sourceFile.parseDiagnostics.length > 0) {
      hasError = true;
      console.error(`[ERROR] TypeScript parse diagnostics in ${path.relative(process.cwd(), fullPath)}`);
      for (const diagnostic of sourceFile.parseDiagnostics) {
        console.error(ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n"));
      }
    }
  }
} else {
  console.warn("[WARN] typescript module not installed; skipping TS parse diagnostics.");
}

if (hasError) {
  process.exit(1);
}

console.log("[OK] Patch 6 structural validation passed.");

```


# FILE: files/src/app/AppProvider.tsx

```
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type PropsWithChildren
} from "react";
import {
  bootstrapApp,
  createBackupSnapshot,
  createBusinessWorkspace,
  exportFoundationSnapshot,
  previewImportBundle,
  saveBusinessProfile,
  saveWorkspaceConfiguration,
  switchActiveBusiness
} from "../shared/api";
import type {
  AppBootstrap,
  BackupRecord,
  BusinessProfile,
  ImportPreview,
  NewBusinessWorkspaceInput,
  WorkspaceConfigurationInput
} from "../shared/types";

type AppStatus = "loading" | "ready" | "error";

interface AppContextValue {
  status: AppStatus;
  errorMessage: string | null;
  data: AppBootstrap | null;
  refresh: () => Promise<void>;
  saveProfile: (profile: BusinessProfile) => Promise<BusinessProfile>;
  createBusiness: (input: NewBusinessWorkspaceInput) => Promise<BusinessProfile>;
  switchBusiness: (businessId: string) => Promise<BusinessProfile>;
  saveWorkspace: (input: WorkspaceConfigurationInput) => Promise<void>;
  createBackup: () => Promise<BackupRecord>;
  exportFoundation: () => Promise<string>;
  previewImport: (filePath: string) => Promise<ImportPreview>;
}

type RefreshMode = "blocking" | "background";

const AppContext = createContext<AppContextValue | undefined>(undefined);

export function AppProvider({ children }: PropsWithChildren) {
  const [status, setStatus] = useState<AppStatus>("loading");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [data, setData] = useState<AppBootstrap | null>(null);
  const hasLoadedOnceRef = useRef(false);

  const loadBootstrap = useCallback(async (mode: RefreshMode) => {
    if (mode === "blocking" || !hasLoadedOnceRef.current) {
      setStatus("loading");
    }
    setErrorMessage(null);
    try {
      const bootstrap = await bootstrapApp();
      setData(bootstrap);
      hasLoadedOnceRef.current = true;
      setStatus("ready");
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to bootstrap app";
      setErrorMessage(message);
      setStatus("error");
    }
  }, []);

  const refresh = useCallback(async () => {
    await loadBootstrap("background");
  }, [loadBootstrap]);

  useEffect(() => {
    void loadBootstrap("blocking");
  }, [loadBootstrap]);

  const saveProfile = useCallback(
    async (profile: BusinessProfile) => {
      const saved = await saveBusinessProfile(profile);
      await refresh();
      return saved;
    },
    [refresh]
  );

  const createBusiness = useCallback(
    async (input: NewBusinessWorkspaceInput) => {
      const created = await createBusinessWorkspace(input);
      await refresh();
      return created;
    },
    [refresh]
  );

  const switchBusiness = useCallback(
    async (businessId: string) => {
      const result = await switchActiveBusiness(businessId);
      await refresh();
      return result;
    },
    [refresh]
  );

  const saveWorkspace = useCallback(
    async (input: WorkspaceConfigurationInput) => {
      await saveWorkspaceConfiguration(input);
      await refresh();
    },
    [refresh]
  );

  const createBackupAction = useCallback(async () => {
    const result = await createBackupSnapshot();
    await refresh();
    return result;
  }, [refresh]);

  const exportFoundationAction = useCallback(async () => {
    const result = await exportFoundationSnapshot();
    await refresh();
    return result;
  }, [refresh]);

  const previewImportAction = useCallback(async (filePath: string) => {
    return previewImportBundle(filePath);
  }, []);

  const value = useMemo<AppContextValue>(
    () => ({
      status,
      errorMessage,
      data,
      refresh,
      saveProfile,
      createBusiness,
      switchBusiness,
      saveWorkspace,
      createBackup: createBackupAction,
      exportFoundation: exportFoundationAction,
      previewImport: previewImportAction
    }),
    [
      status,
      errorMessage,
      data,
      refresh,
      saveProfile,
      createBusiness,
      switchBusiness,
      saveWorkspace,
      createBackupAction,
      exportFoundationAction,
      previewImportAction
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppState(): AppContextValue {
  const value = useContext(AppContext);
  if (!value) {
    throw new Error("useAppState must be used inside AppProvider");
  }
  return value;
}

export function AppStateView({ children }: PropsWithChildren) {
  const { status, errorMessage, refresh } = useAppState();

  if (status === "loading") {
    return (
      <div className="app-loading-shell">
        <div className="spinner" />
        <h1>Preparing local workspace…</h1>
        <p>
          Initializing migrations, business workspaces, settings profiles, catalog foundations, inventory ledgers, POS checkout foundations, the daily operations dashboard, and the local patch registry.
        </p>
      </div>
    );
  }

  if (status === "error") {
    return (
      <div className="app-loading-shell">
        <h1>Failed to start the app</h1>
        <p>{errorMessage ?? "Unknown startup error"}</p>
        <button className="primary-button" onClick={() => void refresh()}>
          Retry startup
        </button>
      </div>
    );
  }

  return <>{children}</>;
}

```


# FILE: files/src/modules/dashboard/DashboardPage.tsx

```
import { useState } from "react";
import { useAppState } from "../../app/AppProvider";
import type { NavPage } from "../../shared/types";
import {
  classNames,
  formatCurrency,
  formatDateTime,
  formatModuleList,
  formatQuantity,
  titleCaseWords
} from "../../shared/utils";

interface DashboardPageProps {
  onNavigate: (page: NavPage) => void;
}

type QuickActionDefinition = {
  id: string;
  label: string;
  note: string;
  buttonLabel: string;
  tone: "primary" | "secondary";
  run: () => Promise<void>;
};

function paymentStatusTone(value: string): "success" | "warning" | "neutral" {
  const normalized = value.trim().toLowerCase();
  if (normalized === "paid") return "success";
  if (normalized === "partial" || normalized === "due") return "warning";
  return "neutral";
}

export function DashboardPage({ onNavigate }: DashboardPageProps) {
  const { data, createBackup, exportFoundation } = useAppState();
  const [actionStatus, setActionStatus] = useState("");
  const [busyActionId, setBusyActionId] = useState<string | null>(null);

  if (!data) return null;

  const quickActions: QuickActionDefinition[] = [
    {
      id: "open-pos",
      label: "Start checkout",
      note: "Open the POS workspace to create a bill, resume a held cart, or print the latest receipt.",
      buttonLabel: "Open POS",
      tone: "primary",
      run: async () => onNavigate("pos")
    },
    {
      id: "open-inventory",
      label: "Record stock movement",
      note: "Jump to the inventory ledger to record stock in, stock out, or a manual adjustment.",
      buttonLabel: "Open Inventory",
      tone: "secondary",
      run: async () => onNavigate("inventory")
    },
    {
      id: "open-catalog",
      label: "Review catalog",
      note: "Open the catalog workspace to add an item, adjust prices, or archive unused products.",
      buttonLabel: "Open Catalog",
      tone: "secondary",
      run: async () => onNavigate("catalog")
    },
    {
      id: "create-backup",
      label: "Create backup snapshot",
      note: "Write a local backup snapshot immediately before making larger business changes.",
      buttonLabel: "Create Backup",
      tone: "secondary",
      run: async () => {
        setActionStatus("Creating local backup snapshot…");
        const backup = await createBackup();
        setActionStatus(`Backup created: ${backup.fileName}`);
      }
    },
    {
      id: "export-foundation",
      label: "Export workspace bundle",
      note: "Write a local export bundle for transfer, preview, restore preparation, or machine migration.",
      buttonLabel: "Export Bundle",
      tone: "secondary",
      run: async () => {
        setActionStatus("Exporting local workspace bundle…");
        const targetPath = await exportFoundation();
        setActionStatus(`Export written to: ${targetPath}`);
      }
    },
    {
      id: "open-settings",
      label: "Review workspace settings",
      note: "Open settings to adjust tax defaults, receipt options, themes, and enabled modules.",
      buttonLabel: "Open Settings",
      tone: "secondary",
      run: async () => onNavigate("settings")
    }
  ];

  async function handleQuickAction(action: QuickActionDefinition) {
    setBusyActionId(action.id);
    try {
      await action.run();
      if (action.id.startsWith("open-")) {
        setActionStatus(`${action.label} ready.`);
      }
    } catch (error) {
      setActionStatus(
        error instanceof Error ? error.message : "Quick action failed."
      );
    } finally {
      setBusyActionId(null);
    }
  }

  const currencyCode = data.activeBusiness.currencyCode;

  return (
    <div className="page-grid">
      <section className="hero-card">
        <div>
          <div className="section-kicker">Patch 6 daily ops MVP</div>
          <h2>{data.dashboard.heroTitle}</h2>
          <p>{data.dashboard.heroBody}</p>
        </div>
        <div className="hero-actions">
          <button
            className="primary-button"
            type="button"
            onClick={() => onNavigate("pos")}
          >
            Open POS
          </button>
          <button
            className="secondary-button"
            type="button"
            onClick={() => onNavigate("inventory")}
          >
            Open Inventory
          </button>
          <button
            className="secondary-button"
            type="button"
            onClick={() => onNavigate("data-center")}
          >
            Open Data Center
          </button>
        </div>
      </section>

      <section className="dashboard-summary-grid">
        <div className="summary-chip">
          <strong>{data.dashboard.dailySummary.todaySaleCount}</strong>
          <span>Sales today</span>
        </div>
        <div className="summary-chip">
          <strong>
            {formatCurrency(data.dashboard.dailySummary.todayGrossSales, currencyCode)}
          </strong>
          <span>Gross today</span>
        </div>
        <div className="summary-chip">
          <strong>
            {formatCurrency(data.dashboard.dailySummary.todayCollectedAmount, currencyCode)}
          </strong>
          <span>Collected today</span>
        </div>
        <div className="summary-chip">
          <strong>
            {formatCurrency(data.dashboard.dailySummary.todayDueAmount, currencyCode)}
          </strong>
          <span>Due today</span>
        </div>
        <div className="summary-chip">
          <strong>{data.dashboard.dailySummary.heldSaleCount}</strong>
          <span>Held carts</span>
        </div>
        <div className="summary-chip">
          <strong>{data.dashboard.dailySummary.lowStockCount}</strong>
          <span>Low-stock alerts</span>
        </div>
        <div className="summary-chip">
          <strong>
            {formatCurrency(data.dashboard.dailySummary.averageSaleValue, currencyCode)}
          </strong>
          <span>Average sale value</span>
        </div>
        <div className="summary-chip">
          <strong>{data.dashboard.dailySummary.activeCatalogItems}</strong>
          <span>Active catalog items</span>
        </div>
      </section>

      <section className="split-grid dashboard-primary-grid">
        <article className="card">
          <div className="card-header">
            <h3>Quick actions</h3>
            <span className="pill success">Daily use</span>
          </div>
          <p className="card-note">
            Common local actions are kept one click away so staff can move between
            checkout, stock updates, backup, and export without hunting through the shell.
          </p>
          <div className="dashboard-actions-grid">
            {quickActions.map((action) => (
              <div className="dashboard-action-card" key={action.id}>
                <strong>{action.label}</strong>
                <p className="card-note">{action.note}</p>
                <button
                  className={action.tone === "primary" ? "primary-button" : "secondary-button"}
                  type="button"
                  disabled={busyActionId === action.id}
                  onClick={() => void handleQuickAction(action)}
                >
                  {busyActionId === action.id ? "Working…" : action.buttonLabel}
                </button>
              </div>
            ))}
          </div>
          <div className="status-banner">{actionStatus || "No quick action run yet."}</div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Operations watch</h3>
            <span
              className={classNames(
                "pill",
                data.dashboard.opsSnapshot.openDueSaleCount > 0 ? "warning" : "success"
              )}
            >
              {data.dashboard.opsSnapshot.openDueSaleCount > 0 ? "Needs follow-up" : "In good shape"}
            </span>
          </div>
          <div className="dashboard-watch-grid">
            <div className="dashboard-watch-card">
              <span>Open dues across sales</span>
              <strong>
                {formatCurrency(data.dashboard.opsSnapshot.openDueAmount, currencyCode)}
              </strong>
              <small>
                {data.dashboard.opsSnapshot.openDueSaleCount} completed sale
                {data.dashboard.opsSnapshot.openDueSaleCount === 1 ? "" : "s"} still have a balance due.
              </small>
            </div>
            <div className="dashboard-watch-card">
              <span>Latest backup</span>
              <strong>
                {data.dashboard.opsSnapshot.lastBackupAt
                  ? formatDateTime(data.dashboard.opsSnapshot.lastBackupAt)
                  : "None yet"}
              </strong>
              <small>
                {data.dashboard.opsSnapshot.backupCount} snapshot
                {data.dashboard.opsSnapshot.backupCount === 1 ? "" : "s"} recorded in local storage.
              </small>
            </div>
            <div className="dashboard-watch-card">
              <span>Latest export bundle</span>
              <strong>
                {data.dashboard.opsSnapshot.lastExportAt
                  ? formatDateTime(data.dashboard.opsSnapshot.lastExportAt)
                  : "None yet"}
              </strong>
              <small>
                {data.dashboard.opsSnapshot.exportCount} export job
                {data.dashboard.opsSnapshot.exportCount === 1 ? "" : "s"} logged for transfer or restore prep.
              </small>
            </div>
            <div className="dashboard-watch-card">
              <span>Most recent sale</span>
              <strong>
                {data.dashboard.opsSnapshot.lastSaleAt
                  ? formatDateTime(data.dashboard.opsSnapshot.lastSaleAt)
                  : "No completed sales yet"}
              </strong>
              <small>
                {data.dashboard.dailySummary.totalTrackedItems} tracked stock item
                {data.dashboard.dailySummary.totalTrackedItems === 1 ? "" : "s"} remain under inventory monitoring.
              </small>
            </div>
          </div>
        </article>
      </section>

      <section className="card">
        <div className="card-header">
          <h3>Business KPIs</h3>
          <span className="pill neutral">Operational pulse</span>
        </div>
        <div className="card-grid card-grid-5">
          {data.dashboard.kpis.map((kpi) => (
            <article className="card dashboard-kpi-card" key={kpi.id}>
              <div className="card-label">{kpi.label}</div>
              <div className="kpi-value">{kpi.value}</div>
              <p className="card-note">{kpi.note}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="split-grid dashboard-secondary-grid">
        <article className="card">
          <div className="card-header">
            <h3>Recent transactions</h3>
            <span className="pill neutral">
              {data.dashboard.recentTransactions.length} recent
            </span>
          </div>
          <div className="stack-list">
            {data.dashboard.recentTransactions.length > 0 ? (
              data.dashboard.recentTransactions.map((sale) => (
                <div className="list-row dashboard-transaction-row" key={sale.saleId}>
                  <div>
                    <div className="dashboard-transaction-title-row">
                      <strong>{sale.saleNumber}</strong>
                      <span className={`pill ${paymentStatusTone(sale.paymentStatus)}`}>
                        {titleCaseWords(sale.paymentStatus)}
                      </span>
                    </div>
                    <div className="muted-text">
                      {sale.itemCount} item{sale.itemCount === 1 ? "" : "s"} · paid {formatCurrency(sale.amountPaid, currencyCode)} · due {formatCurrency(sale.balanceDue, currencyCode)}
                    </div>
                  </div>
                  <div className="dashboard-transaction-meta">
                    <strong>{formatCurrency(sale.totalAmount, currencyCode)}</strong>
                    <span className="muted-text">{formatDateTime(sale.completedAt)}</span>
                  </div>
                </div>
              ))
            ) : (
              <p className="muted-text">
                No completed sales have been recorded yet. Use the POS workspace to create the first sale.
              </p>
            )}
          </div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Low-stock alerts</h3>
            <span
              className={classNames(
                "pill",
                data.dashboard.lowStockAlerts.length > 0 ? "warning" : "success"
              )}
            >
              {data.dashboard.lowStockAlerts.length > 0 ? "Needs restock" : "No urgent alerts"}
            </span>
          </div>
          <div className="stack-list">
            {data.dashboard.lowStockAlerts.length > 0 ? (
              data.dashboard.lowStockAlerts.map((item) => (
                <div className="list-row dashboard-low-stock-row" key={item.itemId}>
                  <div>
                    <strong>{item.itemName}</strong>
                    <div className="muted-text">
                      {[item.categoryName, item.sku, item.unitCode].filter(Boolean).join(" · ") || "Uncategorized stock item"}
                    </div>
                  </div>
                  <div className="dashboard-transaction-meta">
                    <strong>
                      {formatQuantity(item.stockQuantity)} / {formatQuantity(item.reorderLevel)}
                    </strong>
                    <span className="muted-text">
                      Short by {formatQuantity(item.shortageQuantity)} · updated {formatDateTime(item.updatedAt)}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p className="muted-text">
                No tracked stock items are currently at or below their reorder levels.
              </p>
            )}
          </div>
        </article>
      </section>

      <section className="split-grid dashboard-secondary-grid">
        <article className="card">
          <div className="card-header">
            <h3>Business workspaces</h3>
            <span className="pill success">
              {data.businessWorkspaces.length} configured
            </span>
          </div>
          <div className="stack-list">
            {data.businessWorkspaces.map((workspace) => (
              <div className="list-row" key={workspace.businessId}>
                <div>
                  <strong>
                    {workspace.name}
                    {workspace.businessId === data.activeBusiness.id ? " · active" : ""}
                  </strong>
                  <div className="muted-text">
                    {workspace.code} · {workspace.currencyCode} · {workspace.timezone}
                  </div>
                  <div className="tag-list compact-tags">
                    {workspace.activeModules.map((module) => (
                      <span className="tag" key={`${workspace.businessId}-${module}`}>
                        {titleCaseWords(module)}
                      </span>
                    ))}
                  </div>
                </div>
                <span className="muted-text">{workspace.nextSaleSequence}</span>
              </div>
            ))}
          </div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Current business configuration</h3>
            <span className="pill neutral">{data.activeBusiness.code}</span>
          </div>
          <div className="detail-list">
            <div>
              <span>Theme</span>
              <code>{data.businessSettings.theme}</code>
            </div>
            <div>
              <span>Tax profile</span>
              <code>
                {data.activeTaxProfile.name} · {data.activeTaxProfile.taxLabel} · {data.activeTaxProfile.defaultRate}%
              </code>
            </div>
            <div>
              <span>Receipt profile</span>
              <code>
                {data.activeReceiptProfile.name} · {data.activeReceiptProfile.paperWidth}
              </code>
            </div>
            <div>
              <span>Enabled modules</span>
              <code>{formatModuleList(data.businessWorkspaces.find((workspace) => workspace.businessId === data.activeBusiness.id)?.activeModules ?? [])}</code>
            </div>
            <div>
              <span>Next sale number</span>
              <code>{data.businessWorkspaces.find((workspace) => workspace.businessId === data.activeBusiness.id)?.nextSaleSequence ?? "Pending"}</code>
            </div>
            <div>
              <span>Storage</span>
              <code>{data.storage.dataDir}</code>
            </div>
          </div>
        </article>
      </section>

      <section className="split-grid dashboard-secondary-grid">
        <article className="card">
          <div className="card-header">
            <h3>Recent local activity</h3>
            <span className="pill neutral">{data.dashboard.recentActivity.length} rows</span>
          </div>
          <div className="stack-list">
            {data.dashboard.recentActivity.length > 0 ? (
              data.dashboard.recentActivity.map((activity) => (
                <div className="list-row" key={activity.id}>
                  <div>
                    <strong>
                      {activity.category} · {activity.level}
                    </strong>
                    <div className="muted-text">{activity.message}</div>
                  </div>
                  <span className="muted-text">{formatDateTime(activity.createdAt)}</span>
                </div>
              ))
            ) : (
              <p className="muted-text">No local activity has been logged yet.</p>
            )}
          </div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Module status</h3>
          </div>
          <div className="stack-list">
            {data.dashboard.moduleStatuses.map((module) => (
              <div className="list-row" key={module.id}>
                <div>
                  <strong>{module.label}</strong>
                  <div className="muted-text">{module.note}</div>
                </div>
                <span className={`pill ${module.status === "planned" ? "warning" : module.status === "coming-next" ? "warning" : "success"}`}>
                  {module.status === "coming-next"
                    ? "Coming next"
                    : titleCaseWords(module.status)}
                </span>
              </div>
            ))}
          </div>
        </article>
      </section>
    </div>
  );
}

```


# FILE: files/src/modules/shell/AppShell.tsx

```
import { useEffect, useMemo, useState } from "react";
import { useAppState } from "../../app/AppProvider";
import type { NavPage } from "../../shared/types";
import { classNames, formatCurrency, formatDateTime, formatModuleList } from "../../shared/utils";
import { DashboardPage } from "../dashboard/DashboardPage";
import { PosPage } from "../pos/PosPage";
import { CatalogPage } from "../catalog/CatalogPage";
import { InventoryPage } from "../inventory/InventoryPage";
import { BusinessPage } from "../business/BusinessPage";
import { SettingsPage } from "../settings/SettingsPage";
import { DataCenterPage } from "../data-center/DataCenterPage";

const NAV_STORAGE_KEY = "lfbm.activeNavPage";

const navItems: Array<{ key: NavPage; label: string; description: string }> = [
  {
    key: "dashboard",
    label: "Dashboard",
    description: "Daily operations pulse"
  },
  {
    key: "pos",
    label: "POS",
    description: "Checkout, holds, receipts"
  },
  {
    key: "catalog",
    label: "Catalog",
    description: "Products, menu, services"
  },
  {
    key: "inventory",
    label: "Inventory",
    description: "Stock ledger and balances"
  },
  {
    key: "business",
    label: "Businesses",
    description: "Profiles and switching"
  },
  {
    key: "settings",
    label: "Settings",
    description: "Tax, receipt, modules"
  },
  {
    key: "data-center",
    label: "Data Center",
    description: "Backup and transfer foundation"
  }
];

export function AppShell() {
  const { data, switchBusiness } = useAppState();
  const [activePage, setActivePage] = useState<NavPage>(() => {
    const stored = window.localStorage.getItem(NAV_STORAGE_KEY) as NavPage | null;
    return stored ?? "dashboard";
  });
  const [switchStatus, setSwitchStatus] = useState<string>("");

  useEffect(() => {
    window.localStorage.setItem(NAV_STORAGE_KEY, activePage);
  }, [activePage]);

  useEffect(() => {
    setSwitchStatus("");
  }, [data?.activeBusiness.id]);

  const pageTitle = useMemo(() => {
    return navItems.find((item) => item.key === activePage)?.label ?? "Dashboard";
  }, [activePage]);

  const activeWorkspace = useMemo(() => {
    return data?.businessWorkspaces.find(
      (workspace) => workspace.businessId === data.activeBusiness.id
    );
  }, [data]);

  if (!data) {
    return null;
  }

  async function handleBusinessSwitch(nextBusinessId: string) {
    if (nextBusinessId === data.activeBusiness.id) {
      return;
    }

    setSwitchStatus("Switching active business…");
    try {
      const switched = await switchBusiness(nextBusinessId);
      setSwitchStatus(`Switched to ${switched.name}.`);
    } catch (error) {
      setSwitchStatus(
        error instanceof Error ? error.message : "Failed to switch business."
      );
    }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <div className="brand-badge">P6</div>
          <div>
            <strong>Local Business Manager</strong>
            <div className="muted-text">
              {data.appInfo.version} · {data.appInfo.patchLevel}
            </div>
          </div>
        </div>

        <div className="sidebar-section-label">Workspace</div>
        <nav className="nav-list">
          {navItems.map((item) => (
            <button
              key={item.key}
              type="button"
              className={classNames(
                "nav-item",
                activePage === item.key && "nav-item-active"
              )}
              onClick={() => setActivePage(item.key)}
            >
              <span className="nav-title">{item.label}</span>
              <span className="nav-description">{item.description}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-section-label">Active business</div>
        <div className="sidebar-card">
          <div className="sidebar-card-title">{data.activeBusiness.name}</div>
          <div className="muted-text">
            {data.activeBusiness.businessType} · {data.activeBusiness.currencyCode}
          </div>
          <label className="sidebar-field">
            <span>Switch workspace</span>
            <select
              className="sidebar-select"
              value={data.activeBusiness.id}
              onChange={(event) => void handleBusinessSwitch(event.target.value)}
            >
              {data.businessWorkspaces.map((workspace) => (
                <option key={workspace.businessId} value={workspace.businessId}>
                  {workspace.name} ({workspace.code})
                </option>
              ))}
            </select>
          </label>
          <div className="sidebar-metadata-grid">
            <div>
              <span>Sales today</span>
              <strong>{data.posSummary.todaySaleCount}</strong>
            </div>
            <div>
              <span>Held carts</span>
              <strong>{data.posSummary.heldSaleCount}</strong>
            </div>
            <div>
              <span>Open dues</span>
              <strong>
                {formatCurrency(
                  data.dashboard.opsSnapshot.openDueAmount,
                  data.activeBusiness.currencyCode
                )}
              </strong>
            </div>
            <div>
              <span>Low stock</span>
              <strong>{data.inventorySummary.lowStockItems}</strong>
            </div>
          </div>
          <div className="muted-text small-text">
            {switchStatus ||
              `${formatCurrency(data.posSummary.todayGrossSales, data.activeBusiness.currencyCode)} today · ${activeWorkspace?.nextSaleSequence ?? "Sequence pending"}`}
          </div>
        </div>

        <div className="sidebar-section-label">Business mode</div>
        <div className="sidebar-card">
          <div className="sidebar-pill success">Daily ops MVP ready</div>
          <div className="sidebar-pill neutral">POS checkout ready</div>
          <div className="sidebar-pill neutral">Inventory ledger ready</div>
          <div className="muted-text small-text">
            {formatModuleList(activeWorkspace?.activeModules ?? [])}
          </div>
          <div className="muted-text small-text">
            Last backup: {data.dashboard.opsSnapshot.lastBackupAt ? formatDateTime(data.dashboard.opsSnapshot.lastBackupAt) : "not yet created"}
          </div>
        </div>
      </aside>

      <main className="workspace">
        <header className="workspace-header">
          <div>
            <h1>{pageTitle}</h1>
            <p>
              Patch 6 turns the app into a more usable daily local workspace with a stronger home dashboard,
              sales pulse, low-stock watchlists, due tracking, quick actions, and better visibility into local
              backup and export activity.
            </p>
          </div>
          <div className="workspace-header-meta">
            <span className="meta-chip">Business: {data.activeBusiness.code}</span>
            <span className="meta-chip">
              Sales today: {data.posSummary.todaySaleCount}
            </span>
            <span className="meta-chip">
              Gross today: {formatCurrency(data.posSummary.todayGrossSales, data.activeBusiness.currencyCode)}
            </span>
            <span className="meta-chip">
              Open dues: {formatCurrency(data.dashboard.opsSnapshot.openDueAmount, data.activeBusiness.currencyCode)}
            </span>
            <span className="meta-chip">Held carts: {data.posSummary.heldSaleCount}</span>
            <span className="meta-chip">Low stock: {data.inventorySummary.lowStockItems}</span>
            <span className="meta-chip">Schema v{data.appInfo.schemaVersion}</span>
          </div>
        </header>

        <section className="workspace-content">
          {activePage === "dashboard" && (
            <DashboardPage onNavigate={setActivePage} />
          )}
          {activePage === "pos" && <PosPage />}
          {activePage === "catalog" && <CatalogPage />}
          {activePage === "inventory" && <InventoryPage />}
          {activePage === "business" && <BusinessPage />}
          {activePage === "settings" && <SettingsPage />}
          {activePage === "data-center" && <DataCenterPage />}
        </section>
      </main>
    </div>
  );
}

```


# FILE: files/src/shared/types.ts

```
export interface BusinessProfile {
  id: string;
  name: string;
  legalName: string | null;
  code: string;
  businessType: string;
  currencyCode: string;
  taxMode: string;
  phone: string | null;
  email: string | null;
  addressLine1: string | null;
  addressLine2: string | null;
  city: string | null;
  state: string | null;
  postalCode: string | null;
  country: string | null;
  createdAt: string;
  updatedAt: string;
  archivedAt: string | null;
}

export interface BusinessSettings {
  businessId: string;
  timezone: string;
  locale: string;
  dateFormat: string;
  theme: string;
  taxLabel: string;
  defaultTaxRate: number;
  pricesIncludeTax: boolean;
  receiptFooter: string | null;
  receiptShowAddress: boolean;
  receiptShowPhone: boolean;
  autoBackupEnabled: boolean;
  backupDirectory: string | null;
  moduleRestaurantEnabled: boolean;
  moduleRetailEnabled: boolean;
  moduleInventoryEnabled: boolean;
  moduleServicesEnabled: boolean;
  updatedAt: string;
}

export interface TaxProfile {
  id: string;
  businessId: string;
  name: string;
  taxLabel: string;
  defaultRate: number;
  pricesIncludeTax: boolean;
  isDefault: boolean;
  updatedAt: string;
}

export interface ReceiptProfile {
  id: string;
  businessId: string;
  name: string;
  footerText: string | null;
  showAddress: boolean;
  showPhone: boolean;
  showEmail: boolean;
  showBusinessCode: boolean;
  paperWidth: string;
  isDefault: boolean;
  updatedAt: string;
}

export interface ModuleFlags {
  businessId: string;
  restaurantEnabled: boolean;
  retailEnabled: boolean;
  inventoryEnabled: boolean;
  servicesEnabled: boolean;
  customersEnabled: boolean;
  suppliersEnabled: boolean;
  expensesEnabled: boolean;
  reportingEnabled: boolean;
  dataCenterEnabled: boolean;
  updatedAt: string;
}

export interface SequenceCounter {
  id: string;
  businessId: string;
  scope: string;
  prefix: string;
  nextNumber: number;
  padding: number;
  resetPolicy: string;
  updatedAt: string;
}

export interface NewBusinessWorkspaceInput {
  name: string;
  legalName: string | null;
  code: string;
  businessType: string;
  currencyCode: string;
  taxMode: string;
  timezone: string;
  locale: string;
  activateNow: boolean;
}

export interface WorkspaceConfigurationInput {
  businessSettings: BusinessSettings;
  taxProfile: TaxProfile;
  receiptProfile: ReceiptProfile;
  moduleFlags: ModuleFlags;
  sequenceCounters: SequenceCounter[];
}

export interface AppInfo {
  appName: string;
  productName: string;
  version: string;
  schemaVersion: number;
  patchLevel: string;
  initializedAt: string;
}

export interface PatchRecord {
  patchId: string;
  patchName: string;
  appliedAt: string;
  schemaVersion: number;
}

export interface BackupRecord {
  id: string;
  businessId: string | null;
  fileName: string;
  filePath: string;
  checksum: string | null;
  status: string;
  createdAt: string;
}

export interface ExportJobRecord {
  id: string;
  businessId: string | null;
  format: string;
  status: string;
  targetPath: string | null;
  createdAt: string;
  completedAt: string | null;
}

export interface ImportPreview {
  filePath: string;
  valid: boolean;
  manifestVersion: string | null;
  bundleType: string | null;
  sourcePatchLevel: string | null;
  businessCount: number;
  categoryCount: number;
  itemCount: number;
  stockBalanceCount: number;
  movementCount: number;
  saleCount: number;
  heldSaleCount: number;
  generatedAt: string | null;
  warnings: string[];
}

export interface RecentActivity {
  id: string;
  level: string;
  category: string;
  message: string;
  createdAt: string;
}

export interface KpiCard {
  id: string;
  label: string;
  value: string;
  note: string;
}

export interface ModuleStatus {
  id: string;
  label: string;
  status: "active-foundation" | "planned" | "coming-next";
  note: string;
}

export interface DashboardDailySummary {
  todaySaleCount: number;
  todayGrossSales: number;
  todayCollectedAmount: number;
  todayDueAmount: number;
  heldSaleCount: number;
  lowStockCount: number;
  averageSaleValue: number;
  totalTrackedItems: number;
  activeCatalogItems: number;
}

export interface DashboardRecentTransaction {
  saleId: string;
  saleNumber: string;
  paymentStatus: string;
  totalAmount: number;
  amountPaid: number;
  balanceDue: number;
  itemCount: number;
  completedAt: string;
}

export interface DashboardLowStockAlert {
  itemId: string;
  itemName: string;
  sku: string | null;
  categoryName: string | null;
  unitCode: string | null;
  stockQuantity: number;
  reorderLevel: number;
  shortageQuantity: number;
  updatedAt: string;
}

export interface DashboardOpsSnapshot {
  openDueSaleCount: number;
  openDueAmount: number;
  backupCount: number;
  exportCount: number;
  lastBackupAt: string | null;
  lastExportAt: string | null;
  lastSaleAt: string | null;
}

export interface DashboardShellData {
  heroTitle: string;
  heroBody: string;
  kpis: KpiCard[];
  recentActivity: RecentActivity[];
  moduleStatuses: ModuleStatus[];
  dailySummary: DashboardDailySummary;
  recentTransactions: DashboardRecentTransaction[];
  lowStockAlerts: DashboardLowStockAlert[];
  opsSnapshot: DashboardOpsSnapshot;
}

export interface StorageStatus {
  dataDir: string;
  configDir: string;
  logDir: string;
  backupDir: string;
  exportDir: string;
  databasePath: string;
  databaseExists: boolean;
  backupCount: number;
  exportCount: number;
}

export interface BusinessWorkspaceSummary {
  businessId: string;
  name: string;
  code: string;
  businessType: string;
  currencyCode: string;
  theme: string;
  timezone: string;
  taxLabel: string;
  defaultTaxRate: number;
  nextSaleSequence: string;
  activeModules: string[];
  archivedAt: string | null;
  updatedAt: string;
}

export interface CatalogCategory {
  id: string;
  businessId: string;
  name: string;
  code: string;
  parentId: string | null;
  itemScope: string;
  sortOrder: number;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  archivedAt: string | null;
}

export interface CatalogUnit {
  id: string;
  businessId: string | null;
  name: string;
  code: string;
  symbol: string;
  allowFractional: boolean;
  isSystem: boolean;
  updatedAt: string;
  archivedAt: string | null;
}

export interface CatalogItem {
  id: string;
  businessId: string;
  categoryId: string | null;
  unitId: string | null;
  taxProfileId: string | null;
  itemKind: string;
  name: string;
  displayName: string | null;
  sku: string | null;
  primaryBarcode: string | null;
  description: string | null;
  sellingPrice: number;
  costPrice: number;
  trackStock: boolean;
  stockQuantity: number;
  reorderLevel: number;
  imagePath: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  archivedAt: string | null;
}

export interface CatalogBarcode {
  id: string;
  itemId: string;
  barcode: string;
  label: string | null;
  isPrimary: boolean;
  createdAt: string;
}

export interface CatalogItemView {
  item: CatalogItem;
  categoryName: string | null;
  unitCode: string | null;
  taxLabel: string | null;
  barcodes: CatalogBarcode[];
}

export interface CatalogSummary {
  totalItems: number;
  activeItems: number;
  archivedItems: number;
  categoryCount: number;
  menuItemCount: number;
  stockItemCount: number;
  serviceItemCount: number;
  lowStockCandidates: number;
}

export interface CatalogWorkspace {
  businessId: string;
  summary: CatalogSummary;
  categories: CatalogCategory[];
  units: CatalogUnit[];
  taxProfiles: TaxProfile[];
  items: CatalogItemView[];
}

export interface SaveCatalogCategoryInput {
  id?: string | null;
  name: string;
  code: string;
  parentId: string | null;
  itemScope: string;
  sortOrder: number;
  notes: string | null;
}

export interface SaveCatalogUnitInput {
  id?: string | null;
  name: string;
  code: string;
  symbol: string;
  allowFractional: boolean;
}

export interface SaveCatalogItemInput {
  id?: string | null;
  categoryId: string | null;
  unitId: string | null;
  taxProfileId: string | null;
  itemKind: string;
  name: string;
  displayName: string | null;
  sku: string | null;
  barcodes: string[];
  description: string | null;
  sellingPrice: number;
  costPrice: number;
  trackStock: boolean;
  stockQuantity: number;
  reorderLevel: number;
  imagePath: string | null;
  isActive: boolean;
}

export interface InventorySummary {
  totalTrackedItems: number;
  lowStockItems: number;
  movementCount: number;
  totalQuantityOnHand: number;
}

export interface InventoryStockItem {
  itemId: string;
  itemName: string;
  itemKind: string;
  sku: string | null;
  categoryName: string | null;
  unitCode: string | null;
  trackStock: boolean;
  stockQuantity: number;
  reorderLevel: number;
  lowStock: boolean;
  updatedAt: string;
}

export interface InventoryMovement {
  id: string;
  businessId: string;
  itemId: string;
  itemName: string;
  sku: string | null;
  unitCode: string | null;
  movementType: string;
  quantityDelta: number;
  quantityAfter: number;
  unitCost: number | null;
  note: string | null;
  occurredAt: string;
  createdAt: string;
}

export interface InventoryWorkspace {
  businessId: string;
  summary: InventorySummary;
  stockItems: InventoryStockItem[];
  recentMovements: InventoryMovement[];
}

export interface SaveInventoryMovementInput {
  itemId: string;
  movementType: string;
  quantity: number;
  unitCost: number | null;
  note: string | null;
}

export interface SaveInventoryStockRuleInput {
  itemId: string;
  trackStock: boolean;
  reorderLevel: number;
}

export interface PosSummary {
  completedSaleCount: number;
  todaySaleCount: number;
  heldSaleCount: number;
  todayGrossSales: number;
  todayCollectedAmount: number;
  todayDueAmount: number;
  averageSaleValue: number;
}

export interface PosSellableItem {
  itemId: string;
  name: string;
  displayName: string | null;
  itemKind: string;
  categoryName: string | null;
  unitCode: string | null;
  allowFractional: boolean;
  sku: string | null;
  primaryBarcode: string | null;
  sellingPrice: number;
  trackStock: boolean;
  onHandQuantity: number;
  taxLabel: string | null;
  taxRate: number;
  pricesIncludeTax: boolean;
  isAvailable: boolean;
}

export interface PosCartLineInput {
  itemId: string;
  quantity: number;
  unitPrice: number | null;
  discountAmount: number;
  notes: string | null;
}

export interface PosPaymentEntryInput {
  paymentMode: string;
  amount: number;
  referenceValue: string | null;
  notes: string | null;
}

export interface SavePosHoldInput {
  id?: string | null;
  holdLabel: string;
  notes: string | null;
  cartLines: PosCartLineInput[];
  cartDiscountAmount: number;
}

export interface CompletePosSaleInput {
  holdId: string | null;
  notes: string | null;
  cartLines: PosCartLineInput[];
  cartDiscountAmount: number;
  payments: PosPaymentEntryInput[];
}

export interface PosHoldSummary {
  id: string;
  businessId: string;
  holdCode: string;
  holdLabel: string;
  itemCount: number;
  subtotalAmount: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
  notes: string | null;
  cartLines: PosCartLineInput[];
  cartDiscountAmount: number;
  createdAt: string;
  updatedAt: string;
}

export interface PosSaleRecord {
  id: string;
  businessId: string;
  registerSessionId: string | null;
  saleNumber: string;
  saleStatus: string;
  paymentStatus: string;
  currencyCode: string;
  subtotalAmount: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
  amountPaid: number;
  balanceDue: number;
  itemCount: number;
  notes: string | null;
  completedAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface PosSaleLine {
  id: string;
  saleId: string;
  itemId: string | null;
  itemName: string;
  itemKind: string;
  categoryName: string | null;
  sku: string | null;
  primaryBarcode: string | null;
  unitCode: string | null;
  taxLabel: string | null;
  taxRate: number;
  pricesIncludeTax: boolean;
  quantity: number;
  unitPrice: number;
  grossAmount: number;
  discountAmount: number;
  netAmount: number;
  taxAmount: number;
  totalAmount: number;
  notes: string | null;
}

export interface PosSalePayment {
  id: string;
  saleId: string;
  paymentMode: string;
  amount: number;
  referenceValue: string | null;
  notes: string | null;
  createdAt: string;
}

export interface PosSaleDetail {
  sale: PosSaleRecord;
  lines: PosSaleLine[];
  payments: PosSalePayment[];
}

export interface PosWorkspace {
  businessId: string;
  summary: PosSummary;
  registerLabel: string | null;
  sellableItems: PosSellableItem[];
  heldSales: PosHoldSummary[];
  recentSales: PosSaleRecord[];
}

export interface AppBootstrap {
  appInfo: AppInfo;
  activeBusiness: BusinessProfile;
  businessSettings: BusinessSettings;
  activeTaxProfile: TaxProfile;
  activeReceiptProfile: ReceiptProfile;
  activeModuleFlags: ModuleFlags;
  activeSequences: SequenceCounter[];
  businesses: BusinessProfile[];
  businessWorkspaces: BusinessWorkspaceSummary[];
  patchHistory: PatchRecord[];
  backups: BackupRecord[];
  storage: StorageStatus;
  catalogSummary: CatalogSummary;
  inventorySummary: InventorySummary;
  posSummary: PosSummary;
  dashboard: DashboardShellData;
}

export type NavPage =
  | "dashboard"
  | "pos"
  | "catalog"
  | "inventory"
  | "business"
  | "settings"
  | "data-center";

```


# FILE: files/src/styles.css

```
:root {
  color-scheme: light;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont,
    "Segoe UI", sans-serif;
  background: #f4f6fb;
  color: #172033;
  line-height: 1.5;
  font-weight: 400;
}

* {
  box-sizing: border-box;
}

html,
body,
#root {
  margin: 0;
  min-height: 100%;
}

body {
  background:
    radial-gradient(circle at top right, #e8f0ff 0, transparent 26%),
    linear-gradient(180deg, #f7f9fd 0%, #eef3fb 100%);
}

button,
input,
select,
textarea {
  font: inherit;
}

button {
  cursor: pointer;
}

code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,
    "Liberation Mono", monospace;
  word-break: break-all;
}

.app-loading-shell {
  min-height: 100vh;
  display: grid;
  place-items: center;
  align-content: center;
  gap: 0.8rem;
  padding: 2rem;
  text-align: center;
}

.spinner {
  width: 3rem;
  height: 3rem;
  border-radius: 999px;
  border: 3px solid #d3def6;
  border-top-color: #305fdb;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.app-shell {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 310px minmax(0, 1fr);
}

.sidebar {
  padding: 1.5rem;
  background: #0f172a;
  color: #e5ecfa;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  border-right: 1px solid rgba(255, 255, 255, 0.08);
}

.sidebar-brand {
  display: flex;
  align-items: center;
  gap: 0.85rem;
}

.brand-badge {
  width: 2.55rem;
  height: 2.55rem;
  border-radius: 0.85rem;
  display: grid;
  place-items: center;
  background: linear-gradient(135deg, #60a5fa, #2563eb);
  font-weight: 700;
}

.sidebar-section-label {
  font-size: 0.78rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  opacity: 0.7;
  margin-top: 0.35rem;
}

.nav-list {
  display: grid;
  gap: 0.65rem;
}

.nav-item {
  background: rgba(255, 255, 255, 0.05);
  color: inherit;
  border: 1px solid transparent;
  border-radius: 0.95rem;
  padding: 0.9rem 1rem;
  text-align: left;
  display: grid;
  gap: 0.2rem;
  transition: 0.18s ease;
}

.nav-item:hover {
  border-color: rgba(255, 255, 255, 0.15);
  transform: translateY(-1px);
}

.nav-item-active {
  background: rgba(37, 99, 235, 0.24);
  border-color: rgba(96, 165, 250, 0.4);
}

.nav-title {
  font-weight: 700;
}

.nav-description {
  color: #9fb2d7;
  font-size: 0.88rem;
}

.sidebar-card {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 0.95rem;
  padding: 1rem;
  display: grid;
  gap: 0.7rem;
}

.sidebar-card-title {
  font-weight: 700;
}

.sidebar-pill {
  display: inline-flex;
  align-items: center;
  width: fit-content;
  padding: 0.35rem 0.6rem;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.08);
  font-size: 0.85rem;
}

.sidebar-field {
  display: grid;
  gap: 0.35rem;
  color: #d8e3fb;
  font-size: 0.88rem;
}

.sidebar-select {
  width: 100%;
  border-radius: 0.8rem;
  border: 1px solid rgba(255, 255, 255, 0.14);
  background: rgba(255, 255, 255, 0.08);
  color: #f5f9ff;
  padding: 0.7rem 0.8rem;
}

.sidebar-select option {
  color: #172033;
}

.sidebar-metadata-grid {
  display: grid;
  gap: 0.55rem;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.sidebar-metadata-grid span {
  display: block;
  color: #9fb2d7;
  font-size: 0.78rem;
  margin-bottom: 0.2rem;
}

.sidebar-metadata-grid strong {
  font-size: 0.9rem;
}

.small-text {
  font-size: 0.82rem;
}

.workspace {
  min-width: 0;
  padding: 1.5rem 2rem 2rem;
}

.workspace-header {
  display: flex;
  justify-content: space-between;
  gap: 1rem;
  align-items: flex-start;
  margin-bottom: 1.25rem;
}

.workspace-header h1 {
  margin: 0 0 0.25rem;
  font-size: 2rem;
}

.workspace-header p {
  margin: 0;
  color: #52607a;
}

.workspace-header-meta {
  display: flex;
  gap: 0.6rem;
  flex-wrap: wrap;
}

.meta-chip,
.pill {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.35rem 0.7rem;
  border-radius: 999px;
  font-size: 0.84rem;
  border: 1px solid transparent;
}

.meta-chip {
  background: #ffffff;
  color: #23304a;
  border-color: #d6e0f2;
}

.pill.success {
  background: #eaf8ef;
  color: #0f7a37;
  border-color: #bfe6c9;
}

.pill.warning {
  background: #fff6e5;
  color: #a75d00;
  border-color: #f4d39c;
}

.pill.neutral {
  background: #f0f4fb;
  color: #40506b;
  border-color: #d8e0f0;
}

.workspace-content {
  display: grid;
  gap: 1.25rem;
}

.page-grid {
  display: grid;
  gap: 1.25rem;
}

.hero-card,
.card {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(8px);
  border: 1px solid #dbe5f4;
  border-radius: 1.2rem;
  padding: 1.2rem 1.25rem;
  box-shadow: 0 14px 35px rgba(15, 23, 42, 0.05);
}

.hero-card {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 1rem;
}

.hero-card h2,
.card h2,
.card h3 {
  margin: 0;
}

.hero-card p,
.card-note {
  color: #5c6c89;
  margin-top: 0.5rem;
}

.hero-actions,
.inline-actions {
  display: flex;
  gap: 0.75rem;
  align-items: center;
  flex-wrap: wrap;
}

.align-start {
  align-items: flex-start;
}

.primary-button,
.secondary-button {
  border: none;
  border-radius: 0.9rem;
  padding: 0.75rem 1rem;
  font-weight: 700;
}

.primary-button {
  background: linear-gradient(135deg, #2563eb, #1d4ed8);
  color: white;
}

.primary-button:hover {
  filter: brightness(1.04);
}

.secondary-button {
  background: white;
  color: #24324a;
  border: 1px solid #d3def3;
}

.secondary-button:hover {
  background: #f5f8fd;
}

.secondary-button:disabled {
  opacity: 0.65;
  cursor: not-allowed;
}

.section-kicker {
  color: #3357aa;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  font-size: 0.78rem;
  font-weight: 700;
}

.card-grid {
  display: grid;
  gap: 1rem;
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.card-grid-5 {
  grid-template-columns: repeat(5, minmax(0, 1fr));
}

.card-label {
  color: #60708d;
  font-size: 0.92rem;
}

.kpi-value {
  font-size: 1.9rem;
  font-weight: 800;
  margin-top: 0.2rem;
}

.split-grid {
  display: grid;
  gap: 1rem;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.card-header {
  display: flex;
  justify-content: space-between;
  gap: 0.8rem;
  align-items: center;
  margin-bottom: 0.75rem;
}

.compact-card-header {
  margin-bottom: 0.5rem;
}

.stack-list {
  display: grid;
  gap: 0.75rem;
}

.list-row {
  display: flex;
  justify-content: space-between;
  gap: 0.75rem;
  align-items: flex-start;
  padding: 0.8rem 0;
  border-top: 1px solid #edf2fb;
}

.list-row:first-child {
  border-top: none;
  padding-top: 0;
}

.detail-list {
  display: grid;
  gap: 0.75rem;
}

.detail-list > div {
  display: grid;
  gap: 0.25rem;
}

.detail-list span {
  font-size: 0.88rem;
  color: #5f708c;
}

.compact-detail-list {
  gap: 0.6rem;
}

.two-column-detail-list {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.spaced-detail-list {
  margin-top: 1rem;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.9rem;
}

.compact-form-grid {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.form-grid label,
.form-span-2 {
  display: grid;
  gap: 0.35rem;
}

.form-span-2 {
  grid-column: 1 / -1;
}

input,
select,
textarea {
  width: 100%;
  border: 1px solid #ccd8ee;
  border-radius: 0.85rem;
  padding: 0.8rem 0.9rem;
  background: #fbfcff;
  color: #172033;
}

input:focus,
select:focus,
textarea:focus {
  outline: 3px solid rgba(37, 99, 235, 0.14);
  border-color: #78a6f8;
}

.toggle-stack,
.toggle-grid {
  display: grid;
  gap: 0.7rem;
}

.toggle-grid {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.toggle-row {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  padding: 0.7rem 0.1rem;
}

.toggle-row input[type="checkbox"] {
  width: auto;
}

.status-banner {
  padding: 0.8rem 0.95rem;
  background: #f3f7fd;
  border: 1px solid #dae4f5;
  border-radius: 0.95rem;
  color: #31405e;
}

.muted-text {
  color: #6a7a96;
  font-size: 0.92rem;
}

.directory-grid {
  display: grid;
  gap: 1rem;
}

.workspace-directory-card {
  border: 1px solid #d8e2f2;
  border-radius: 1rem;
  padding: 1rem;
  background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
  display: grid;
  gap: 0.9rem;
}

.workspace-directory-card.active {
  border-color: #8db4ff;
  box-shadow: inset 0 0 0 1px rgba(37, 99, 235, 0.1);
}

.tag-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.45rem;
}

.compact-tags {
  margin-top: 0.25rem;
}

.tag {
  display: inline-flex;
  align-items: center;
  padding: 0.28rem 0.58rem;
  border-radius: 999px;
  background: #edf3ff;
  border: 1px solid #d6e2ff;
  color: #34508c;
  font-size: 0.8rem;
}

.sequence-list {
  display: grid;
  gap: 0.95rem;
}

.sequence-row {
  border: 1px solid #deebf9;
  border-radius: 1rem;
  padding: 0.95rem;
  background: #fbfdff;
}

.sequence-row-header {
  display: flex;
  justify-content: space-between;
  gap: 0.8rem;
  align-items: flex-start;
  margin-bottom: 0.8rem;
}

.spacing-top {
  margin-top: 1.2rem;
}

@media (max-width: 1280px) {
  .card-grid-5 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }

  .compact-form-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 1120px) {
  .card-grid,
  .card-grid-5,
  .split-grid {
    grid-template-columns: 1fr 1fr;
  }
}

@media (max-width: 920px) {
  .app-shell {
    grid-template-columns: 1fr;
  }

  .sidebar {
    border-right: none;
    border-bottom: 1px solid rgba(15, 23, 42, 0.12);
  }

  .workspace {
    padding: 1.25rem;
  }

  .workspace-header,
  .hero-card,
  .split-grid,
  .card-grid,
  .card-grid-5,
  .form-grid,
  .compact-form-grid,
  .toggle-grid,
  .two-column-detail-list,
  .sidebar-metadata-grid {
    grid-template-columns: 1fr;
    display: grid;
  }

  .workspace-header {
    gap: 1rem;
  }

  .hero-card {
    align-items: stretch;
  }
}

.card-grid-4 {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.catalog-primary-grid,
.catalog-secondary-grid {
  grid-template-columns: 1.4fr 1fr;
}

.catalog-filter-bar {
  display: grid;
  grid-template-columns: minmax(0, 1.8fr) 180px auto;
  gap: 0.75rem;
  margin-bottom: 1rem;
  align-items: center;
}

.inline-toggle {
  min-height: 100%;
  padding: 0.7rem 0.85rem;
  border: 1px solid #d9e4f6;
  border-radius: 0.85rem;
  background: #fbfdff;
}

.catalog-list {
  display: grid;
  gap: 0.9rem;
}

.catalog-item-card {
  border: 1px solid #dbe5f5;
  border-radius: 1rem;
  padding: 1rem;
  background: linear-gradient(180deg, #ffffff 0%, #f9fbff 100%);
}

.catalog-item-description {
  margin: 0.65rem 0 0;
  color: #43516b;
  font-size: 0.94rem;
}

.compact-stack-list {
  gap: 0.55rem;
}

@media (max-width: 1280px) {
  .card-grid-4 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 1120px) {
  .catalog-primary-grid,
  .catalog-secondary-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 920px) {
  .catalog-filter-bar,
  .card-grid-4 {
    grid-template-columns: 1fr;
  }
}

.checkbox-field {
  display: flex;
  align-items: center;
  gap: 0.65rem;
}

.checkbox-field input[type="checkbox"] {
  width: auto;
}

.compact-checkbox {
  min-height: 100%;
  padding: 0.7rem 0.85rem;
  border: 1px solid #d9e4f6;
  border-radius: 0.85rem;
  background: #fbfdff;
}

.small-button {
  padding: 0.45rem 0.7rem;
  font-size: 0.86rem;
}

.inventory-main-grid,
.inventory-form-grid {
  grid-template-columns: 1.2fr 1fr;
}

.inventory-toolbar {
  display: grid;
  grid-template-columns: minmax(0, 1.8fr) auto;
  gap: 0.75rem;
  align-items: center;
  margin-bottom: 1rem;
}

.inventory-item-list,
.inventory-movement-list {
  gap: 0.9rem;
}

.inventory-item-row,
.inventory-movement-row {
  border-top: 1px solid #edf2fb;
}

.inventory-inline-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 0.45rem;
  margin-top: 0.4rem;
}

.inventory-qty-block {
  min-width: 132px;
  display: grid;
  justify-items: end;
  gap: 0.25rem;
  text-align: right;
}

.qty-positive {
  color: #0f7a37;
}

.qty-negative {
  color: #be2e2e;
}

@media (max-width: 1120px) {
  .inventory-main-grid,
  .inventory-form-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 920px) {
  .inventory-toolbar {
    grid-template-columns: 1fr;
  }

  .inventory-qty-block {
    justify-items: start;
    text-align: left;
    min-width: 0;
  }
}

.summary-chip {
  display: grid;
  gap: 0.15rem;
  min-width: 140px;
  padding: 0.8rem 0.95rem;
  border: 1px solid #dce7f7;
  border-radius: 1rem;
  background: rgba(255, 255, 255, 0.82);
  box-shadow: 0 12px 24px rgba(22, 33, 59, 0.06);
}

.summary-chip strong {
  font-size: 1rem;
}

.summary-chip span {
  color: #5a6b88;
  font-size: 0.82rem;
}

.pos-layout {
  grid-template-columns: 1.2fr 1fr;
}

.pos-item-browser,
.pos-cart-card {
  min-height: 100%;
}

.pos-item-list {
  display: grid;
  gap: 0.8rem;
  margin-top: 1rem;
  max-height: 720px;
  overflow: auto;
  padding-right: 0.15rem;
}

.pos-item-card {
  width: 100%;
  display: flex;
  align-items: start;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.9rem 1rem;
  border: 1px solid #d9e4f6;
  border-radius: 0.95rem;
  background: linear-gradient(180deg, #ffffff 0%, #f7fbff 100%);
  cursor: pointer;
  text-align: left;
}

.pos-item-card:hover {
  border-color: #a7c4ff;
  transform: translateY(-1px);
}

.pos-item-meta {
  display: grid;
  justify-items: end;
  gap: 0.25rem;
  text-align: right;
}

.pos-item-meta span {
  font-weight: 700;
  color: #14213d;
}

.pos-item-meta small {
  color: #5d6f8d;
}

.pos-cart-line {
  display: grid;
  gap: 0.9rem;
  padding: 0.95rem 0;
  border-top: 1px solid #edf2fb;
}

.pos-cart-line:first-child {
  border-top: 0;
  padding-top: 0;
}

.pos-cart-line-main {
  display: grid;
  gap: 0.3rem;
}

.pos-cart-line-fields {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 0.8rem;
}

.pos-cart-line-fields label {
  display: grid;
  gap: 0.35rem;
}

.pos-cart-line-total {
  display: flex;
  flex-wrap: wrap;
  gap: 0.7rem;
  align-items: center;
  justify-content: space-between;
}

.pos-cart-form-grid {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.pos-payment-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.75rem;
}

.pos-payment-row {
  display: grid;
  grid-template-columns: 1.1fr 0.9fr 1.1fr auto;
  gap: 0.75rem;
  align-items: end;
}

.pos-summary-list {
  display: grid;
  gap: 0.5rem;
}

.pos-summary-list > div {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.55rem 0;
  border-top: 1px solid #edf2fb;
}

.pos-summary-list > div:first-child {
  border-top: 0;
}

.compact-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.55rem;
}

.align-right-text {
  text-align: right;
}

.align-start {
  align-items: start;
}

.receipt-preview-layout {
  grid-template-columns: 1fr 0.9fr;
}

.receipt-preview {
  padding: 1rem;
  border: 1px dashed #c8d5ea;
  border-radius: 1rem;
  background: #fbfdff;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

.receipt-preview-title {
  font-size: 1rem;
  font-weight: 700;
}

.receipt-preview-subtitle {
  margin-top: 0.35rem;
  color: #5d6f8d;
  font-size: 0.9rem;
}

.receipt-preview-divider {
  margin: 0.85rem 0;
  border-top: 1px dashed #bcc7d9;
}

.compact-stack {
  display: grid;
  gap: 0.5rem;
}

.compact-detail-list {
  display: grid;
  gap: 0.55rem;
}

.compact-detail-list > div {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}

@media (max-width: 1240px) {
  .pos-layout,
  .receipt-preview-layout {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 980px) {
  .pos-cart-line-fields,
  .pos-cart-form-grid,
  .pos-payment-row {
    grid-template-columns: 1fr;
  }

  .pos-item-card,
  .pos-cart-line-total,
  .pos-payment-header,
  .compact-detail-list > div,
  .pos-summary-list > div {
    align-items: start;
    justify-content: start;
  }

  .pos-item-meta,
  .align-right-text {
    justify-items: start;
    text-align: left;
  }
}

.dashboard-summary-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 0.9rem;
}

.dashboard-primary-grid {
  grid-template-columns: 1.2fr 0.9fr;
}

.dashboard-secondary-grid {
  grid-template-columns: 1fr 1fr;
}

.dashboard-actions-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.85rem;
  margin: 1rem 0;
}

.dashboard-action-card,
.dashboard-watch-card,
.dashboard-kpi-card {
  border: 1px solid #dbe5f5;
  border-radius: 1rem;
  padding: 1rem;
  background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
}

.dashboard-action-card {
  display: grid;
  gap: 0.75rem;
  align-content: start;
}

.dashboard-action-card .card-note {
  margin: 0;
}

.dashboard-watch-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.85rem;
}

.dashboard-watch-card {
  display: grid;
  gap: 0.35rem;
}

.dashboard-watch-card span {
  color: #60708d;
  font-size: 0.88rem;
}

.dashboard-watch-card strong {
  font-size: 1.02rem;
}

.dashboard-watch-card small {
  color: #5d6f8d;
  line-height: 1.45;
}

.dashboard-transaction-row,
.dashboard-low-stock-row {
  align-items: center;
}

.dashboard-transaction-title-row {
  display: flex;
  flex-wrap: wrap;
  gap: 0.55rem;
  align-items: center;
  margin-bottom: 0.3rem;
}

.dashboard-transaction-meta {
  display: grid;
  gap: 0.25rem;
  text-align: right;
  justify-items: end;
  min-width: 180px;
}

.dashboard-kpi-card {
  box-shadow: none;
}

@media (max-width: 1280px) {
  .dashboard-summary-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 1120px) {
  .dashboard-primary-grid,
  .dashboard-secondary-grid,
  .dashboard-watch-grid,
  .dashboard-actions-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 920px) {
  .dashboard-summary-grid {
    grid-template-columns: 1fr;
  }

  .dashboard-transaction-meta {
    justify-items: start;
    text-align: left;
    min-width: 0;
  }
}

```


# FILE: files/src-tauri/Cargo.toml

```
[package]
name = "local-business-manager"
version = "0.6.0"
description = "Local-first business management desktop app dashboard and daily ops MVP"
authors = ["OpenAI"]
edition = "2021"

[lib]
name = "local_business_manager"
crate-type = ["staticlib", "cdylib", "rlib"]

[build-dependencies]
tauri-build = { version = "2.0.0", features = [] }

[dependencies]
chrono = { version = "0.4.38", features = ["serde"] }
rusqlite = { version = "0.32.1", features = ["bundled"] }
serde = { version = "1.0.215", features = ["derive"] }
serde_json = "1.0.133"
sha2 = "0.10.8"
tauri = { version = "2.0.0", features = [] }
uuid = { version = "1.11.0", features = ["v4", "serde"] }

```


# FILE: files/src-tauri/src/commands/bootstrap.rs

```
use tauri::AppHandle;

use crate::{
    core::{catalog, dashboard, db, error::CommandResult, inventory, pos},
    domain::bootstrap::build_app_bootstrap,
};

#[tauri::command]
pub fn bootstrap_app(app: AppHandle) -> CommandResult<crate::domain::models::AppBootstrap> {
    db::with_connection(&app, |conn, paths| {
        let app_info = db::load_app_info(conn)?;
        let active_business = db::get_active_business(conn)?;
        let business_settings = db::get_business_settings(conn, &active_business.id)?;
        let active_tax_profile = db::get_default_tax_profile(conn, &active_business.id)?;
        let active_receipt_profile = db::get_default_receipt_profile(conn, &active_business.id)?;
        let active_module_flags = db::get_module_flags(conn, &active_business.id)?;
        let active_sequences = db::list_sequence_counters(conn, &active_business.id)?;
        let businesses = db::list_businesses(conn)?;
        let business_workspaces = db::list_business_workspace_summaries(conn)?;
        let patch_history = db::list_patch_history(conn)?;
        let backups = db::list_backups(conn)?;
        let storage = db::build_storage_status(conn, paths)?;
        let recent_activity = db::list_recent_activity(conn, 10)?;
        let catalog_summary = catalog::build_catalog_summary(conn, &active_business.id)?;
        let inventory_summary = inventory::build_inventory_summary(conn, &active_business.id)?;
        let pos_summary = pos::build_pos_summary(conn, &active_business.id)?;
        let dashboard_daily_summary =
            dashboard::build_daily_summary(&catalog_summary, &inventory_summary, &pos_summary);
        let dashboard_recent_transactions =
            dashboard::list_recent_transactions(conn, &active_business.id, 8)?;
        let dashboard_low_stock_alerts =
            dashboard::list_low_stock_alerts(conn, &active_business.id, 8)?;
        let dashboard_ops_snapshot = dashboard::build_ops_snapshot(conn, &active_business.id)?;

        Ok(build_app_bootstrap(
            app_info,
            active_business,
            business_settings,
            active_tax_profile,
            active_receipt_profile,
            active_module_flags,
            active_sequences,
            businesses,
            business_workspaces,
            patch_history,
            backups,
            storage,
            recent_activity,
            catalog_summary,
            inventory_summary,
            pos_summary,
            dashboard_daily_summary,
            dashboard_recent_transactions,
            dashboard_low_stock_alerts,
            dashboard_ops_snapshot,
        ))
    })
}

```


# FILE: files/src-tauri/src/core/dashboard.rs

```
use rusqlite::{params, Connection, OptionalExtension, Row};

use crate::domain::models::{
    CatalogSummary, DashboardDailySummary, DashboardLowStockAlert, DashboardOpsSnapshot,
    DashboardRecentTransaction, InventorySummary, PosSummary,
};

use super::error::to_command_error;

fn recent_transaction_from_row(row: &Row) -> rusqlite::Result<DashboardRecentTransaction> {
    Ok(DashboardRecentTransaction {
        sale_id: row.get(0)?,
        sale_number: row.get(1)?,
        payment_status: row.get(2)?,
        total_amount: row.get(3)?,
        amount_paid: row.get(4)?,
        balance_due: row.get(5)?,
        item_count: row.get::<_, i64>(6)? as usize,
        completed_at: row.get(7)?,
    })
}

fn low_stock_alert_from_row(row: &Row) -> rusqlite::Result<DashboardLowStockAlert> {
    let stock_quantity: f64 = row.get(5)?;
    let reorder_level: f64 = row.get(6)?;
    Ok(DashboardLowStockAlert {
        item_id: row.get(0)?,
        item_name: row.get(1)?,
        sku: row.get(2)?,
        category_name: row.get(3)?,
        unit_code: row.get(4)?,
        stock_quantity,
        reorder_level,
        shortage_quantity: (reorder_level - stock_quantity).max(0.0),
        updated_at: row.get(7)?,
    })
}

pub fn build_daily_summary(
    catalog_summary: &CatalogSummary,
    inventory_summary: &InventorySummary,
    pos_summary: &PosSummary,
) -> DashboardDailySummary {
    DashboardDailySummary {
        today_sale_count: pos_summary.today_sale_count,
        today_gross_sales: pos_summary.today_gross_sales,
        today_collected_amount: pos_summary.today_collected_amount,
        today_due_amount: pos_summary.today_due_amount,
        held_sale_count: pos_summary.held_sale_count,
        low_stock_count: inventory_summary.low_stock_items,
        average_sale_value: pos_summary.average_sale_value,
        total_tracked_items: inventory_summary.total_tracked_items,
        active_catalog_items: catalog_summary.active_items,
    }
}

pub fn list_recent_transactions(
    conn: &Connection,
    business_id: &str,
    limit: usize,
) -> Result<Vec<DashboardRecentTransaction>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, sale_number, payment_status, total_amount, amount_paid, balance_due, item_count, completed_at
             FROM sales
             WHERE business_id = ?1
               AND sale_status = 'completed'
             ORDER BY completed_at DESC, created_at DESC
             LIMIT ?2",
        )
        .map_err(|error| to_command_error("failed to prepare recent transaction query", error))?;

    let rows = stmt
        .query_map(params![business_id, limit as i64], recent_transaction_from_row)
        .map_err(|error| to_command_error("failed to query recent transactions", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map recent transactions", error))
}

pub fn list_low_stock_alerts(
    conn: &Connection,
    business_id: &str,
    limit: usize,
) -> Result<Vec<DashboardLowStockAlert>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT
                i.id,
                i.name,
                i.sku,
                c.name,
                u.code,
                i.stock_quantity,
                i.reorder_level,
                i.updated_at
             FROM catalog_items i
             LEFT JOIN catalog_categories c ON c.id = i.category_id
             LEFT JOIN catalog_units u ON u.id = i.unit_id
             WHERE i.business_id = ?1
               AND i.archived_at IS NULL
               AND i.item_kind = 'stock'
               AND i.track_stock = 1
               AND i.reorder_level > 0
               AND i.stock_quantity <= i.reorder_level
             ORDER BY
                (i.reorder_level - i.stock_quantity) DESC,
                i.updated_at DESC,
                i.name COLLATE NOCASE ASC
             LIMIT ?2",
        )
        .map_err(|error| to_command_error("failed to prepare low stock alert query", error))?;

    let rows = stmt
        .query_map(params![business_id, limit as i64], low_stock_alert_from_row)
        .map_err(|error| to_command_error("failed to query low stock alerts", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map low stock alerts", error))
}

pub fn build_ops_snapshot(
    conn: &Connection,
    business_id: &str,
) -> Result<DashboardOpsSnapshot, String> {
    let (open_due_sale_count, open_due_amount): (usize, f64) = conn
        .query_row(
            "SELECT COUNT(*), COALESCE(SUM(balance_due), 0)
             FROM sales
             WHERE business_id = ?1
               AND sale_status = 'completed'
               AND balance_due > 0.000001",
            params![business_id],
            |row| Ok((row.get::<_, i64>(0)? as usize, row.get(1)?)),
        )
        .map_err(|error| to_command_error("failed to summarize open dues", error))?;

    let backup_count: usize = conn
        .query_row("SELECT COUNT(*) FROM backup_records", [], |row| {
            row.get::<_, i64>(0)
        })
        .map_err(|error| to_command_error("failed to count backups", error))?
        as usize;

    let export_count: usize = conn
        .query_row("SELECT COUNT(*) FROM export_jobs", [], |row| row.get::<_, i64>(0))
        .map_err(|error| to_command_error("failed to count exports", error))?
        as usize;

    let last_backup_at = conn
        .query_row(
            "SELECT created_at FROM backup_records ORDER BY created_at DESC LIMIT 1",
            [],
            |row| row.get::<_, String>(0),
        )
        .optional()
        .map_err(|error| to_command_error("failed to load last backup timestamp", error))?;

    let last_export_at = conn
        .query_row(
            "SELECT COALESCE(completed_at, created_at) FROM export_jobs ORDER BY COALESCE(completed_at, created_at) DESC LIMIT 1",
            [],
            |row| row.get::<_, String>(0),
        )
        .optional()
        .map_err(|error| to_command_error("failed to load last export timestamp", error))?;

    let last_sale_at = conn
        .query_row(
            "SELECT completed_at
             FROM sales
             WHERE business_id = ?1
               AND sale_status = 'completed'
             ORDER BY completed_at DESC, created_at DESC
             LIMIT 1",
            params![business_id],
            |row| row.get::<_, String>(0),
        )
        .optional()
        .map_err(|error| to_command_error("failed to load last sale timestamp", error))?;

    Ok(DashboardOpsSnapshot {
        open_due_sale_count,
        open_due_amount,
        backup_count,
        export_count,
        last_backup_at,
        last_export_at,
        last_sale_at,
    })
}

```


# FILE: files/src-tauri/src/core/mod.rs

```
pub mod dashboard;
pub mod catalog;
pub mod db;
pub mod error;
pub mod inventory;
pub mod migrations;
pub mod patching;
pub mod paths;
pub mod pos;
pub mod seed;

```


# FILE: files/src-tauri/src/core/patching.rs

```
use chrono::Utc;
use rusqlite::{params, Connection};
use serde_json::json;

use super::migrations::CURRENT_SCHEMA_VERSION;

struct PatchDefinition {
    patch_id: &'static str,
    patch_name: &'static str,
    schema_version: i64,
    notes: &'static str,
}

const PATCHES: [PatchDefinition; 6] = [
    PatchDefinition {
        patch_id: "P001_foundation_base_structure",
        patch_name: "Foundation Base Structure",
        schema_version: 1,
        notes: "Initial desktop foundation with local storage, business/settings shell, backup/export foundation.",
    },
    PatchDefinition {
        patch_id: "P002_multi_business_workspace_settings_core",
        patch_name: "Multi-Business Workspace & Settings Core",
        schema_version: 2,
        notes: "Adds multi-business switching, business-scoped settings profiles, normalized module flags, receipt profiles, tax profiles, and sequence counters.",
    },
    PatchDefinition {
        patch_id: "P003_catalog_core",
        patch_name: "Catalog Core",
        schema_version: 3,
        notes: "Adds categories, units, item master data, barcode foundations, and catalog-aware export scope for local businesses.",
    },
    PatchDefinition {
        patch_id: "P004_inventory_ledger_core",
        patch_name: "Inventory Ledger Core",
        schema_version: 4,
        notes: "Adds stock movement history, on-hand stock balances, reorder monitoring, and inventory-aware export data.",
    },
    PatchDefinition {
        patch_id: "P005_pos_checkout_core",
        patch_name: "POS Checkout Core",
        schema_version: 5,
        notes: "Adds local checkout with held carts, completed sales, payment capture, receipt-ready sale history, and stock deduction through the existing inventory ledger.",
    },
    PatchDefinition {
        patch_id: "P006_dashboard_daily_ops_mvp",
        patch_name: "Dashboard & Daily Ops MVP",
        schema_version: 5,
        notes: "Elevates the home screen into a daily operations workspace with today’s sales pulse, quick actions, recent transactions, low-stock watchlists, due tracking, and backup/export visibility.",
    },
];

pub const PATCH_ID: &str = "P006_dashboard_daily_ops_mvp";
pub const PATCH_NAME: &str = "Dashboard & Daily Ops MVP";
pub const APP_VERSION: &str = "0.6.0";

pub fn register_patch(conn: &Connection) -> rusqlite::Result<()> {
    for patch in PATCHES {
        let now = Utc::now().to_rfc3339();
        let manifest = json!({
            "patch_id": patch.patch_id,
            "patch_name": patch.patch_name,
            "schema_version": patch.schema_version,
            "applied_at": now.clone(),
            "notes": patch.notes,
        });

        conn.execute(
            "INSERT OR IGNORE INTO patch_history (patch_id, patch_name, schema_version, applied_at, manifest_json)
             VALUES (?1, ?2, ?3, ?4, ?5)",
            params![
                patch.patch_id,
                patch.patch_name,
                patch.schema_version,
                now,
                manifest.to_string()
            ],
        )?;
    }

    let now = Utc::now().to_rfc3339();

    conn.execute(
        "INSERT INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        params![
            "schema_version",
            CURRENT_SCHEMA_VERSION.to_string(),
            now.clone()
        ],
    )?;

    conn.execute(
        "INSERT INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        params!["patch_level", PATCH_ID, now.clone()],
    )?;

    conn.execute(
        "INSERT INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        params!["app_version", APP_VERSION, now],
    )?;

    Ok(())
}

```


# FILE: files/src-tauri/src/domain/bootstrap.rs

```
use super::models::{
    AppBootstrap, AppInfo, BackupRecord, BusinessProfile, BusinessSettings,
    BusinessWorkspaceSummary, CatalogSummary, DashboardDailySummary, DashboardLowStockAlert,
    DashboardOpsSnapshot, DashboardRecentTransaction, DashboardShellData, InventorySummary,
    KpiCard, ModuleFlags, ModuleStatus, PatchRecord, PosSummary, ReceiptProfile, RecentActivity,
    SequenceCounter, StorageStatus, TaxProfile,
};

fn active_module_count(module_flags: &ModuleFlags) -> usize {
    [
        module_flags.restaurant_enabled,
        module_flags.retail_enabled,
        module_flags.inventory_enabled,
        module_flags.services_enabled,
        module_flags.customers_enabled,
        module_flags.suppliers_enabled,
        module_flags.expenses_enabled,
        module_flags.reporting_enabled,
        module_flags.data_center_enabled,
    ]
    .into_iter()
    .filter(|enabled| *enabled)
    .count()
}

#[allow(clippy::too_many_arguments)]
pub fn compose_dashboard(
    business_workspaces: &[BusinessWorkspaceSummary],
    active_business: &BusinessProfile,
    active_modules: &ModuleFlags,
    active_sequences: &[SequenceCounter],
    backups: &[BackupRecord],
    recent_activity: Vec<RecentActivity>,
    patch_history: &[PatchRecord],
    storage: &StorageStatus,
    catalog_summary: &CatalogSummary,
    inventory_summary: &InventorySummary,
    pos_summary: &PosSummary,
    daily_summary: DashboardDailySummary,
    recent_transactions: Vec<DashboardRecentTransaction>,
    low_stock_alerts: Vec<DashboardLowStockAlert>,
    ops_snapshot: DashboardOpsSnapshot,
) -> DashboardShellData {
    DashboardShellData {
        hero_title: "Daily operations dashboard is ready".into(),
        hero_body: format!(
            "Patch 6 turns the local foundation into a practical daily workspace for {} with today’s sales pulse, recent transactions, low-stock watchlists, due tracking, and quick actions for checkout, stock updates, backup, and export.",
            active_business.name
        ),
        kpis: vec![
            KpiCard {
                id: "workspace-count".into(),
                label: "Business workspaces".into(),
                value: business_workspaces.len().to_string(),
                note: "Each business keeps isolated profiles, settings, sequences, and local data boundaries.".into(),
            },
            KpiCard {
                id: "catalog-items".into(),
                label: "Active catalog items".into(),
                value: catalog_summary.active_items.to_string(),
                note: format!(
                    "{} categories support menu, stock, and service records inside the local catalog.",
                    catalog_summary.category_count
                ),
            },
            KpiCard {
                id: "tracked-stock".into(),
                label: "Tracked stock items".into(),
                value: inventory_summary.total_tracked_items.to_string(),
                note: format!(
                    "{} items are currently at or below reorder level.",
                    inventory_summary.low_stock_items
                ),
            },
            KpiCard {
                id: "inventory-movements".into(),
                label: "Inventory movements".into(),
                value: inventory_summary.movement_count.to_string(),
                note: "Opening balances, manual adjustments, and POS deductions share one movement ledger.".into(),
            },
            KpiCard {
                id: "completed-sales".into(),
                label: "Completed sales".into(),
                value: pos_summary.completed_sale_count.to_string(),
                note: format!(
                    "{} held carts remain available to resume locally.",
                    pos_summary.held_sale_count
                ),
            },
            KpiCard {
                id: "average-sale-value".into(),
                label: "Average sale value".into(),
                value: format!("{} {:.2}", active_business.currency_code, pos_summary.average_sale_value),
                note: "Useful for monitoring bill size before customer profiles and advanced reports arrive.".into(),
            },
            KpiCard {
                id: "module-count".into(),
                label: "Active modules".into(),
                value: active_module_count(active_modules).to_string(),
                note: "Workspace, catalog, inventory, POS, dashboard, and data-center foundations are active offline.".into(),
            },
            KpiCard {
                id: "backup-count".into(),
                label: "Local backups".into(),
                value: backups.len().to_string(),
                note: format!(
                    "{} export bundles are recorded under {}.",
                    storage.export_count, storage.export_dir
                ),
            },
            KpiCard {
                id: "sequence-count".into(),
                label: "Sequence counters".into(),
                value: active_sequences.len().to_string(),
                note: "Sale and hold numbering are ready for future purchasing, returns, and customer-linked flows.".into(),
            },
            KpiCard {
                id: "patch-count".into(),
                label: "Applied patches".into(),
                value: patch_history.len().to_string(),
                note: "Patch history stays in the local database for upgrade traceability and rollback planning.".into(),
            },
        ],
        recent_activity,
        module_statuses: vec![
            ModuleStatus {
                id: "workspace".into(),
                label: "Workspace core".into(),
                status: "active-foundation".into(),
                note: "Multi-business profiles, settings, tax defaults, receipts, and sequence counters remain active.".into(),
            },
            ModuleStatus {
                id: "catalog".into(),
                label: "Catalog".into(),
                status: "active-foundation".into(),
                note: "Products, menu items, services, categories, units, and barcodes are available locally.".into(),
            },
            ModuleStatus {
                id: "inventory".into(),
                label: "Inventory ledger".into(),
                status: "active-foundation".into(),
                note: "Stock movements, on-hand balances, reorder alerts, and POS deductions are tracked per business.".into(),
            },
            ModuleStatus {
                id: "pos".into(),
                label: "POS / billing".into(),
                status: "active-foundation".into(),
                note: "Cart building, held carts, sale completion, payment capture, receipt rendering, and recent sale history are available offline.".into(),
            },
            ModuleStatus {
                id: "dashboard".into(),
                label: "Daily ops dashboard".into(),
                status: "active-foundation".into(),
                note: "Today’s sales pulse, low-stock watchlists, pending dues, and backup visibility now sit in one home screen.".into(),
            },
            ModuleStatus {
                id: "customers".into(),
                label: "Customers".into(),
                status: "coming-next".into(),
                note: "The next patch can add customer profiles, sale linking, notes, and repeat-buyer support on top of the current POS workflow.".into(),
            },
        ],
        daily_summary,
        recent_transactions,
        low_stock_alerts,
        ops_snapshot,
    }
}

#[allow(clippy::too_many_arguments)]
pub fn build_app_bootstrap(
    app_info: AppInfo,
    active_business: BusinessProfile,
    business_settings: BusinessSettings,
    active_tax_profile: TaxProfile,
    active_receipt_profile: ReceiptProfile,
    active_module_flags: ModuleFlags,
    active_sequences: Vec<SequenceCounter>,
    businesses: Vec<BusinessProfile>,
    business_workspaces: Vec<BusinessWorkspaceSummary>,
    patch_history: Vec<PatchRecord>,
    backups: Vec<BackupRecord>,
    storage: StorageStatus,
    recent_activity: Vec<RecentActivity>,
    catalog_summary: CatalogSummary,
    inventory_summary: InventorySummary,
    pos_summary: PosSummary,
    dashboard_daily_summary: DashboardDailySummary,
    dashboard_recent_transactions: Vec<DashboardRecentTransaction>,
    dashboard_low_stock_alerts: Vec<DashboardLowStockAlert>,
    dashboard_ops_snapshot: DashboardOpsSnapshot,
) -> AppBootstrap {
    let dashboard = compose_dashboard(
        &business_workspaces,
        &active_business,
        &active_module_flags,
        &active_sequences,
        &backups,
        recent_activity,
        &patch_history,
        &storage,
        &catalog_summary,
        &inventory_summary,
        &pos_summary,
        dashboard_daily_summary,
        dashboard_recent_transactions,
        dashboard_low_stock_alerts,
        dashboard_ops_snapshot,
    );

    AppBootstrap {
        app_info,
        active_business,
        business_settings,
        active_tax_profile,
        active_receipt_profile,
        active_module_flags,
        active_sequences,
        businesses,
        business_workspaces,
        patch_history,
        backups,
        storage,
        catalog_summary,
        inventory_summary,
        pos_summary,
        dashboard,
    }
}

```


# FILE: files/src-tauri/src/domain/models.rs

```
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BusinessProfile {
    pub id: String,
    pub name: String,
    pub legal_name: Option<String>,
    pub code: String,
    pub business_type: String,
    pub currency_code: String,
    pub tax_mode: String,
    pub phone: Option<String>,
    pub email: Option<String>,
    pub address_line1: Option<String>,
    pub address_line2: Option<String>,
    pub city: Option<String>,
    pub state: Option<String>,
    pub postal_code: Option<String>,
    pub country: Option<String>,
    pub created_at: String,
    pub updated_at: String,
    pub archived_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BusinessSettings {
    pub business_id: String,
    pub timezone: String,
    pub locale: String,
    pub date_format: String,
    pub theme: String,
    pub tax_label: String,
    pub default_tax_rate: f64,
    pub prices_include_tax: bool,
    pub receipt_footer: Option<String>,
    pub receipt_show_address: bool,
    pub receipt_show_phone: bool,
    pub auto_backup_enabled: bool,
    pub backup_directory: Option<String>,
    pub module_restaurant_enabled: bool,
    pub module_retail_enabled: bool,
    pub module_inventory_enabled: bool,
    pub module_services_enabled: bool,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TaxProfile {
    pub id: String,
    pub business_id: String,
    pub name: String,
    pub tax_label: String,
    pub default_rate: f64,
    pub prices_include_tax: bool,
    pub is_default: bool,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ReceiptProfile {
    pub id: String,
    pub business_id: String,
    pub name: String,
    pub footer_text: Option<String>,
    pub show_address: bool,
    pub show_phone: bool,
    pub show_email: bool,
    pub show_business_code: bool,
    pub paper_width: String,
    pub is_default: bool,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ModuleFlags {
    pub business_id: String,
    pub restaurant_enabled: bool,
    pub retail_enabled: bool,
    pub inventory_enabled: bool,
    pub services_enabled: bool,
    pub customers_enabled: bool,
    pub suppliers_enabled: bool,
    pub expenses_enabled: bool,
    pub reporting_enabled: bool,
    pub data_center_enabled: bool,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SequenceCounter {
    pub id: String,
    pub business_id: String,
    pub scope: String,
    pub prefix: String,
    pub next_number: i64,
    pub padding: i64,
    pub reset_policy: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NewBusinessWorkspaceInput {
    pub name: String,
    pub legal_name: Option<String>,
    pub code: String,
    pub business_type: String,
    pub currency_code: String,
    pub tax_mode: String,
    pub timezone: String,
    pub locale: String,
    pub activate_now: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WorkspaceConfigurationInput {
    pub business_settings: BusinessSettings,
    pub tax_profile: TaxProfile,
    pub receipt_profile: ReceiptProfile,
    pub module_flags: ModuleFlags,
    pub sequence_counters: Vec<SequenceCounter>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BusinessWorkspaceSummary {
    pub business_id: String,
    pub name: String,
    pub code: String,
    pub business_type: String,
    pub currency_code: String,
    pub theme: String,
    pub timezone: String,
    pub tax_label: String,
    pub default_tax_rate: f64,
    pub next_sale_sequence: String,
    pub active_modules: Vec<String>,
    pub archived_at: Option<String>,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AppInfo {
    pub app_name: String,
    pub product_name: String,
    pub version: String,
    pub schema_version: i64,
    pub patch_level: String,
    pub initialized_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PatchRecord {
    pub patch_id: String,
    pub patch_name: String,
    pub schema_version: i64,
    pub applied_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BackupRecord {
    pub id: String,
    pub business_id: Option<String>,
    pub file_name: String,
    pub file_path: String,
    pub checksum: Option<String>,
    pub status: String,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ExportJobRecord {
    pub id: String,
    pub business_id: Option<String>,
    pub format: String,
    pub status: String,
    pub target_path: Option<String>,
    pub created_at: String,
    pub completed_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ImportPreview {
    pub file_path: String,
    pub valid: bool,
    pub manifest_version: Option<String>,
    pub bundle_type: Option<String>,
    pub source_patch_level: Option<String>,
    pub business_count: usize,
    pub category_count: usize,
    pub item_count: usize,
    pub stock_balance_count: usize,
    pub movement_count: usize,
    pub sale_count: usize,
    pub held_sale_count: usize,
    pub generated_at: Option<String>,
    pub warnings: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RecentActivity {
    pub id: String,
    pub level: String,
    pub category: String,
    pub message: String,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct KpiCard {
    pub id: String,
    pub label: String,
    pub value: String,
    pub note: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ModuleStatus {
    pub id: String,
    pub label: String,
    pub status: String,
    pub note: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardDailySummary {
    pub today_sale_count: usize,
    pub today_gross_sales: f64,
    pub today_collected_amount: f64,
    pub today_due_amount: f64,
    pub held_sale_count: usize,
    pub low_stock_count: usize,
    pub average_sale_value: f64,
    pub total_tracked_items: usize,
    pub active_catalog_items: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardRecentTransaction {
    pub sale_id: String,
    pub sale_number: String,
    pub payment_status: String,
    pub total_amount: f64,
    pub amount_paid: f64,
    pub balance_due: f64,
    pub item_count: usize,
    pub completed_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardLowStockAlert {
    pub item_id: String,
    pub item_name: String,
    pub sku: Option<String>,
    pub category_name: Option<String>,
    pub unit_code: Option<String>,
    pub stock_quantity: f64,
    pub reorder_level: f64,
    pub shortage_quantity: f64,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardOpsSnapshot {
    pub open_due_sale_count: usize,
    pub open_due_amount: f64,
    pub backup_count: usize,
    pub export_count: usize,
    pub last_backup_at: Option<String>,
    pub last_export_at: Option<String>,
    pub last_sale_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardShellData {
    pub hero_title: String,
    pub hero_body: String,
    pub kpis: Vec<KpiCard>,
    pub recent_activity: Vec<RecentActivity>,
    pub module_statuses: Vec<ModuleStatus>,
    pub daily_summary: DashboardDailySummary,
    pub recent_transactions: Vec<DashboardRecentTransaction>,
    pub low_stock_alerts: Vec<DashboardLowStockAlert>,
    pub ops_snapshot: DashboardOpsSnapshot,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct StorageStatus {
    pub data_dir: String,
    pub config_dir: String,
    pub log_dir: String,
    pub backup_dir: String,
    pub export_dir: String,
    pub database_path: String,
    pub database_exists: bool,
    pub backup_count: usize,
    pub export_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogCategory {
    pub id: String,
    pub business_id: String,
    pub name: String,
    pub code: String,
    pub parent_id: Option<String>,
    pub item_scope: String,
    pub sort_order: i64,
    pub notes: Option<String>,
    pub created_at: String,
    pub updated_at: String,
    pub archived_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogUnit {
    pub id: String,
    pub business_id: Option<String>,
    pub name: String,
    pub code: String,
    pub symbol: String,
    pub allow_fractional: bool,
    pub is_system: bool,
    pub updated_at: String,
    pub archived_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogItem {
    pub id: String,
    pub business_id: String,
    pub category_id: Option<String>,
    pub unit_id: Option<String>,
    pub tax_profile_id: Option<String>,
    pub item_kind: String,
    pub name: String,
    pub display_name: Option<String>,
    pub sku: Option<String>,
    pub primary_barcode: Option<String>,
    pub description: Option<String>,
    pub selling_price: f64,
    pub cost_price: f64,
    pub track_stock: bool,
    pub stock_quantity: f64,
    pub reorder_level: f64,
    pub image_path: Option<String>,
    pub is_active: bool,
    pub created_at: String,
    pub updated_at: String,
    pub archived_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogBarcode {
    pub id: String,
    pub item_id: String,
    pub barcode: String,
    pub label: Option<String>,
    pub is_primary: bool,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogItemView {
    pub item: CatalogItem,
    pub category_name: Option<String>,
    pub unit_code: Option<String>,
    pub tax_label: Option<String>,
    pub barcodes: Vec<CatalogBarcode>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogSummary {
    pub total_items: usize,
    pub active_items: usize,
    pub archived_items: usize,
    pub category_count: usize,
    pub menu_item_count: usize,
    pub stock_item_count: usize,
    pub service_item_count: usize,
    pub low_stock_candidates: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogWorkspace {
    pub business_id: String,
    pub summary: CatalogSummary,
    pub categories: Vec<CatalogCategory>,
    pub units: Vec<CatalogUnit>,
    pub tax_profiles: Vec<TaxProfile>,
    pub items: Vec<CatalogItemView>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveCatalogCategoryInput {
    pub id: Option<String>,
    pub name: String,
    pub code: String,
    pub parent_id: Option<String>,
    pub item_scope: String,
    pub sort_order: i64,
    pub notes: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveCatalogUnitInput {
    pub id: Option<String>,
    pub name: String,
    pub code: String,
    pub symbol: String,
    pub allow_fractional: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveCatalogItemInput {
    pub id: Option<String>,
    pub category_id: Option<String>,
    pub unit_id: Option<String>,
    pub tax_profile_id: Option<String>,
    pub item_kind: String,
    pub name: String,
    pub display_name: Option<String>,
    pub sku: Option<String>,
    pub barcodes: Vec<String>,
    pub description: Option<String>,
    pub selling_price: f64,
    pub cost_price: f64,
    pub track_stock: bool,
    pub stock_quantity: f64,
    pub reorder_level: f64,
    pub image_path: Option<String>,
    pub is_active: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InventorySummary {
    pub total_tracked_items: usize,
    pub low_stock_items: usize,
    pub movement_count: usize,
    pub total_quantity_on_hand: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InventoryStockItem {
    pub item_id: String,
    pub item_name: String,
    pub item_kind: String,
    pub sku: Option<String>,
    pub category_name: Option<String>,
    pub unit_code: Option<String>,
    pub track_stock: bool,
    pub stock_quantity: f64,
    pub reorder_level: f64,
    pub low_stock: bool,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InventoryMovement {
    pub id: String,
    pub business_id: String,
    pub item_id: String,
    pub item_name: String,
    pub sku: Option<String>,
    pub unit_code: Option<String>,
    pub movement_type: String,
    pub quantity_delta: f64,
    pub quantity_after: f64,
    pub unit_cost: Option<f64>,
    pub note: Option<String>,
    pub occurred_at: String,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InventoryWorkspace {
    pub business_id: String,
    pub summary: InventorySummary,
    pub stock_items: Vec<InventoryStockItem>,
    pub recent_movements: Vec<InventoryMovement>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveInventoryMovementInput {
    pub item_id: String,
    pub movement_type: String,
    pub quantity: f64,
    pub unit_cost: Option<f64>,
    pub note: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveInventoryStockRuleInput {
    pub item_id: String,
    pub track_stock: bool,
    pub reorder_level: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSummary {
    pub completed_sale_count: usize,
    pub today_sale_count: usize,
    pub held_sale_count: usize,
    pub today_gross_sales: f64,
    pub today_collected_amount: f64,
    pub today_due_amount: f64,
    pub average_sale_value: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSellableItem {
    pub item_id: String,
    pub name: String,
    pub display_name: Option<String>,
    pub item_kind: String,
    pub category_name: Option<String>,
    pub unit_code: Option<String>,
    pub allow_fractional: bool,
    pub sku: Option<String>,
    pub primary_barcode: Option<String>,
    pub selling_price: f64,
    pub track_stock: bool,
    pub on_hand_quantity: f64,
    pub tax_label: Option<String>,
    pub tax_rate: f64,
    pub prices_include_tax: bool,
    pub is_available: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosCartLineInput {
    pub item_id: String,
    pub quantity: f64,
    pub unit_price: Option<f64>,
    pub discount_amount: f64,
    pub notes: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosPaymentEntryInput {
    pub payment_mode: String,
    pub amount: f64,
    pub reference_value: Option<String>,
    pub notes: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SavePosHoldInput {
    pub id: Option<String>,
    pub hold_label: String,
    pub notes: Option<String>,
    pub cart_lines: Vec<PosCartLineInput>,
    pub cart_discount_amount: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CompletePosSaleInput {
    pub hold_id: Option<String>,
    pub notes: Option<String>,
    pub cart_lines: Vec<PosCartLineInput>,
    pub cart_discount_amount: f64,
    pub payments: Vec<PosPaymentEntryInput>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosHoldSummary {
    pub id: String,
    pub business_id: String,
    pub hold_code: String,
    pub hold_label: String,
    pub item_count: usize,
    pub subtotal_amount: f64,
    pub discount_amount: f64,
    pub tax_amount: f64,
    pub total_amount: f64,
    pub notes: Option<String>,
    pub cart_lines: Vec<PosCartLineInput>,
    pub cart_discount_amount: f64,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSaleRecord {
    pub id: String,
    pub business_id: String,
    pub register_session_id: Option<String>,
    pub sale_number: String,
    pub sale_status: String,
    pub payment_status: String,
    pub currency_code: String,
    pub subtotal_amount: f64,
    pub discount_amount: f64,
    pub tax_amount: f64,
    pub total_amount: f64,
    pub amount_paid: f64,
    pub balance_due: f64,
    pub item_count: usize,
    pub notes: Option<String>,
    pub completed_at: String,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSaleLine {
    pub id: String,
    pub sale_id: String,
    pub item_id: Option<String>,
    pub item_name: String,
    pub item_kind: String,
    pub category_name: Option<String>,
    pub sku: Option<String>,
    pub primary_barcode: Option<String>,
    pub unit_code: Option<String>,
    pub tax_label: Option<String>,
    pub tax_rate: f64,
    pub prices_include_tax: bool,
    pub quantity: f64,
    pub unit_price: f64,
    pub gross_amount: f64,
    pub discount_amount: f64,
    pub net_amount: f64,
    pub tax_amount: f64,
    pub total_amount: f64,
    pub notes: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSalePayment {
    pub id: String,
    pub sale_id: String,
    pub payment_mode: String,
    pub amount: f64,
    pub reference_value: Option<String>,
    pub notes: Option<String>,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSaleDetail {
    pub sale: PosSaleRecord,
    pub lines: Vec<PosSaleLine>,
    pub payments: Vec<PosSalePayment>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosWorkspace {
    pub business_id: String,
    pub summary: PosSummary,
    pub register_label: Option<String>,
    pub sellable_items: Vec<PosSellableItem>,
    pub held_sales: Vec<PosHoldSummary>,
    pub recent_sales: Vec<PosSaleRecord>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RegisterSession {
    pub id: String,
    pub business_id: String,
    pub label: String,
    pub status: String,
    pub opened_at: String,
    pub closed_at: Option<String>,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AppBootstrap {
    pub app_info: AppInfo,
    pub active_business: BusinessProfile,
    pub business_settings: BusinessSettings,
    pub active_tax_profile: TaxProfile,
    pub active_receipt_profile: ReceiptProfile,
    pub active_module_flags: ModuleFlags,
    pub active_sequences: Vec<SequenceCounter>,
    pub businesses: Vec<BusinessProfile>,
    pub business_workspaces: Vec<BusinessWorkspaceSummary>,
    pub patch_history: Vec<PatchRecord>,
    pub backups: Vec<BackupRecord>,
    pub storage: StorageStatus,
    pub catalog_summary: CatalogSummary,
    pub inventory_summary: InventorySummary,
    pub pos_summary: PosSummary,
    pub dashboard: DashboardShellData,
}

```


# FILE: files/src-tauri/tauri.conf.json

```
{
  "$schema": "https://schema.tauri.app/config/2",
  "productName": "Local Business Manager",
  "version": "0.6.0",
  "identifier": "com.localfirst.businessmanager",
  "build": {
    "beforeBuildCommand": "npm run build",
    "beforeDevCommand": "npm run dev",
    "devUrl": "http://localhost:5173",
    "frontendDist": "../dist"
  },
  "app": {
    "windows": [
      {
        "label": "main",
        "title": "Local Business Manager",
        "width": 1380,
        "height": 860,
        "minWidth": 1100,
        "minHeight": 720,
        "resizable": true
      }
    ],
    "security": {
      "csp": null
    }
  },
  "bundle": {
    "active": false
  }
}

```


# FILE: migrations/MIGRATION_NOTES.md

```
# Migration Notes

Patch 6 does not include a new SQL migration file.

## Database impact

- `PRAGMA user_version` stays at `5`
- no tables are added
- no columns are added
- no indexes are added

## Runtime metadata updates

On app startup after Patch 6 is applied:

- `patch_history` receives `P006_dashboard_daily_ops_mvp`
- `app_meta.patch_level` is updated to `P006_dashboard_daily_ops_mvp`
- `app_meta.app_version` is updated to `0.6.0`

## Derived dashboard data

The new dashboard views are computed from existing tables introduced in earlier patches:

- `sales`
- `sale_holds`
- `backup_records`
- `export_jobs`
- `catalog_items`
- `inventory_stock_movements`

```


# FILE: patch-manifest.json

```
{
  "patch_id": "P006_dashboard_daily_ops_mvp",
  "patch_name": "Dashboard & Daily Ops MVP",
  "base_version": "0.5.0",
  "target_version": "0.6.0",
  "description": "Elevates the home screen into a practical daily operations workspace with today's sales pulse, recent transactions, low-stock watchlists, due tracking, and quick actions for checkout, stock updates, backup, and export.",
  "dependencies": [
    "P005_pos_checkout_core"
  ],
  "safe_on_empty_project": false,
  "migration_required": false,
  "rollback_supported": true,
  "files_root": "files",
  "post_apply_steps": [
    "cd <target>",
    "npm install",
    "npm run validate:patch6",
    "npm run tauri dev"
  ]
}

```


# FILE: rollback.md

```
# Rollback Notes

This patch does not change the database schema, so rollback is file-based.

## Recommended rollback

1. restore your project from source control, or
2. restore overwritten files from:

```text
.patch-backups/P006_dashboard_daily_ops_mvp/
```

## Notes

- no SQL rollback is required
- no table/data migration rollback is required
- if you created new backups or exports while testing Patch 6, those local artifacts remain on disk unless you remove them manually

```


# FILE: validate.md

```
# Validation Checklist

- [ ] Patch applies cleanly on top of a Patch 5 project
- [ ] `npm install` completes
- [ ] `npm run validate:patch6` passes
- [ ] `npm run tauri dev` launches the desktop shell
- [ ] Dashboard shows daily summary chips
- [ ] Dashboard shows quick actions
- [ ] Dashboard shows recent transactions
- [ ] Dashboard shows low-stock alerts when applicable
- [ ] Backup quick action creates a local snapshot and refreshes the dashboard
- [ ] Export quick action creates a local bundle and refreshes the dashboard
- [ ] Sidebar and header show Patch 6 daily-ops messaging

```
