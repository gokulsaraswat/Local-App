# Patch 6 - Dashboard & Daily Ops MVP

Patch ID: `P006_dashboard_daily_ops_mvp`

## Goal

Turn the existing local foundation into a more practical daily-use home workspace by improving the dashboard and surfacing operational data that a restaurant, cafe, bakery, retail store, or inventory-led business needs during routine day-to-day work.

## What this patch adds

- stronger dashboard/home workspace
- daily sales pulse cards
- recent transaction list
- low-stock alert watchlist
- open-due visibility for completed sales with outstanding balance
- quick actions for POS, inventory, catalog, settings, backup, and export
- latest backup / export / sale visibility
- updated app shell messaging for the daily operations milestone
- patch metadata bumped to Patch 6 / version 0.6.0

## What this patch does not add

- no customer module yet
- no returns/refunds yet
- no supplier or purchasing module yet
- no schema changes or new database tables
- no advanced reporting module yet

## Data model impact

This patch does **not** change the SQLite schema.

It adds richer in-memory/bootstrap dashboard view models:

- `DashboardDailySummary`
- `DashboardRecentTransaction`
- `DashboardLowStockAlert`
- `DashboardOpsSnapshot`

These are derived from existing Patch 1-5 tables and returned through the bootstrap payload.

## Files changed in this patch

- `package.json`
- `scripts/validate-patch6.mjs`
- `src/app/AppProvider.tsx`
- `src/modules/dashboard/DashboardPage.tsx`
- `src/modules/shell/AppShell.tsx`
- `src/shared/types.ts`
- `src/styles.css`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src-tauri/src/commands/bootstrap.rs`
- `src-tauri/src/core/dashboard.rs`
- `src-tauri/src/core/mod.rs`
- `src-tauri/src/core/patching.rs`
- `src-tauri/src/domain/bootstrap.rs`
- `src-tauri/src/domain/models.rs`

## Apply instructions

### macOS / Linux

```bash
./apply_patch.sh /path/to/patch5-project
```

### Windows PowerShell

```powershell
./apply_patch.ps1 -TargetDir C:/path/to/patch5-project
```

### Direct Node

```bash
node apply_patch.mjs /path/to/patch5-project --install
```

## Post-apply steps

```bash
npm install
npm run validate:patch6
npm run tauri dev
```

## Validation focus

After applying Patch 6:

1. the app should open with Patch 6 / version 0.6.0 visible
2. the dashboard should show daily summary chips
3. the dashboard should show recent transactions
4. the dashboard should show low-stock alerts when present
5. quick actions should navigate correctly
6. backup/export quick actions should update dashboard visibility after refresh
7. the app shell should show the new daily-ops messaging and header chips

## Migration notes

No SQL migration is included.

- schema version remains `5`
- Patch 6 is registered in `patch_history`
- `app_meta.patch_level` becomes `P006_dashboard_daily_ops_mvp`
- `app_meta.app_version` becomes `0.6.0`

## Rollback notes

- restore from your source control state, or
- restore overwritten files from `.patch-backups/P006_dashboard_daily_ops_mvp/`
- no schema rollback is required because this patch does not alter the database structure
