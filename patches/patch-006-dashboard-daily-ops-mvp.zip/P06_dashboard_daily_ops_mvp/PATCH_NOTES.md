# Patch Notes

## Added

- `src-tauri/src/core/dashboard.rs`
- `scripts/validate-patch6.mjs`

## Updated

- frontend dashboard with daily summary, quick actions, recent transactions, and low-stock watchlists
- app shell labels and operational status chips
- Rust bootstrap composition for richer dashboard data
- patch registration metadata for Patch 6 / version 0.6.0

## No schema migration

Patch 6 intentionally does not add or modify SQLite tables. It derives daily ops data from existing Patch 1-5 tables.
