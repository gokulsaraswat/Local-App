# Patch 5 - POS Checkout Core

Patch ID: `P005_pos_checkout_core`

## Goal

Add the first real local POS checkout workflow on top of Patch 4.

This patch introduces checkout, held carts, completed sales, payment capture, receipt-ready sale history, and stock deduction routed through the existing inventory ledger while keeping the application fully local-first and offline-capable.

## What this patch adds

- POS workspace page in the desktop UI
- item browser for sellable catalog items
- local cart building and editable line items
- per-line discount support
- cart-level discount support
- payment entry rows for cash, card, UPI, bank transfer, and other
- held cart save / resume / delete flow
- completed sale records with sale lines and payments
- receipt preview and print-friendly popup
- register session foundation
- per-business sale and hold sequence support
- inventory deduction for tracked stock items when a sale is completed
- `pos_sale` movement rows added to the existing inventory ledger
- POS summary added to app bootstrap and dashboard
- export bundle support for sales, payments, held carts, and register sessions
- import preview counts for completed and held sales
- demo seed POS data for the demo workspace

## What this patch does not add

- customer linkage on sales
- split tenders with change calculation logic
- refunds / returns
- invoice settlement after sale completion
- kitchen tickets / restaurant table workflow
- barcode scanning integration
- printer device integration
- tax reporting beyond stored sale totals

## Data model changes

### New tables

`register_sessions`
- `id`
- `business_id`
- `label`
- `opened_at`
- `closed_at`
- `is_active`
- `created_at`
- `updated_at`

`sales`
- `id`
- `business_id`
- `register_session_id`
- `sale_number`
- `sale_status`
- `payment_status`
- `currency_code`
- `subtotal_amount`
- `discount_amount`
- `tax_amount`
- `total_amount`
- `amount_paid`
- `balance_due`
- `item_count`
- `notes`
- `completed_at`
- `created_at`
- `updated_at`

`sale_lines`
- `id`
- `sale_id`
- `business_id`
- `item_id`
- `item_name`
- `item_kind`
- `category_name`
- `sku`
- `primary_barcode`
- `unit_code`
- `tax_label`
- `tax_rate`
- `prices_include_tax`
- `quantity`
- `unit_price`
- `gross_amount`
- `discount_amount`
- `net_amount`
- `tax_amount`
- `total_amount`
- `notes`
- `created_at`

`sale_payments`
- `id`
- `sale_id`
- `payment_mode`
- `amount`
- `reference_value`
- `notes`
- `created_at`

`sale_holds`
- `id`
- `business_id`
- `hold_code`
- `hold_label`
- `notes`
- `item_count`
- `subtotal_amount`
- `discount_amount`
- `tax_amount`
- `total_amount`
- `cart_discount_amount`
- `cart_json`
- `created_at`
- `updated_at`

### Inventory integration

Tracked stock items now create `inventory_stock_movements` rows with `movement_type = 'pos_sale'` whenever a sale is completed successfully.

### API / bootstrap shape updates

- `AppBootstrap.posSummary`
- `ImportPreview.stockBalanceCount`
- `ImportPreview.saleCount`
- `ImportPreview.heldSaleCount`
- new POS commands:
  - `load_pos_workspace`
  - `save_pos_hold`
  - `delete_pos_hold`
  - `complete_pos_sale`

## Files added

- `scripts/validate-patch5.mjs`
- `src/modules/pos/PosPage.tsx`
- `src-tauri/src/commands/pos.rs`
- `src-tauri/src/core/pos.rs`
- `src-tauri/src/core/migrations/005_pos_checkout_core.sql`

## Files updated

- `package.json`
- `src/app/AppProvider.tsx`
- `src/modules/dashboard/DashboardPage.tsx`
- `src/modules/data-center/DataCenterPage.tsx`
- `src/modules/shell/AppShell.tsx`
- `src/shared/api.ts`
- `src/shared/types.ts`
- `src/shared/utils.ts`
- `src/styles.css`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src-tauri/src/commands/bootstrap.rs`
- `src-tauri/src/commands/data_center.rs`
- `src-tauri/src/commands/mod.rs`
- `src-tauri/src/core/db.rs`
- `src-tauri/src/core/migrations.rs`
- `src-tauri/src/core/mod.rs`
- `src-tauri/src/core/patching.rs`
- `src-tauri/src/core/seed.rs`
- `src-tauri/src/domain/bootstrap.rs`
- `src-tauri/src/domain/models.rs`
- `src-tauri/src/lib.rs`

## Apply instructions

Apply this patch on top of a working Patch 4 project.

### macOS / Linux

```bash
./apply_patch.sh /path/to/patch4-project
```

### Windows PowerShell

```powershell
./apply_patch.ps1 -TargetDir C:\path\to\patch4-project
```

### Direct Node

```bash
node apply_patch.mjs /path/to/patch4-project --install
```

## Post-apply steps

```bash
npm install
npm run validate:patch5
npm run tauri dev
```

## Validation notes

This patch bundle was structurally validated before packaging:

- `node --check apply_patch.mjs` passed
- `node scripts/validate-patch5.mjs` passed on an applied Patch 4 target
- TypeScript syntax parsing passed for all frontend `.ts` / `.tsx` files included in Patch 5
- SQLite migration smoke test for `001 + 002 + 003 + 004 + 005` passed
- `rustfmt` passed on the modified Rust files

A full `cargo check` and a full `npm install` + Tauri desktop launch could not be completed in this container.

## Rollback notes

- restore the files backed up under `.patch-backups/P005_pos_checkout_core/`
- restore the SQLite database from a pre-patch backup if migration 005 has already been executed in a live workspace
- remove Patch 5 entries from `.patch-meta/` only if you are performing a manual rollback and understand the consequences

## Known limitations

- POS is local single-workstation foundation only in this patch
- payment capture stores rows but does not calculate cash change automatically
- sale completion does not yet link customers or ledgers
- import remains preview-only
- receipt printing is browser-popup based rather than device-printer integrated
