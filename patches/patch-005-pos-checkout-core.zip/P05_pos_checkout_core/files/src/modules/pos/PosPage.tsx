import { useCallback, useEffect, useMemo, useState } from "react";
import { useAppState } from "../../app/AppProvider";
import {
  completePosSale,
  deletePosHold,
  loadPosWorkspace,
  savePosHold
} from "../../shared/api";
import type {
  PosCartLineInput,
  PosHoldSummary,
  PosPaymentEntryInput,
  PosSaleDetail,
  PosSellableItem,
  PosWorkspace
} from "../../shared/types";
import {
  clampNumber,
  formatCurrency,
  formatDateTime,
  formatPaymentMode,
  formatQuantity,
  roundMoney,
  titleCaseWords
} from "../../shared/utils";

const paymentModeOptions = [
  { value: "cash", label: "Cash" },
  { value: "card", label: "Card" },
  { value: "upi", label: "UPI" },
  { value: "bank_transfer", label: "Bank transfer" },
  { value: "other", label: "Other" }
] as const;

interface PreviewLine {
  item: PosSellableItem;
  quantity: number;
  unitPrice: number;
  grossAmount: number;
  discountAmount: number;
  netAmount: number;
  taxAmount: number;
  totalAmount: number;
  stockIssue: boolean;
  notes: string | null;
}

interface CartPreview {
  lines: PreviewLine[];
  subtotalAmount: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
  amountPaid: number;
  balanceDue: number;
  stockIssueCount: number;
}

const emptyPayment = (): PosPaymentEntryInput => ({
  paymentMode: "cash",
  amount: 0,
  referenceValue: null,
  notes: null
});

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function buildCartPreview(
  sellableItems: PosSellableItem[],
  cartLines: PosCartLineInput[],
  cartDiscountAmount: number,
  payments: PosPaymentEntryInput[]
): CartPreview {
  const itemById = new Map(sellableItems.map((item) => [item.itemId, item]));

  const draftLines = cartLines
    .map((line) => {
      const item = itemById.get(line.itemId);
      if (!item) return null;
      const quantity = clampNumber(line.quantity, 0);
      if (quantity <= 0) return null;
      const unitPrice = roundMoney(
        line.unitPrice !== null && Number.isFinite(line.unitPrice)
          ? line.unitPrice
          : item.sellingPrice
      );
      const grossAmount = roundMoney(unitPrice * quantity);
      const lineDiscount = roundMoney(
        Math.min(clampNumber(line.discountAmount, 0), grossAmount)
      );
      return {
        item,
        quantity,
        unitPrice,
        grossAmount,
        lineDiscount,
        baseAfterLineDiscount: roundMoney(grossAmount - lineDiscount),
        notes: line.notes
      };
    })
    .filter((line): line is NonNullable<typeof line> => Boolean(line));

  const totalEligible = roundMoney(
    draftLines.reduce((sum, line) => sum + line.baseAfterLineDiscount, 0)
  );
  const normalizedCartDiscount = roundMoney(
    Math.min(clampNumber(cartDiscountAmount, 0), totalEligible)
  );

  const allocatedCartDiscounts = draftLines.map(() => 0);
  if (draftLines.length > 0 && totalEligible > 0) {
    let consumed = 0;
    draftLines.forEach((line, index) => {
      if (index === draftLines.length - 1) {
        allocatedCartDiscounts[index] = roundMoney(normalizedCartDiscount - consumed);
        return;
      }
      const share = roundMoney(
        (normalizedCartDiscount * line.baseAfterLineDiscount) / totalEligible
      );
      allocatedCartDiscounts[index] = share;
      consumed = roundMoney(consumed + share);
    });
  }

  const previewLines: PreviewLine[] = draftLines.map((line, index) => {
    const allocatedCartDiscount = allocatedCartDiscounts[index] ?? 0;
    const discountAmount = roundMoney(line.lineDiscount + allocatedCartDiscount);
    const discountedAmount = roundMoney(
      Math.max(0, line.grossAmount - discountAmount)
    );
    const taxRate = clampNumber(line.item.taxRate, 0);
    const pricesIncludeTax = line.item.pricesIncludeTax;

    let netAmount = discountedAmount;
    let taxAmount = 0;
    let totalAmount = discountedAmount;

    if (pricesIncludeTax) {
      taxAmount =
        taxRate > 0
          ? roundMoney((discountedAmount * taxRate) / (100 + taxRate))
          : 0;
      netAmount = roundMoney(discountedAmount - taxAmount);
      totalAmount = discountedAmount;
    } else {
      netAmount = discountedAmount;
      taxAmount = taxRate > 0 ? roundMoney((netAmount * taxRate) / 100) : 0;
      totalAmount = roundMoney(netAmount + taxAmount);
    }

    return {
      item: line.item,
      quantity: line.quantity,
      unitPrice: line.unitPrice,
      grossAmount: line.grossAmount,
      discountAmount,
      netAmount,
      taxAmount,
      totalAmount,
      stockIssue:
        line.item.trackStock && line.quantity - line.item.onHandQuantity > 0.000001,
      notes: line.notes
    };
  });

  const subtotalAmount = roundMoney(
    previewLines.reduce((sum, line) => sum + line.grossAmount, 0)
  );
  const discountAmount = roundMoney(
    previewLines.reduce((sum, line) => sum + line.discountAmount, 0)
  );
  const taxAmount = roundMoney(
    previewLines.reduce((sum, line) => sum + line.taxAmount, 0)
  );
  const totalAmount = roundMoney(
    previewLines.reduce((sum, line) => sum + line.totalAmount, 0)
  );
  const amountPaid = roundMoney(
    payments.reduce((sum, payment) => sum + clampNumber(payment.amount, 0), 0)
  );
  const balanceDue = roundMoney(Math.max(0, totalAmount - amountPaid));

  return {
    lines: previewLines,
    subtotalAmount,
    discountAmount,
    taxAmount,
    totalAmount,
    amountPaid,
    balanceDue,
    stockIssueCount: previewLines.filter((line) => line.stockIssue).length
  };
}

function buildReceiptHtml(
  detail: PosSaleDetail,
  businessName: string,
  businessCode: string,
  currencyCode: string,
  receiptFooter: string | null
): string {
  const lineMarkup = detail.lines
    .map(
      (line) => `
        <tr>
          <td>${escapeHtml(line.itemName)}</td>
          <td style="text-align:right;">${escapeHtml(formatQuantity(line.quantity))}</td>
          <td style="text-align:right;">${escapeHtml(formatCurrency(line.totalAmount, currencyCode))}</td>
        </tr>
      `
    )
    .join("");

  const paymentMarkup =
    detail.payments.length > 0
      ? detail.payments
          .map(
            (payment) => `
              <tr>
                <td>${escapeHtml(formatPaymentMode(payment.paymentMode))}</td>
                <td style="text-align:right;">${escapeHtml(formatCurrency(payment.amount, currencyCode))}</td>
              </tr>
            `
          )
          .join("")
      : '<tr><td>Unpaid</td><td style="text-align:right;">—</td></tr>';

  return `
    <!doctype html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${escapeHtml(detail.sale.saleNumber)}</title>
        <style>
          body { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; margin: 18px; color: #111827; }
          h1, h2, p { margin: 0; }
          .receipt { max-width: 360px; margin: 0 auto; }
          .receipt-header { text-align: center; margin-bottom: 12px; }
          .muted { color: #4b5563; font-size: 12px; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; }
          td { padding: 4px 0; vertical-align: top; }
          .divider { border-top: 1px dashed #9ca3af; margin: 10px 0; }
          .totals td { font-weight: 700; }
        </style>
      </head>
      <body>
        <div class="receipt">
          <div class="receipt-header">
            <h1>${escapeHtml(businessName)}</h1>
            <p class="muted">${escapeHtml(businessCode)} · ${escapeHtml(detail.sale.saleNumber)}</p>
            <p class="muted">${escapeHtml(formatDateTime(detail.sale.completedAt))}</p>
          </div>
          <div class="divider"></div>
          <table>
            <tbody>${lineMarkup}</tbody>
          </table>
          <div class="divider"></div>
          <table>
            <tbody>
              <tr><td>Subtotal</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.subtotalAmount, currencyCode))}</td></tr>
              <tr><td>Discount</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.discountAmount, currencyCode))}</td></tr>
              <tr><td>Tax</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.taxAmount, currencyCode))}</td></tr>
              <tr class="totals"><td>Total</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.totalAmount, currencyCode))}</td></tr>
              <tr><td>Paid</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.amountPaid, currencyCode))}</td></tr>
              <tr><td>Due</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.balanceDue, currencyCode))}</td></tr>
            </tbody>
          </table>
          <div class="divider"></div>
          <table>
            <tbody>${paymentMarkup}</tbody>
          </table>
          ${receiptFooter ? `<div class="divider"></div><p class="muted">${escapeHtml(receiptFooter)}</p>` : ""}
        </div>
        <script>window.print();</script>
      </body>
    </html>
  `;
}

export function PosPage() {
  const { data, refresh } = useAppState();
  const [workspace, setWorkspace] = useState<PosWorkspace | null>(null);
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [search, setSearch] = useState("");
  const [cartLines, setCartLines] = useState<PosCartLineInput[]>([]);
  const [cartDiscountAmount, setCartDiscountAmount] = useState("0");
  const [saleNotes, setSaleNotes] = useState("");
  const [holdLabel, setHoldLabel] = useState("");
  const [selectedHoldId, setSelectedHoldId] = useState<string | null>(null);
  const [payments, setPayments] = useState<PosPaymentEntryInput[]>([emptyPayment()]);
  const [lastReceipt, setLastReceipt] = useState<PosSaleDetail | null>(null);

  const loadWorkspace = useCallback(async () => {
    setLoading(true);
    try {
      const next = await loadPosWorkspace();
      setWorkspace(next);
    } catch (error) {
      setStatusMessage(
        error instanceof Error ? error.message : "Failed to load POS workspace."
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadWorkspace();
  }, [loadWorkspace, data?.activeBusiness.id]);

  const filteredItems = useMemo(() => {
    if (!workspace) return [];
    const query = search.trim().toLowerCase();
    return workspace.sellableItems.filter((item) => {
      if (!query) return true;
      const haystack = [
        item.name,
        item.displayName,
        item.categoryName,
        item.sku,
        item.primaryBarcode,
        item.itemKind,
        item.taxLabel
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return haystack.includes(query);
    });
  }, [workspace, search]);

  const preview = useMemo(
    () =>
      buildCartPreview(
        workspace?.sellableItems ?? [],
        cartLines,
        Number(cartDiscountAmount || 0),
        payments
      ),
    [workspace, cartLines, cartDiscountAmount, payments]
  );

  function resetComposer() {
    setCartLines([]);
    setCartDiscountAmount("0");
    setSaleNotes("");
    setHoldLabel("");
    setSelectedHoldId(null);
    setPayments([emptyPayment()]);
  }

  function addItemToCart(item: PosSellableItem) {
    setCartLines((current) => {
      const existing = current.find((line) => line.itemId === item.itemId);
      if (existing) {
        return current.map((line) =>
          line.itemId === item.itemId
            ? { ...line, quantity: roundMoney(line.quantity + 1) }
            : line
        );
      }
      return [
        ...current,
        {
          itemId: item.itemId,
          quantity: 1,
          unitPrice: item.sellingPrice,
          discountAmount: 0,
          notes: null
        }
      ];
    });
  }

  function updateCartLine(itemId: string, patch: Partial<PosCartLineInput>) {
    setCartLines((current) =>
      current.map((line) => (line.itemId === itemId ? { ...line, ...patch } : line))
    );
  }

  function removeCartLine(itemId: string) {
    setCartLines((current) => current.filter((line) => line.itemId !== itemId));
  }

  function setPaymentDraft(index: number, patch: Partial<PosPaymentEntryInput>) {
    setPayments((current) =>
      current.map((payment, paymentIndex) =>
        paymentIndex === index ? { ...payment, ...patch } : payment
      )
    );
  }

  async function handleSaveHold() {
    if (preview.lines.length === 0) {
      setStatusMessage("Add at least one item before saving a hold.");
      return;
    }

    setStatusMessage("Saving held cart…");
    try {
      const saved = await savePosHold({
        id: selectedHoldId,
        holdLabel: holdLabel.trim() || "Held cart",
        notes: saleNotes.trim() || null,
        cartLines,
        cartDiscountAmount: Number(cartDiscountAmount || 0)
      });
      setSelectedHoldId(saved.id);
      setHoldLabel(saved.holdLabel);
      setStatusMessage(`Held cart saved: ${saved.holdCode}`);
      await Promise.all([loadWorkspace(), refresh()]);
    } catch (error) {
      setStatusMessage(error instanceof Error ? error.message : "Failed to save hold.");
    }
  }

  function handleResumeHold(hold: PosHoldSummary) {
    setSelectedHoldId(hold.id);
    setHoldLabel(hold.holdLabel);
    setSaleNotes(hold.notes ?? "");
    setCartDiscountAmount(String(hold.cartDiscountAmount ?? 0));
    setCartLines(hold.cartLines);
    setPayments([emptyPayment()]);
    setStatusMessage(`Resumed held cart ${hold.holdCode}.`);
  }

  async function handleDeleteHold(holdId: string) {
    setStatusMessage("Removing held cart…");
    try {
      await deletePosHold(holdId);
      if (selectedHoldId === holdId) {
        resetComposer();
      }
      setStatusMessage("Held cart removed.");
      await Promise.all([loadWorkspace(), refresh()]);
    } catch (error) {
      setStatusMessage(error instanceof Error ? error.message : "Failed to remove hold.");
    }
  }

  async function handleCompleteSale() {
    if (preview.lines.length === 0) {
      setStatusMessage("Add at least one item before completing a sale.");
      return;
    }
    if (preview.stockIssueCount > 0) {
      setStatusMessage("Resolve stock shortages before completing this sale.");
      return;
    }

    setStatusMessage("Completing local sale…");
    try {
      const completed = await completePosSale({
        holdId: selectedHoldId,
        notes: saleNotes.trim() || null,
        cartLines,
        cartDiscountAmount: Number(cartDiscountAmount || 0),
        payments: payments.filter((payment) => clampNumber(payment.amount, 0) > 0)
      });
      setLastReceipt(completed);
      resetComposer();
      setStatusMessage(`Sale completed: ${completed.sale.saleNumber}`);
      await Promise.all([loadWorkspace(), refresh()]);
    } catch (error) {
      setStatusMessage(error instanceof Error ? error.message : "Failed to complete sale.");
    }
  }

  function handlePrepareExactCash() {
    setPayments([
      {
        paymentMode: "cash",
        amount: preview.totalAmount,
        referenceValue: null,
        notes: null
      }
    ]);
  }

  function handlePrintReceipt() {
    if (!lastReceipt || !data) return;
    const popup = window.open("", "_blank", "width=420,height=720");
    if (!popup) {
      setStatusMessage("The receipt window was blocked by the browser runtime.");
      return;
    }

    popup.document.open();
    popup.document.write(
      buildReceiptHtml(
        lastReceipt,
        data.activeBusiness.name,
        data.activeBusiness.code,
        data.activeBusiness.currencyCode,
        data.activeReceiptProfile.footerText ?? data.businessSettings.receiptFooter ?? null
      )
    );
    popup.document.close();
  }

  if (!data) return null;

  return (
    <div className="page-grid">
      <section className="hero-card">
        <div>
          <div className="section-kicker">Patch 5 POS checkout core</div>
          <h2>Fast local checkout foundation</h2>
          <p>
            Build bills from local catalog items, park carts as held orders, capture
            split or partial payments, and generate receipt-ready sale snapshots without
            any cloud dependency.
          </p>
        </div>
        <div className="hero-actions align-start">
          <div className="summary-chip">
            <strong>{workspace?.registerLabel ?? "Main register"}</strong>
            <span>Register</span>
          </div>
          <div className="summary-chip">
            <strong>{data.posSummary.heldSaleCount}</strong>
            <span>Held carts</span>
          </div>
          <div className="summary-chip">
            <strong>
              {formatCurrency(data.posSummary.todayGrossSales, data.activeBusiness.currencyCode)}
            </strong>
            <span>Gross today</span>
          </div>
        </div>
      </section>

      <section className="split-grid pos-layout">
        <article className="card pos-item-browser">
          <div className="card-header">
            <h2>Sellable items</h2>
            <span className="pill success">
              {workspace?.sellableItems.length ?? 0} available
            </span>
          </div>

          <label className="form-span-2">
            <span>Search by item, category, SKU, or barcode</span>
            <input
              placeholder="Espresso, bread, service fee, 8901..."
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </label>

          <div className="pos-item-list">
            {filteredItems.map((item) => (
              <button
                className="pos-item-card"
                key={item.itemId}
                type="button"
                onClick={() => addItemToCart(item)}
              >
                <div>
                  <strong>{item.displayName || item.name}</strong>
                  <div className="muted-text">
                    {item.categoryName || titleCaseWords(item.itemKind)}
                    {item.sku ? ` · ${item.sku}` : ""}
                  </div>
                </div>
                <div className="pos-item-meta">
                  <span>
                    {formatCurrency(item.sellingPrice, data.activeBusiness.currencyCode)}
                  </span>
                  {item.trackStock ? (
                    <small>
                      Stock {formatQuantity(item.onHandQuantity)}
                      {item.unitCode ? ` ${item.unitCode}` : ""}
                    </small>
                  ) : (
                    <small>No stock tracking</small>
                  )}
                </div>
              </button>
            ))}
            {!loading && filteredItems.length === 0 ? (
              <p className="muted-text">No sellable items matched the current search.</p>
            ) : null}
          </div>
        </article>

        <article className="card pos-cart-card">
          <div className="card-header">
            <h2>Cart and checkout</h2>
            <span className={`pill ${preview.stockIssueCount > 0 ? "warning" : "success"}`}>
              {preview.lines.length} line(s)
            </span>
          </div>

          <div className="stack-list">
            {preview.lines.length > 0 ? (
              preview.lines.map((line) => (
                <div className="pos-cart-line" key={line.item.itemId}>
                  <div className="pos-cart-line-main">
                    <strong>{line.item.displayName || line.item.name}</strong>
                    <div className="muted-text">
                      {titleCaseWords(line.item.itemKind)}
                      {line.item.taxLabel ? ` · ${line.item.taxLabel}` : ""}
                    </div>
                    {line.stockIssue ? (
                      <div className="pill warning">
                        Requested {formatQuantity(line.quantity)} but only {formatQuantity(line.item.onHandQuantity)} in stock
                      </div>
                    ) : null}
                  </div>
                  <div className="pos-cart-line-fields">
                    <label>
                      <span>Qty</span>
                      <input
                        type="number"
                        min={line.item.allowFractional ? "0.001" : "1"}
                        step={line.item.allowFractional ? "0.001" : "1"}
                        value={cartLines.find((entry) => entry.itemId === line.item.itemId)?.quantity ?? line.quantity}
                        onChange={(event) =>
                          updateCartLine(line.item.itemId, {
                            quantity: Number(event.target.value)
                          })
                        }
                      />
                    </label>
                    <label>
                      <span>Price</span>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={cartLines.find((entry) => entry.itemId === line.item.itemId)?.unitPrice ?? line.unitPrice}
                        onChange={(event) =>
                          updateCartLine(line.item.itemId, {
                            unitPrice: Number(event.target.value)
                          })
                        }
                      />
                    </label>
                    <label>
                      <span>Discount</span>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={cartLines.find((entry) => entry.itemId === line.item.itemId)?.discountAmount ?? 0}
                        onChange={(event) =>
                          updateCartLine(line.item.itemId, {
                            discountAmount: Number(event.target.value)
                          })
                        }
                      />
                    </label>
                    <button
                      className="secondary-button"
                      type="button"
                      onClick={() => removeCartLine(line.item.itemId)}
                    >
                      Remove
                    </button>
                  </div>
                  <div className="pos-cart-line-total">
                    {formatCurrency(line.totalAmount, data.activeBusiness.currencyCode)}
                  </div>
                </div>
              ))
            ) : (
              <p className="muted-text">
                No cart lines yet. Click a sellable item on the left to start a bill.
              </p>
            )}
          </div>

          <div className="form-grid pos-cart-form-grid">
            <label>
              <span>Cart discount</span>
              <input
                type="number"
                min="0"
                step="0.01"
                value={cartDiscountAmount}
                onChange={(event) => setCartDiscountAmount(event.target.value)}
              />
            </label>
            <label>
              <span>Hold label</span>
              <input
                placeholder="Counter order / takeaway"
                value={holdLabel}
                onChange={(event) => setHoldLabel(event.target.value)}
              />
            </label>
            <label className="form-span-2">
              <span>Sale notes</span>
              <textarea
                rows={3}
                value={saleNotes}
                onChange={(event) => setSaleNotes(event.target.value)}
              />
            </label>
          </div>

          <div className="card-header pos-payment-header">
            <h3>Payments</h3>
            <button
              className="secondary-button"
              type="button"
              onClick={() => setPayments((current) => [...current, emptyPayment()])}
            >
              Add payment row
            </button>
          </div>
          <div className="stack-list">
            {payments.map((payment, index) => (
              <div className="pos-payment-row" key={`payment-${index}`}>
                <select
                  value={payment.paymentMode}
                  onChange={(event) =>
                    setPaymentDraft(index, { paymentMode: event.target.value })
                  }
                >
                  {paymentModeOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={payment.amount}
                  onChange={(event) =>
                    setPaymentDraft(index, { amount: Number(event.target.value) })
                  }
                />
                <input
                  placeholder="Reference"
                  value={payment.referenceValue ?? ""}
                  onChange={(event) =>
                    setPaymentDraft(index, {
                      referenceValue: event.target.value || null
                    })
                  }
                />
                <button
                  className="secondary-button"
                  type="button"
                  onClick={() =>
                    setPayments((current) =>
                      current.length === 1
                        ? [emptyPayment()]
                        : current.filter((_, paymentIndex) => paymentIndex !== index)
                    )
                  }
                >
                  Remove
                </button>
              </div>
            ))}
          </div>

          <div className="detail-list pos-summary-list">
            <div>
              <span>Subtotal</span>
              <code>{formatCurrency(preview.subtotalAmount, data.activeBusiness.currencyCode)}</code>
            </div>
            <div>
              <span>Discount</span>
              <code>{formatCurrency(preview.discountAmount, data.activeBusiness.currencyCode)}</code>
            </div>
            <div>
              <span>Tax</span>
              <code>{formatCurrency(preview.taxAmount, data.activeBusiness.currencyCode)}</code>
            </div>
            <div>
              <span>Total</span>
              <code>{formatCurrency(preview.totalAmount, data.activeBusiness.currencyCode)}</code>
            </div>
            <div>
              <span>Paid</span>
              <code>{formatCurrency(preview.amountPaid, data.activeBusiness.currencyCode)}</code>
            </div>
            <div>
              <span>Balance due</span>
              <code>{formatCurrency(preview.balanceDue, data.activeBusiness.currencyCode)}</code>
            </div>
          </div>

          <div className="inline-actions">
            <button className="secondary-button" type="button" onClick={handlePrepareExactCash}>
              Use exact cash
            </button>
            <button className="secondary-button" type="button" onClick={() => void handleSaveHold()}>
              Save Hold
            </button>
            <button className="secondary-button" type="button" onClick={resetComposer}>
              Clear Cart
            </button>
            <button
              className="primary-button"
              type="button"
              onClick={() => void handleCompleteSale()}
              disabled={preview.lines.length === 0 || preview.stockIssueCount > 0}
            >
              Complete Sale
            </button>
          </div>

          <div className="status-banner">{statusMessage || "No POS action run yet."}</div>
        </article>
      </section>

      <section className="split-grid">
        <article className="card">
          <div className="card-header">
            <h3>Held carts</h3>
            <span className="pill neutral">{workspace?.heldSales.length ?? 0} total</span>
          </div>
          <div className="stack-list">
            {workspace?.heldSales.length ? (
              workspace.heldSales.map((hold) => (
                <div className="list-row" key={hold.id}>
                  <div>
                    <strong>
                      {hold.holdCode} · {hold.holdLabel}
                    </strong>
                    <div className="muted-text">
                      {hold.itemCount} line(s) · {formatCurrency(hold.totalAmount, data.activeBusiness.currencyCode)}
                    </div>
                    <div className="muted-text">Updated {formatDateTime(hold.updatedAt)}</div>
                  </div>
                  <div className="inline-actions compact-actions">
                    <button
                      className="secondary-button"
                      type="button"
                      onClick={() => handleResumeHold(hold)}
                    >
                      Resume
                    </button>
                    <button
                      className="secondary-button"
                      type="button"
                      onClick={() => void handleDeleteHold(hold.id)}
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <p className="muted-text">No held carts yet.</p>
            )}
          </div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Recent sales</h3>
            <span className="pill success">{workspace?.recentSales.length ?? 0} shown</span>
          </div>
          <div className="stack-list">
            {workspace?.recentSales.length ? (
              workspace.recentSales.map((sale) => (
                <div className="list-row" key={sale.id}>
                  <div>
                    <strong>{sale.saleNumber}</strong>
                    <div className="muted-text">
                      {sale.itemCount} item(s) · {formatPaymentMode(sale.paymentStatus)}
                    </div>
                    <div className="muted-text">{formatDateTime(sale.completedAt)}</div>
                  </div>
                  <div className="align-right-text">
                    <strong>
                      {formatCurrency(sale.totalAmount, data.activeBusiness.currencyCode)}
                    </strong>
                    <div className="muted-text">
                      Paid {formatCurrency(sale.amountPaid, data.activeBusiness.currencyCode)}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="muted-text">No sales have been completed yet.</p>
            )}
          </div>
        </article>
      </section>

      {lastReceipt ? (
        <section className="card">
          <div className="card-header">
            <h3>Last completed receipt</h3>
            <div className="inline-actions compact-actions">
              <span className="pill success">{lastReceipt.sale.saleNumber}</span>
              <button className="secondary-button" type="button" onClick={handlePrintReceipt}>
                Print Receipt
              </button>
            </div>
          </div>
          <div className="split-grid receipt-preview-layout">
            <div>
              <div className="detail-list">
                <div>
                  <span>Total</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.totalAmount, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Paid</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.amountPaid, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Due</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.balanceDue, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Completed</span>
                  <code>{formatDateTime(lastReceipt.sale.completedAt)}</code>
                </div>
              </div>
            </div>
            <div className="receipt-preview">
              <div className="receipt-preview-title">{data.activeBusiness.name}</div>
              <div className="receipt-preview-subtitle">
                {data.activeBusiness.code} · {lastReceipt.sale.saleNumber}
              </div>
              <div className="receipt-preview-divider" />
              <div className="stack-list compact-stack">
                {lastReceipt.lines.map((line) => (
                  <div className="list-row" key={line.id}>
                    <div>
                      <strong>{line.itemName}</strong>
                      <div className="muted-text">
                        {formatQuantity(line.quantity)} × {formatCurrency(line.unitPrice, data.activeBusiness.currencyCode)}
                      </div>
                    </div>
                    <span>
                      {formatCurrency(line.totalAmount, data.activeBusiness.currencyCode)}
                    </span>
                  </div>
                ))}
              </div>
              <div className="receipt-preview-divider" />
              <div className="detail-list compact-detail-list">
                <div>
                  <span>Subtotal</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.subtotalAmount, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Discount</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.discountAmount, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Tax</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.taxAmount, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Total</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.totalAmount, data.activeBusiness.currencyCode)}
                  </code>
                </div>
              </div>
            </div>
          </div>
        </section>
      ) : null}
    </div>
  );
}
