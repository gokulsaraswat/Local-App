use tauri::AppHandle;

use crate::{
    core::{db, error::CommandResult, pos},
    domain::models::{CompletePosSaleInput, PosHoldSummary, PosSaleDetail, PosWorkspace, SavePosHoldInput},
};

#[tauri::command]
pub fn load_pos_workspace(app: AppHandle) -> CommandResult<PosWorkspace> {
    db::with_connection(&app, |conn, _paths| {
        let active_business = db::get_active_business(conn)?;
        pos::load_pos_workspace(conn, &active_business.id)
    })
}

#[tauri::command]
pub fn save_pos_hold(app: AppHandle, input: SavePosHoldInput) -> CommandResult<PosHoldSummary> {
    db::with_connection(&app, |conn, _paths| {
        let active_business = db::get_active_business(conn)?;
        pos::save_pos_hold(conn, &active_business.id, &input)
    })
}

#[tauri::command]
pub fn delete_pos_hold(app: AppHandle, hold_id: String) -> CommandResult<()> {
    db::with_connection(&app, |conn, _paths| {
        let active_business = db::get_active_business(conn)?;
        pos::delete_pos_hold(conn, &active_business.id, &hold_id)
    })
}

#[tauri::command]
pub fn complete_pos_sale(
    app: AppHandle,
    input: CompletePosSaleInput,
) -> CommandResult<PosSaleDetail> {
    db::with_connection(&app, |conn, _paths| {
        let active_business = db::get_active_business(conn)?;
        pos::complete_pos_sale(conn, &active_business, &input)
    })
}
