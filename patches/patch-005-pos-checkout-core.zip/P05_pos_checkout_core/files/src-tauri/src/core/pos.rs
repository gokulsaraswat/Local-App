use std::collections::HashMap;

use chrono::Utc;
use rusqlite::{params, Connection, OptionalExtension, Row};
use serde_json::{from_str, to_string};
use uuid::Uuid;

use crate::domain::models::{
    BusinessProfile, CompletePosSaleInput, PosCartLineInput, PosHoldSummary, PosPaymentEntryInput,
    PosSaleDetail, PosSaleLine, PosSalePayment, PosSaleRecord, PosSellableItem, PosSummary,
    PosWorkspace, RegisterSession, SavePosHoldInput,
};

use super::{db, error::to_command_error};

const EPSILON: f64 = 0.000_001;

#[derive(Debug, Clone)]
struct PosDraftLine {
    item: PosSellableItem,
    quantity: f64,
    unit_price: f64,
    gross_amount: f64,
    line_discount: f64,
    base_after_line_discount: f64,
    notes: Option<String>,
    cost_price: f64,
}

#[derive(Debug, Clone)]
struct ComputedSaleLine {
    item_id: Option<String>,
    item_name: String,
    item_kind: String,
    category_name: Option<String>,
    sku: Option<String>,
    primary_barcode: Option<String>,
    unit_code: Option<String>,
    tax_label: Option<String>,
    tax_rate: f64,
    prices_include_tax: bool,
    quantity: f64,
    unit_price: f64,
    gross_amount: f64,
    discount_amount: f64,
    net_amount: f64,
    tax_amount: f64,
    total_amount: f64,
    notes: Option<String>,
    track_stock: bool,
    on_hand_quantity: f64,
    cost_price: f64,
}

#[derive(Debug, Clone)]
struct ComputedSale {
    lines: Vec<ComputedSaleLine>,
    subtotal_amount: f64,
    discount_amount: f64,
    tax_amount: f64,
    total_amount: f64,
}

#[derive(Debug, Clone)]
struct RegisterSessionRow {
    pub session: RegisterSession,
}

fn round2(value: f64) -> f64 {
    if !value.is_finite() {
        return 0.0;
    }
    ((value + f64::EPSILON) * 100.0).round() / 100.0
}

fn canonical_zero(value: f64) -> f64 {
    if value.abs() < EPSILON {
        0.0
    } else {
        value
    }
}

fn bool_from_row(row: &Row, index: usize) -> rusqlite::Result<bool> {
    let value: i64 = row.get(index)?;
    Ok(value != 0)
}

fn bool_to_i64(value: bool) -> i64 {
    if value {
        1
    } else {
        0
    }
}

fn normalize_optional(value: &Option<String>) -> Option<String> {
    value.as_ref().and_then(|raw| {
        let trimmed = raw.trim();
        if trimmed.is_empty() {
            None
        } else {
            Some(trimmed.to_string())
        }
    })
}

fn normalize_text(value: &str, field: &str) -> Result<String, String> {
    let trimmed = value.trim();
    if trimmed.is_empty() {
        return Err(format!("{field} cannot be empty"));
    }
    Ok(trimmed.to_string())
}

fn normalize_payment_mode(value: &str) -> String {
    match value.trim().to_lowercase().as_str() {
        "cash" => "cash".into(),
        "card" => "card".into(),
        "upi" => "upi".into(),
        "bank" | "bank_transfer" => "bank_transfer".into(),
        _ => "other".into(),
    }
}

fn register_session_from_row(row: &Row) -> rusqlite::Result<RegisterSessionRow> {
    Ok(RegisterSessionRow {
        session: RegisterSession {
            id: row.get(0)?,
            business_id: row.get(1)?,
            label: row.get(2)?,
            status: row.get(3)?,
            opened_at: row.get(4)?,
            closed_at: row.get(5)?,
            created_at: row.get(6)?,
            updated_at: row.get(7)?,
        },
    })
}

fn sellable_item_with_cost_from_row(row: &Row) -> rusqlite::Result<(PosSellableItem, f64)> {
    let track_stock = bool_from_row(row, 10)?;
    let on_hand_quantity: f64 = row.get(11)?;
    let allow_fractional = bool_from_row(row, 6)?;
    let is_active = bool_from_row(row, 15)?;

    Ok((
        PosSellableItem {
            item_id: row.get(0)?,
            name: row.get(1)?,
            display_name: row.get(2)?,
            item_kind: row.get(3)?,
            category_name: row.get(4)?,
            unit_code: row.get(5)?,
            allow_fractional,
            sku: row.get(7)?,
            primary_barcode: row.get(8)?,
            selling_price: row.get(9)?,
            track_stock,
            on_hand_quantity,
            tax_label: row.get(12)?,
            tax_rate: row.get::<_, Option<f64>>(13)?.unwrap_or(0.0),
            prices_include_tax: bool_from_row(row, 14)?,
            is_available: is_active && (!track_stock || on_hand_quantity > 0.0),
        },
        row.get::<_, Option<f64>>(16)?.unwrap_or(0.0),
    ))
}

fn sale_record_from_row(row: &Row) -> rusqlite::Result<PosSaleRecord> {
    Ok(PosSaleRecord {
        id: row.get(0)?,
        business_id: row.get(1)?,
        register_session_id: row.get(2)?,
        sale_number: row.get(3)?,
        sale_status: row.get(4)?,
        payment_status: row.get(5)?,
        currency_code: row.get(6)?,
        subtotal_amount: row.get(7)?,
        discount_amount: row.get(8)?,
        tax_amount: row.get(9)?,
        total_amount: row.get(10)?,
        amount_paid: row.get(11)?,
        balance_due: row.get(12)?,
        item_count: row.get::<_, i64>(13)? as usize,
        notes: row.get(14)?,
        completed_at: row.get(15)?,
        created_at: row.get(16)?,
        updated_at: row.get(17)?,
    })
}

fn sale_line_from_row(row: &Row) -> rusqlite::Result<PosSaleLine> {
    Ok(PosSaleLine {
        id: row.get(0)?,
        sale_id: row.get(1)?,
        item_id: row.get(2)?,
        item_name: row.get(3)?,
        item_kind: row.get(4)?,
        category_name: row.get(5)?,
        sku: row.get(6)?,
        primary_barcode: row.get(7)?,
        unit_code: row.get(8)?,
        tax_label: row.get(9)?,
        tax_rate: row.get::<_, Option<f64>>(10)?.unwrap_or(0.0),
        prices_include_tax: bool_from_row(row, 11)?,
        quantity: row.get(12)?,
        unit_price: row.get(13)?,
        gross_amount: row.get(14)?,
        discount_amount: row.get(15)?,
        net_amount: row.get(16)?,
        tax_amount: row.get(17)?,
        total_amount: row.get(18)?,
        notes: row.get(19)?,
    })
}

fn sale_payment_from_row(row: &Row) -> rusqlite::Result<PosSalePayment> {
    Ok(PosSalePayment {
        id: row.get(0)?,
        sale_id: row.get(1)?,
        payment_mode: row.get(2)?,
        amount: row.get(3)?,
        reference_value: row.get(4)?,
        notes: row.get(5)?,
        created_at: row.get(6)?,
    })
}

fn hold_summary_from_row(row: &Row) -> rusqlite::Result<PosHoldSummary> {
    let cart_json: String = row.get(9)?;
    let cart_lines = from_str::<Vec<PosCartLineInput>>(&cart_json).unwrap_or_default();

    Ok(PosHoldSummary {
        id: row.get(0)?,
        business_id: row.get(1)?,
        hold_code: row.get(2)?,
        hold_label: row.get(3)?,
        item_count: row.get::<_, i64>(4)? as usize,
        subtotal_amount: row.get(5)?,
        discount_amount: row.get(6)?,
        tax_amount: row.get(7)?,
        total_amount: row.get(8)?,
        notes: row.get(10)?,
        cart_lines,
        cart_discount_amount: row.get(11)?,
        created_at: row.get(12)?,
        updated_at: row.get(13)?,
    })
}

fn list_register_sessions_for_business(
    conn: &Connection,
    business_id: &str,
) -> Result<Vec<RegisterSession>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, label, status, opened_at, closed_at, created_at, updated_at
             FROM register_sessions
             WHERE business_id = ?1
             ORDER BY status = 'open' DESC, created_at ASC",
        )
        .map_err(|error| to_command_error("failed to prepare register session query", error))?;

    let rows = stmt
        .query_map(params![business_id], register_session_from_row)
        .map_err(|error| to_command_error("failed to query register sessions", error))?;

    rows.map(|row| row.map(|record| record.session))
        .collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map register sessions", error))
}

fn get_primary_register(conn: &Connection, business_id: &str) -> Result<RegisterSession, String> {
    ensure_pos_support_for_business(conn, business_id)?;
    list_register_sessions_for_business(conn, business_id)?
        .into_iter()
        .next()
        .ok_or_else(|| "no register session available".into())
}

fn list_sellable_items_with_cost(
    conn: &Connection,
    business_id: &str,
) -> Result<Vec<(PosSellableItem, f64)>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT
                i.id,
                i.name,
                i.display_name,
                i.item_kind,
                c.name,
                u.code,
                COALESCE(u.allow_fractional, 0),
                i.sku,
                i.primary_barcode,
                i.selling_price,
                i.track_stock,
                i.stock_quantity,
                t.label,
                COALESCE(t.rate, 0),
                COALESCE(t.prices_include_tax, 0),
                i.is_active,
                i.cost_price
             FROM catalog_items i
             LEFT JOIN catalog_categories c ON c.id = i.category_id
             LEFT JOIN catalog_units u ON u.id = i.unit_id
             LEFT JOIN tax_profiles t ON t.id = i.tax_profile_id
             WHERE i.business_id = ?1
               AND i.archived_at IS NULL
               AND i.is_active = 1
             ORDER BY i.name COLLATE NOCASE ASC",
        )
        .map_err(|error| to_command_error("failed to prepare sellable item query", error))?;

    let rows = stmt
        .query_map(params![business_id], sellable_item_with_cost_from_row)
        .map_err(|error| to_command_error("failed to query sellable items", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map sellable items", error))
}

fn list_sellable_items(conn: &Connection, business_id: &str) -> Result<Vec<PosSellableItem>, String> {
    Ok(list_sellable_items_with_cost(conn, business_id)?
        .into_iter()
        .map(|(item, _cost)| item)
        .collect())
}

fn build_sale_calculation(
    conn: &Connection,
    business_id: &str,
    cart_lines: &[PosCartLineInput],
    cart_discount_amount: f64,
) -> Result<ComputedSale, String> {
    let mut item_map = HashMap::new();
    for (item, cost_price) in list_sellable_items_with_cost(conn, business_id)? {
        item_map.insert(item.item_id.clone(), (item, cost_price));
    }

    let mut draft_lines = Vec::new();
    for line in cart_lines {
        let Some((item, cost_price)) = item_map.get(&line.item_id) else {
            return Err(format!("item {} is not available in the active business", line.item_id));
        };

        let quantity = if line.quantity.is_finite() { line.quantity } else { 0.0 };
        if quantity <= 0.0 {
            return Err("line quantity must be greater than zero".into());
        }
        if !item.allow_fractional && (quantity.fract().abs() > EPSILON) {
            return Err(format!("{} does not allow fractional quantity", item.name));
        }

        let unit_price = line
            .unit_price
            .filter(|value| value.is_finite() && *value >= 0.0)
            .unwrap_or(item.selling_price);
        let gross_amount = round2(unit_price * quantity);
        let line_discount = round2(line.discount_amount.max(0.0).min(gross_amount));
        let base_after_line_discount = round2(gross_amount - line_discount);

        draft_lines.push(PosDraftLine {
            item: item.clone(),
            quantity,
            unit_price,
            gross_amount,
            line_discount,
            base_after_line_discount,
            notes: normalize_optional(&line.notes),
            cost_price: *cost_price,
        });
    }

    let total_eligible = round2(
        draft_lines
            .iter()
            .map(|line| line.base_after_line_discount)
            .sum::<f64>(),
    );

    let normalized_cart_discount = round2(cart_discount_amount.max(0.0).min(total_eligible));
    let mut allocated_discounts = vec![0.0; draft_lines.len()];

    if !draft_lines.is_empty() && total_eligible > 0.0 {
        let mut consumed = 0.0;
        for (index, line) in draft_lines.iter().enumerate() {
            if index == draft_lines.len() - 1 {
                allocated_discounts[index] = round2(normalized_cart_discount - consumed);
            } else {
                let share = round2(
                    (normalized_cart_discount * line.base_after_line_discount) / total_eligible,
                );
                allocated_discounts[index] = share;
                consumed = round2(consumed + share);
            }
        }
    }

    let lines = draft_lines
        .into_iter()
        .enumerate()
        .map(|(index, draft)| {
            let discount_amount = round2(draft.line_discount + allocated_discounts[index]);
            let discounted_amount = round2((draft.gross_amount - discount_amount).max(0.0));
            let mut net_amount = discounted_amount;
            let mut tax_amount = 0.0;
            let mut total_amount = discounted_amount;

            if draft.item.prices_include_tax {
                tax_amount = if draft.item.tax_rate > 0.0 {
                    round2((discounted_amount * draft.item.tax_rate) / (100.0 + draft.item.tax_rate))
                } else {
                    0.0
                };
                net_amount = round2(discounted_amount - tax_amount);
                total_amount = discounted_amount;
            } else {
                net_amount = discounted_amount;
                tax_amount = if draft.item.tax_rate > 0.0 {
                    round2((net_amount * draft.item.tax_rate) / 100.0)
                } else {
                    0.0
                };
                total_amount = round2(net_amount + tax_amount);
            }

            ComputedSaleLine {
                item_id: Some(draft.item.item_id),
                item_name: draft.item.name,
                item_kind: draft.item.item_kind,
                category_name: draft.item.category_name,
                sku: draft.item.sku,
                primary_barcode: draft.item.primary_barcode,
                unit_code: draft.item.unit_code,
                tax_label: draft.item.tax_label,
                tax_rate: draft.item.tax_rate,
                prices_include_tax: draft.item.prices_include_tax,
                quantity: draft.quantity,
                unit_price: draft.unit_price,
                gross_amount: draft.gross_amount,
                discount_amount,
                net_amount,
                tax_amount,
                total_amount,
                notes: draft.notes,
                track_stock: draft.item.track_stock,
                on_hand_quantity: draft.item.on_hand_quantity,
                cost_price: draft.cost_price,
            }
        })
        .collect::<Vec<_>>();

    Ok(ComputedSale {
        subtotal_amount: round2(lines.iter().map(|line| line.gross_amount).sum()),
        discount_amount: round2(lines.iter().map(|line| line.discount_amount).sum()),
        tax_amount: round2(lines.iter().map(|line| line.tax_amount).sum()),
        total_amount: round2(lines.iter().map(|line| line.total_amount).sum()),
        lines,
    })
}

fn get_sale_record(conn: &Connection, sale_id: &str) -> Result<PosSaleRecord, String> {
    conn.query_row(
        "SELECT id, business_id, register_session_id, sale_number, sale_status, payment_status, currency_code,
                subtotal_amount, discount_amount, tax_amount, total_amount, amount_paid, balance_due,
                item_count, notes, completed_at, created_at, updated_at
         FROM sales
         WHERE id = ?1
         LIMIT 1",
        params![sale_id],
        sale_record_from_row,
    )
    .map_err(|error| to_command_error("failed to load sale", error))
}

fn list_sale_lines_for_sale(conn: &Connection, sale_id: &str) -> Result<Vec<PosSaleLine>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, sale_id, item_id, item_name, item_kind, category_name, sku, primary_barcode,
                    unit_code, tax_label, tax_rate, prices_include_tax, quantity, unit_price,
                    gross_amount, discount_amount, net_amount, tax_amount, total_amount, notes
             FROM sale_lines
             WHERE sale_id = ?1
             ORDER BY created_at ASC, id ASC",
        )
        .map_err(|error| to_command_error("failed to prepare sale line query", error))?;

    let rows = stmt
        .query_map(params![sale_id], sale_line_from_row)
        .map_err(|error| to_command_error("failed to query sale lines", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map sale lines", error))
}

fn list_sale_payments_for_sale(
    conn: &Connection,
    sale_id: &str,
) -> Result<Vec<PosSalePayment>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, sale_id, payment_mode, amount, reference_value, notes, created_at
             FROM sale_payments
             WHERE sale_id = ?1
             ORDER BY created_at ASC, id ASC",
        )
        .map_err(|error| to_command_error("failed to prepare sale payment query", error))?;

    let rows = stmt
        .query_map(params![sale_id], sale_payment_from_row)
        .map_err(|error| to_command_error("failed to query sale payments", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map sale payments", error))
}

fn list_recent_sales(
    conn: &Connection,
    business_id: &str,
    limit: usize,
) -> Result<Vec<PosSaleRecord>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, register_session_id, sale_number, sale_status, payment_status, currency_code,
                    subtotal_amount, discount_amount, tax_amount, total_amount, amount_paid, balance_due,
                    item_count, notes, completed_at, created_at, updated_at
             FROM sales
             WHERE business_id = ?1
             ORDER BY completed_at DESC, created_at DESC
             LIMIT ?2",
        )
        .map_err(|error| to_command_error("failed to prepare recent sale query", error))?;

    let rows = stmt
        .query_map(params![business_id, limit as i64], sale_record_from_row)
        .map_err(|error| to_command_error("failed to query recent sales", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map recent sales", error))
}

fn get_hold_summary(
    conn: &Connection,
    business_id: &str,
    hold_id: &str,
) -> Result<PosHoldSummary, String> {
    conn.query_row(
        "SELECT id, business_id, hold_code, hold_label, item_count, subtotal_amount, discount_amount,
                tax_amount, total_amount, cart_json, notes, cart_discount_amount, created_at, updated_at
         FROM sale_holds
         WHERE business_id = ?1 AND id = ?2
         LIMIT 1",
        params![business_id, hold_id],
        hold_summary_from_row,
    )
    .map_err(|error| to_command_error("failed to load held sale", error))
}

fn list_held_sales(conn: &Connection, business_id: &str) -> Result<Vec<PosHoldSummary>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, hold_code, hold_label, item_count, subtotal_amount, discount_amount,
                    tax_amount, total_amount, cart_json, notes, cart_discount_amount, created_at, updated_at
             FROM sale_holds
             WHERE business_id = ?1
             ORDER BY updated_at DESC, created_at DESC",
        )
        .map_err(|error| to_command_error("failed to prepare held sale query", error))?;

    let rows = stmt
        .query_map(params![business_id], hold_summary_from_row)
        .map_err(|error| to_command_error("failed to query held sales", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map held sales", error))
}

fn next_sequence_value(
    conn: &Connection,
    business_id: &str,
    counter_key: &str,
    default_prefix: &str,
    default_padding: i64,
) -> Result<String, String> {
    let now = db::now_iso();

    conn.execute(
        "INSERT OR IGNORE INTO sequence_counters (
            business_id, counter_key, prefix, next_number, padding, reset_policy, updated_at
         ) VALUES (?1, ?2, ?3, 1, ?4, 'none', ?5)",
        params![business_id, counter_key, default_prefix, default_padding.max(1), &now],
    )
    .map_err(|error| to_command_error("failed to seed sequence counter", error))?;

    let (prefix, next_number, padding): (String, i64, i64) = conn
        .query_row(
            "SELECT prefix, next_number, padding
             FROM sequence_counters
             WHERE business_id = ?1 AND counter_key = ?2
             LIMIT 1",
            params![business_id, counter_key],
            |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)),
        )
        .map_err(|error| to_command_error("failed to read sequence counter", error))?;

    conn.execute(
        "UPDATE sequence_counters
         SET next_number = ?3, updated_at = ?4
         WHERE business_id = ?1 AND counter_key = ?2",
        params![business_id, counter_key, next_number.max(1) + 1, &now],
    )
    .map_err(|error| to_command_error("failed to increment sequence counter", error))?;

    let width = padding.max(1) as usize;
    Ok(format!("{}{number:0width$}", prefix, number = next_number.max(1), width = width))
}

pub fn ensure_pos_support_for_business(conn: &Connection, business_id: &str) -> Result<(), String> {
    let now = db::now_iso();

    conn.execute(
        "INSERT OR IGNORE INTO sequence_counters (
            business_id, counter_key, prefix, next_number, padding, reset_policy, updated_at
         ) VALUES (?1, 'sale', 'SAL-', 1, 5, 'none', ?2)",
        params![business_id, &now],
    )
    .map_err(|error| to_command_error("failed to ensure sale sequence", error))?;

    conn.execute(
        "INSERT OR IGNORE INTO sequence_counters (
            business_id, counter_key, prefix, next_number, padding, reset_policy, updated_at
         ) VALUES (?1, 'hold', 'HOLD-', 1, 5, 'none', ?2)",
        params![business_id, &now],
    )
    .map_err(|error| to_command_error("failed to ensure hold sequence", error))?;

    conn.execute(
        "INSERT OR IGNORE INTO register_sessions (
            id, business_id, label, status, opened_at, closed_at, created_at, updated_at
         ) VALUES (?1, ?2, ?3, 'open', ?4, NULL, ?5, ?6)",
        params![
            format!("register-main:{business_id}"),
            business_id,
            "Main register",
            &now,
            &now,
            &now,
        ],
    )
    .map_err(|error| to_command_error("failed to ensure main register", error))?;

    Ok(())
}

pub fn ensure_pos_support_foundation(conn: &Connection) -> Result<(), String> {
    let mut stmt = conn
        .prepare("SELECT id FROM businesses ORDER BY created_at ASC")
        .map_err(|error| to_command_error("failed to prepare business list", error))?;

    let rows = stmt
        .query_map([], |row| row.get::<_, String>(0))
        .map_err(|error| to_command_error("failed to query businesses", error))?;

    for business_id in rows {
        ensure_pos_support_for_business(conn, &business_id.map_err(|error| {
            to_command_error("failed to map business id for pos support", error)
        })?)?;
    }

    Ok(())
}

pub fn build_pos_summary(conn: &Connection, business_id: &str) -> Result<PosSummary, String> {
    ensure_pos_support_for_business(conn, business_id)?;
    let today = Utc::now().format("%Y-%m-%d").to_string();

    let completed_sale_count: usize = conn
        .query_row(
            "SELECT COUNT(*) FROM sales WHERE business_id = ?1 AND sale_status = 'completed'",
            params![business_id],
            |row| row.get::<_, i64>(0),
        )
        .map_err(|error| to_command_error("failed to count completed sales", error))?
        as usize;

    let (today_sale_count, today_gross_sales, today_collected_amount, today_due_amount): (
        usize,
        f64,
        f64,
        f64,
    ) = conn
        .query_row(
            "SELECT
                COUNT(*),
                COALESCE(SUM(total_amount), 0),
                COALESCE(SUM(amount_paid), 0),
                COALESCE(SUM(balance_due), 0)
             FROM sales
             WHERE business_id = ?1
               AND sale_status = 'completed'
               AND substr(completed_at, 1, 10) = ?2",
            params![business_id, today],
            |row| {
                Ok((
                    row.get::<_, i64>(0)? as usize,
                    row.get(1)?,
                    row.get(2)?,
                    row.get(3)?,
                ))
            },
        )
        .map_err(|error| to_command_error("failed to summarize today's sales", error))?;

    let held_sale_count: usize = conn
        .query_row(
            "SELECT COUNT(*) FROM sale_holds WHERE business_id = ?1",
            params![business_id],
            |row| row.get::<_, i64>(0),
        )
        .map_err(|error| to_command_error("failed to count held sales", error))?
        as usize;

    let average_sale_value = if completed_sale_count > 0 {
        let total: f64 = conn
            .query_row(
                "SELECT COALESCE(SUM(total_amount), 0)
                 FROM sales
                 WHERE business_id = ?1 AND sale_status = 'completed'",
                params![business_id],
                |row| row.get(0),
            )
            .map_err(|error| to_command_error("failed to total sales", error))?;
        round2(total / completed_sale_count as f64)
    } else {
        0.0
    };

    Ok(PosSummary {
        completed_sale_count,
        today_sale_count,
        held_sale_count,
        today_gross_sales: round2(today_gross_sales),
        today_collected_amount: round2(today_collected_amount),
        today_due_amount: round2(today_due_amount),
        average_sale_value,
    })
}

pub fn load_pos_workspace(conn: &Connection, business_id: &str) -> Result<PosWorkspace, String> {
    let register = get_primary_register(conn, business_id)?;
    Ok(PosWorkspace {
        business_id: business_id.to_string(),
        summary: build_pos_summary(conn, business_id)?,
        register_label: Some(register.label),
        sellable_items: list_sellable_items(conn, business_id)?,
        held_sales: list_held_sales(conn, business_id)?,
        recent_sales: list_recent_sales(conn, business_id, 20)?,
    })
}

pub fn save_pos_hold(
    conn: &Connection,
    business_id: &str,
    input: &SavePosHoldInput,
) -> Result<PosHoldSummary, String> {
    ensure_pos_support_for_business(conn, business_id)?;
    let hold_label = normalize_text(&input.hold_label, "hold label")?;
    let notes = normalize_optional(&input.notes);
    let calculation = build_sale_calculation(
        conn,
        business_id,
        &input.cart_lines,
        input.cart_discount_amount,
    )?;

    if calculation.lines.is_empty() {
        return Err("at least one cart line is required".into());
    }

    let now = db::now_iso();
    let cart_json = to_string(&input.cart_lines)
        .map_err(|error| to_command_error("failed to serialize held cart", error))?;

    let (hold_id, hold_code, created_at) = if let Some(existing_id) = input.id.clone() {
        let existing: Option<(String, String)> = conn
            .query_row(
                "SELECT hold_code, created_at FROM sale_holds WHERE business_id = ?1 AND id = ?2 LIMIT 1",
                params![business_id, &existing_id],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .optional()
            .map_err(|error| to_command_error("failed to load existing hold", error))?;

        let Some((existing_code, existing_created_at)) = existing else {
            return Err("held cart was not found for this business".into());
        };
        (existing_id, existing_code, existing_created_at)
    } else {
        (
            Uuid::new_v4().to_string(),
            next_sequence_value(conn, business_id, "hold", "HOLD-", 5)?,
            now.clone(),
        )
    };

    conn.execute(
        "INSERT INTO sale_holds (
            id, business_id, hold_code, hold_label, item_count, subtotal_amount, discount_amount,
            tax_amount, total_amount, notes, cart_json, cart_discount_amount, created_at, updated_at
         ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14)
         ON CONFLICT(id) DO UPDATE SET
            hold_label = excluded.hold_label,
            item_count = excluded.item_count,
            subtotal_amount = excluded.subtotal_amount,
            discount_amount = excluded.discount_amount,
            tax_amount = excluded.tax_amount,
            total_amount = excluded.total_amount,
            notes = excluded.notes,
            cart_json = excluded.cart_json,
            cart_discount_amount = excluded.cart_discount_amount,
            updated_at = excluded.updated_at",
        params![
            &hold_id,
            business_id,
            &hold_code,
            hold_label,
            calculation.lines.len() as i64,
            calculation.subtotal_amount,
            calculation.discount_amount,
            calculation.tax_amount,
            calculation.total_amount,
            notes,
            cart_json,
            round2(input.cart_discount_amount.max(0.0)),
            created_at,
            &now,
        ],
    )
    .map_err(|error| to_command_error("failed to save held cart", error))?;

    db::insert_log(conn, "INFO", "pos", "Held cart saved", None)?;
    get_hold_summary(conn, business_id, &hold_id)
}

pub fn delete_pos_hold(conn: &Connection, business_id: &str, hold_id: &str) -> Result<(), String> {
    let deleted = conn
        .execute(
            "DELETE FROM sale_holds WHERE business_id = ?1 AND id = ?2",
            params![business_id, hold_id],
        )
        .map_err(|error| to_command_error("failed to delete held cart", error))?;

    if deleted == 0 {
        return Err("held cart was not found for this business".into());
    }

    db::insert_log(conn, "INFO", "pos", "Held cart removed", None)?;
    Ok(())
}

pub fn complete_pos_sale(
    conn: &Connection,
    business: &BusinessProfile,
    input: &CompletePosSaleInput,
) -> Result<PosSaleDetail, String> {
    let business_id = &business.id;
    ensure_pos_support_for_business(conn, business_id)?;
    let register = get_primary_register(conn, business_id)?;
    let calculation = build_sale_calculation(
        conn,
        business_id,
        &input.cart_lines,
        input.cart_discount_amount,
    )?;

    if calculation.lines.is_empty() {
        return Err("at least one cart line is required".into());
    }

    for line in &calculation.lines {
        if line.track_stock && line.quantity - line.on_hand_quantity > EPSILON {
            return Err(format!(
                "{} has insufficient stock for this sale",
                line.item_name
            ));
        }
    }

    let payments = input
        .payments
        .iter()
        .filter_map(|payment| {
            let amount = if payment.amount.is_finite() {
                payment.amount.max(0.0)
            } else {
                0.0
            };
            if amount <= 0.0 {
                None
            } else {
                Some(PosPaymentEntryInput {
                    payment_mode: normalize_payment_mode(&payment.payment_mode),
                    amount: round2(amount),
                    reference_value: normalize_optional(&payment.reference_value),
                    notes: normalize_optional(&payment.notes),
                })
            }
        })
        .collect::<Vec<_>>();

    let amount_paid = round2(payments.iter().map(|payment| payment.amount).sum());
    if amount_paid - calculation.total_amount > EPSILON {
        return Err("payment amount cannot exceed sale total in this patch".into());
    }

    let balance_due = round2((calculation.total_amount - amount_paid).max(0.0));
    let payment_status = if amount_paid <= EPSILON {
        "unpaid"
    } else if balance_due <= EPSILON {
        "paid"
    } else {
        "partial"
    };

    let sale_id = Uuid::new_v4().to_string();
    let sale_number = next_sequence_value(conn, business_id, "sale", "SAL-", 5)?;
    let now = db::now_iso();
    let notes = normalize_optional(&input.notes);

    conn.execute(
        "INSERT INTO sales (
            id, business_id, register_session_id, sale_number, sale_status, payment_status,
            currency_code, subtotal_amount, discount_amount, tax_amount, total_amount,
            amount_paid, balance_due, item_count, notes, completed_at, created_at, updated_at
         ) VALUES (
            ?1, ?2, ?3, ?4, 'completed', ?5,
            ?6, ?7, ?8, ?9, ?10,
            ?11, ?12, ?13, ?14, ?15, ?16, ?17
         )",
        params![
            &sale_id,
            business_id,
            &register.session.id,
            &sale_number,
            payment_status,
            &business.currency_code,
            calculation.subtotal_amount,
            calculation.discount_amount,
            calculation.tax_amount,
            calculation.total_amount,
            amount_paid,
            balance_due,
            calculation.lines.len() as i64,
            notes,
            &now,
            &now,
            &now,
        ],
    )
    .map_err(|error| to_command_error("failed to create sale", error))?;

    for line in &calculation.lines {
        let line_id = Uuid::new_v4().to_string();
        conn.execute(
            "INSERT INTO sale_lines (
                id, sale_id, business_id, item_id, item_name, item_kind, category_name, sku,
                primary_barcode, unit_code, tax_label, tax_rate, prices_include_tax, quantity,
                unit_price, gross_amount, discount_amount, net_amount, tax_amount, total_amount,
                notes, created_at
             ) VALUES (
                ?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8,
                ?9, ?10, ?11, ?12, ?13, ?14,
                ?15, ?16, ?17, ?18, ?19, ?20,
                ?21, ?22
             )",
            params![
                &line_id,
                &sale_id,
                business_id,
                &line.item_id,
                &line.item_name,
                &line.item_kind,
                &line.category_name,
                &line.sku,
                &line.primary_barcode,
                &line.unit_code,
                &line.tax_label,
                line.tax_rate,
                bool_to_i64(line.prices_include_tax),
                line.quantity,
                line.unit_price,
                line.gross_amount,
                line.discount_amount,
                line.net_amount,
                line.tax_amount,
                line.total_amount,
                &line.notes,
                &now,
            ],
        )
        .map_err(|error| to_command_error("failed to create sale line", error))?;

        if line.track_stock {
            let quantity_after = canonical_zero(line.on_hand_quantity - line.quantity);
            if quantity_after < -EPSILON {
                return Err(format!(
                    "{} would fall below zero stock",
                    line.item_name
                ));
            }

            if let Some(item_id) = &line.item_id {
                conn.execute(
                    "UPDATE catalog_items
                     SET stock_quantity = ?3, updated_at = ?4
                     WHERE business_id = ?1 AND id = ?2",
                    params![business_id, item_id, quantity_after.max(0.0), &now],
                )
                .map_err(|error| to_command_error("failed to update stock after sale", error))?;

                conn.execute(
                    "INSERT INTO inventory_stock_movements (
                        id, business_id, item_id, movement_type, quantity_delta, quantity_after,
                        unit_cost, note, occurred_at, created_at
                     ) VALUES (?1, ?2, ?3, 'pos_sale', ?4, ?5, ?6, ?7, ?8, ?9)",
                    params![
                        Uuid::new_v4().to_string(),
                        business_id,
                        item_id,
                        -line.quantity,
                        quantity_after.max(0.0),
                        if line.cost_price > 0.0 {
                            Some(line.cost_price)
                        } else {
                            None
                        },
                        format!("POS sale {sale_number}"),
                        &now,
                        &now,
                    ],
                )
                .map_err(|error| to_command_error("failed to record inventory deduction", error))?;
            }
        }
    }

    for payment in payments {
        conn.execute(
            "INSERT INTO sale_payments (
                id, sale_id, business_id, payment_mode, amount, reference_value, notes, created_at
             ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
            params![
                Uuid::new_v4().to_string(),
                &sale_id,
                business_id,
                payment.payment_mode,
                payment.amount,
                payment.reference_value,
                payment.notes,
                &now,
            ],
        )
        .map_err(|error| to_command_error("failed to create sale payment", error))?;
    }

    if let Some(hold_id) = input.hold_id.as_ref() {
        conn.execute(
            "DELETE FROM sale_holds WHERE business_id = ?1 AND id = ?2",
            params![business_id, hold_id],
        )
        .map_err(|error| to_command_error("failed to clear held cart", error))?;
    }

    db::insert_log(conn, "INFO", "pos", "POS sale completed", None)?;

    Ok(PosSaleDetail {
        sale: get_sale_record(conn, &sale_id)?,
        lines: list_sale_lines_for_sale(conn, &sale_id)?,
        payments: list_sale_payments_for_sale(conn, &sale_id)?,
    })
}

pub fn seed_demo_pos_for_business(conn: &Connection, business_id: &str) -> Result<(), String> {
    ensure_pos_support_for_business(conn, business_id)?;

    let sale_count: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM sales WHERE business_id = ?1",
            params![business_id],
            |row| row.get(0),
        )
        .map_err(|error| to_command_error("failed to count demo sales", error))?;

    let hold_count: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM sale_holds WHERE business_id = ?1",
            params![business_id],
            |row| row.get(0),
        )
        .map_err(|error| to_command_error("failed to count demo held carts", error))?;

    let items = list_sellable_items(conn, business_id)?;
    let Some(first_item) = items.first() else {
        return Ok(());
    };
    let sale_item = items
        .iter()
        .find(|item| !item.track_stock || item.on_hand_quantity >= 1.0)
        .unwrap_or(first_item);

    if hold_count == 0 {
        let hold_input = SavePosHoldInput {
            id: None,
            hold_label: "Demo held cart".into(),
            notes: Some("Seeded held cart for checkout testing".into()),
            cart_lines: vec![PosCartLineInput {
                item_id: sale_item.item_id.clone(),
                quantity: 1.0,
                unit_price: Some(sale_item.selling_price),
                discount_amount: 0.0,
                notes: None,
            }],
            cart_discount_amount: 0.0,
        };
        let _ = save_pos_hold(conn, business_id, &hold_input)?;
    }

    if sale_count == 0 {
        let demo_business = BusinessProfile {
            id: business_id.to_string(),
            name: "Demo".into(),
            legal_name: None,
            code: "DEMO".into(),
            business_type: "Demo".into(),
            currency_code: conn
                .query_row(
                    "SELECT currency_code FROM businesses WHERE id = ?1 LIMIT 1",
                    params![business_id],
                    |row| row.get(0),
                )
                .map_err(|error| to_command_error("failed to load demo business currency", error))?,
            tax_mode: "exclusive".into(),
            phone: None,
            email: None,
            address_line1: None,
            address_line2: None,
            city: None,
            state: None,
            postal_code: None,
            country: None,
            created_at: db::now_iso(),
            updated_at: db::now_iso(),
            archived_at: None,
        };

        let sale_input = CompletePosSaleInput {
            hold_id: None,
            notes: Some("Seeded demo sale".into()),
            cart_lines: vec![PosCartLineInput {
                item_id: sale_item.item_id.clone(),
                quantity: 1.0,
                unit_price: Some(sale_item.selling_price),
                discount_amount: 0.0,
                notes: None,
            }],
            cart_discount_amount: 0.0,
            payments: vec![PosPaymentEntryInput {
                payment_mode: "cash".into(),
                amount: sale_item.selling_price,
                reference_value: None,
                notes: Some("Seeded payment".into()),
            }],
        };
        let _ = complete_pos_sale(conn, &demo_business, &sale_input)?;
    }

    Ok(())
}

pub fn list_all_register_sessions(conn: &Connection) -> Result<Vec<RegisterSession>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, label, status, opened_at, closed_at, created_at, updated_at
             FROM register_sessions
             ORDER BY created_at ASC",
        )
        .map_err(|error| to_command_error("failed to prepare all register query", error))?;

    let rows = stmt
        .query_map([], register_session_from_row)
        .map_err(|error| to_command_error("failed to query all registers", error))?;

    rows.map(|row| row.map(|record| record.session))
        .collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map all registers", error))
}

pub fn list_all_sales(conn: &Connection) -> Result<Vec<PosSaleRecord>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, register_session_id, sale_number, sale_status, payment_status, currency_code,
                    subtotal_amount, discount_amount, tax_amount, total_amount, amount_paid, balance_due,
                    item_count, notes, completed_at, created_at, updated_at
             FROM sales
             ORDER BY completed_at DESC, created_at DESC",
        )
        .map_err(|error| to_command_error("failed to prepare all sales query", error))?;

    let rows = stmt
        .query_map([], sale_record_from_row)
        .map_err(|error| to_command_error("failed to query all sales", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map all sales", error))
}

pub fn list_all_sale_lines(conn: &Connection) -> Result<Vec<PosSaleLine>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, sale_id, item_id, item_name, item_kind, category_name, sku, primary_barcode,
                    unit_code, tax_label, tax_rate, prices_include_tax, quantity, unit_price,
                    gross_amount, discount_amount, net_amount, tax_amount, total_amount, notes
             FROM sale_lines
             ORDER BY created_at ASC, id ASC",
        )
        .map_err(|error| to_command_error("failed to prepare all sale lines query", error))?;

    let rows = stmt
        .query_map([], sale_line_from_row)
        .map_err(|error| to_command_error("failed to query all sale lines", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map all sale lines", error))
}

pub fn list_all_sale_payments(conn: &Connection) -> Result<Vec<PosSalePayment>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, sale_id, payment_mode, amount, reference_value, notes, created_at
             FROM sale_payments
             ORDER BY created_at ASC, id ASC",
        )
        .map_err(|error| to_command_error("failed to prepare all sale payments query", error))?;

    let rows = stmt
        .query_map([], sale_payment_from_row)
        .map_err(|error| to_command_error("failed to query all sale payments", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map all sale payments", error))
}

pub fn list_all_sale_holds(conn: &Connection) -> Result<Vec<PosHoldSummary>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, hold_code, hold_label, item_count, subtotal_amount, discount_amount,
                    tax_amount, total_amount, cart_json, notes, cart_discount_amount, created_at, updated_at
             FROM sale_holds
             ORDER BY updated_at DESC, created_at DESC",
        )
        .map_err(|error| to_command_error("failed to prepare all held carts query", error))?;

    let rows = stmt
        .query_map([], hold_summary_from_row)
        .map_err(|error| to_command_error("failed to query all held carts", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map all held carts", error))
}
