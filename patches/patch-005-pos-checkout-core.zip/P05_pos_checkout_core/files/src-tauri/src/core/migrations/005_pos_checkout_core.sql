CREATE TABLE IF NOT EXISTS register_sessions (
  id TEXT PRIMARY KEY,
  business_id TEXT NOT NULL,
  label TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  opened_at TEXT NOT NULL,
  closed_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS sales (
  id TEXT PRIMARY KEY,
  business_id TEXT NOT NULL,
  register_session_id TEXT,
  sale_number TEXT NOT NULL,
  sale_status TEXT NOT NULL,
  payment_status TEXT NOT NULL,
  currency_code TEXT NOT NULL,
  subtotal_amount REAL NOT NULL DEFAULT 0,
  discount_amount REAL NOT NULL DEFAULT 0,
  tax_amount REAL NOT NULL DEFAULT 0,
  total_amount REAL NOT NULL DEFAULT 0,
  amount_paid REAL NOT NULL DEFAULT 0,
  balance_due REAL NOT NULL DEFAULT 0,
  item_count INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  completed_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  FOREIGN KEY (register_session_id) REFERENCES register_sessions(id) ON DELETE SET NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_business_sale_number
  ON sales (business_id, sale_number);

CREATE INDEX IF NOT EXISTS idx_sales_business_completed_at
  ON sales (business_id, completed_at DESC, created_at DESC);

CREATE TABLE IF NOT EXISTS sale_lines (
  id TEXT PRIMARY KEY,
  sale_id TEXT NOT NULL,
  business_id TEXT NOT NULL,
  item_id TEXT,
  item_name TEXT NOT NULL,
  item_kind TEXT NOT NULL,
  category_name TEXT,
  sku TEXT,
  primary_barcode TEXT,
  unit_code TEXT,
  tax_label TEXT,
  tax_rate REAL NOT NULL DEFAULT 0,
  prices_include_tax INTEGER NOT NULL DEFAULT 0,
  quantity REAL NOT NULL,
  unit_price REAL NOT NULL,
  gross_amount REAL NOT NULL DEFAULT 0,
  discount_amount REAL NOT NULL DEFAULT 0,
  net_amount REAL NOT NULL DEFAULT 0,
  tax_amount REAL NOT NULL DEFAULT 0,
  total_amount REAL NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
  FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  FOREIGN KEY (item_id) REFERENCES catalog_items(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_sale_lines_sale_id
  ON sale_lines (sale_id, created_at ASC);

CREATE INDEX IF NOT EXISTS idx_sale_lines_business_item
  ON sale_lines (business_id, item_id, created_at DESC);

CREATE TABLE IF NOT EXISTS sale_payments (
  id TEXT PRIMARY KEY,
  sale_id TEXT NOT NULL,
  business_id TEXT NOT NULL,
  payment_mode TEXT NOT NULL,
  amount REAL NOT NULL DEFAULT 0,
  reference_value TEXT,
  notes TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
  FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_sale_payments_sale_id
  ON sale_payments (sale_id, created_at ASC);

CREATE TABLE IF NOT EXISTS sale_holds (
  id TEXT PRIMARY KEY,
  business_id TEXT NOT NULL,
  hold_code TEXT NOT NULL,
  hold_label TEXT NOT NULL,
  item_count INTEGER NOT NULL DEFAULT 0,
  subtotal_amount REAL NOT NULL DEFAULT 0,
  discount_amount REAL NOT NULL DEFAULT 0,
  tax_amount REAL NOT NULL DEFAULT 0,
  total_amount REAL NOT NULL DEFAULT 0,
  notes TEXT,
  cart_json TEXT NOT NULL,
  cart_discount_amount REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_sale_holds_business_hold_code
  ON sale_holds (business_id, hold_code);

CREATE INDEX IF NOT EXISTS idx_sale_holds_business_updated_at
  ON sale_holds (business_id, updated_at DESC, created_at DESC);
