# Validation Checklist - Patch 5

- [ ] Apply Patch 5 on top of a Patch 4 project
- [ ] `npm install` completes
- [ ] `npm run validate:patch5` passes
- [ ] `npm run tauri dev` opens the desktop shell
- [ ] POS appears in the left navigation
- [ ] POS page loads sellable items from the catalog
- [ ] Adding items updates the cart totals correctly
- [ ] Held cart save / resume / delete works locally
- [ ] Completing a sale creates sale header, lines, and payment rows
- [ ] Selling a tracked stock item decreases on-hand quantity
- [ ] Inventory history shows `pos_sale` movement rows for completed sales
- [ ] Data export includes sales, payments, held carts, and register sessions
- [ ] Import preview shows `stockBalanceCount`, `saleCount`, and `heldSaleCount`
