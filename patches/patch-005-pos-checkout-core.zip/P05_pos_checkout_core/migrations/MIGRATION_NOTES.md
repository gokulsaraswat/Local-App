# Migration Notes - Patch 5

Schema version moves from `4` to `5`.

## Migration 005

Creates the POS foundation tables:

- `register_sessions`
- `sales`
- `sale_lines`
- `sale_payments`
- `sale_holds`

It also adds lookup indexes for sale number, completed time, line lookups, payment lookups, and held-cart lookups.

## Business workspace backfill behavior

At startup, each business receives POS support foundation if missing:

- sale sequence counter
- hold sequence counter
- default register session (`register-main:<business_id>`)

## Demo seed behavior

If the demo workspace exists and has no POS data yet, seed logic can create:

- one held cart
- one completed demo sale

## Destructive changes

This migration is additive only. No existing Patch 4 tables are dropped or renamed.

## Operational recommendation

Create a local backup before opening a live database with Patch 5 for the first time.
