# Rollback Notes - Patch 5

## Code rollback

1. Restore overwritten files from:
   - `.patch-backups/P005_pos_checkout_core/`
2. Remove any newly added Patch 5 files if you are fully reverting the code layer.
3. Remove Patch 5 entries from `.patch-meta/` only if you are performing a deliberate manual rollback.

## Database rollback

Migration 005 adds new tables and runtime startup support records.

If the patched app has already opened a live database, the safest rollback is:
- restore the SQLite database from a pre-Patch-5 backup snapshot
- then restore the Patch 4 codebase

Rolling back only the code without restoring the database can leave extra POS tables present in the SQLite file.
