# Patch Notes - Patch 5

## Overview

Patch 5 introduces the first operational checkout layer for the local-first business app.

The patch adds:
- POS page and navigation entry
- cart and held-cart workflow
- sales, payments, and receipt-ready sale history
- register session foundation
- stock deduction through the inventory ledger
- export / import preview coverage for POS records

## New modules / files

- `src/modules/pos/PosPage.tsx`
- `src-tauri/src/commands/pos.rs`
- `src-tauri/src/core/pos.rs`
- `src-tauri/src/core/migrations/005_pos_checkout_core.sql`
- `scripts/validate-patch5.mjs`

## Internal design notes

- Held carts are stored in `sale_holds.cart_json` as serialized line inputs.
- Completed sales persist normalized headers, lines, and payment rows.
- Stock deduction reuses the existing `inventory_stock_movements` table using `movement_type = 'pos_sale'`.
- Each business receives sale and hold sequence counters and a default register session foundation.

## Export scope additions

The export bundle now includes:
- `inventoryStockBalances`
- `registerSessions`
- `sales`
- `saleLines`
- `salePayments`
- `saleHolds`

The import preview now surfaces:
- `stockBalanceCount`
- `saleCount`
- `heldSaleCount`

## Known limitations

- no customer assignment to sales yet
- no return / refund flow yet
- no split-payment change handling yet
- no hardware printer or barcode scanner integration yet
- no sales-to-ledger posting yet
