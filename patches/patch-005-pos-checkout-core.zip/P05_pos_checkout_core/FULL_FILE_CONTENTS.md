## PATCH-5-README.md

```md
# Patch 5 - POS Checkout Core

Patch ID: `P005_pos_checkout_core`

## Goal

Add the first real local POS checkout workflow on top of Patch 4.

This patch introduces checkout, held carts, completed sales, payment capture, receipt-ready sale history, and stock deduction routed through the existing inventory ledger while keeping the application fully local-first and offline-capable.

## What this patch adds

- POS workspace page in the desktop UI
- item browser for sellable catalog items
- local cart building and editable line items
- per-line discount support
- cart-level discount support
- payment entry rows for cash, card, UPI, bank transfer, and other
- held cart save / resume / delete flow
- completed sale records with sale lines and payments
- receipt preview and print-friendly popup
- register session foundation
- per-business sale and hold sequence support
- inventory deduction for tracked stock items when a sale is completed
- `pos_sale` movement rows added to the existing inventory ledger
- POS summary added to app bootstrap and dashboard
- export bundle support for sales, payments, held carts, and register sessions
- import preview counts for completed and held sales
- demo seed POS data for the demo workspace

## What this patch does not add

- customer linkage on sales
- split tenders with change calculation logic
- refunds / returns
- invoice settlement after sale completion
- kitchen tickets / restaurant table workflow
- barcode scanning integration
- printer device integration
- tax reporting beyond stored sale totals

## Data model changes

### New tables

`register_sessions`
- `id`
- `business_id`
- `label`
- `opened_at`
- `closed_at`
- `is_active`
- `created_at`
- `updated_at`

`sales`
- `id`
- `business_id`
- `register_session_id`
- `sale_number`
- `sale_status`
- `payment_status`
- `currency_code`
- `subtotal_amount`
- `discount_amount`
- `tax_amount`
- `total_amount`
- `amount_paid`
- `balance_due`
- `item_count`
- `notes`
- `completed_at`
- `created_at`
- `updated_at`

`sale_lines`
- `id`
- `sale_id`
- `business_id`
- `item_id`
- `item_name`
- `item_kind`
- `category_name`
- `sku`
- `primary_barcode`
- `unit_code`
- `tax_label`
- `tax_rate`
- `prices_include_tax`
- `quantity`
- `unit_price`
- `gross_amount`
- `discount_amount`
- `net_amount`
- `tax_amount`
- `total_amount`
- `notes`
- `created_at`

`sale_payments`
- `id`
- `sale_id`
- `payment_mode`
- `amount`
- `reference_value`
- `notes`
- `created_at`

`sale_holds`
- `id`
- `business_id`
- `hold_code`
- `hold_label`
- `notes`
- `item_count`
- `subtotal_amount`
- `discount_amount`
- `tax_amount`
- `total_amount`
- `cart_discount_amount`
- `cart_json`
- `created_at`
- `updated_at`

### Inventory integration

Tracked stock items now create `inventory_stock_movements` rows with `movement_type = 'pos_sale'` whenever a sale is completed successfully.

### API / bootstrap shape updates

- `AppBootstrap.posSummary`
- `ImportPreview.stockBalanceCount`
- `ImportPreview.saleCount`
- `ImportPreview.heldSaleCount`
- new POS commands:
  - `load_pos_workspace`
  - `save_pos_hold`
  - `delete_pos_hold`
  - `complete_pos_sale`

## Files added

- `scripts/validate-patch5.mjs`
- `src/modules/pos/PosPage.tsx`
- `src-tauri/src/commands/pos.rs`
- `src-tauri/src/core/pos.rs`
- `src-tauri/src/core/migrations/005_pos_checkout_core.sql`

## Files updated

- `package.json`
- `src/app/AppProvider.tsx`
- `src/modules/dashboard/DashboardPage.tsx`
- `src/modules/data-center/DataCenterPage.tsx`
- `src/modules/shell/AppShell.tsx`
- `src/shared/api.ts`
- `src/shared/types.ts`
- `src/shared/utils.ts`
- `src/styles.css`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src-tauri/src/commands/bootstrap.rs`
- `src-tauri/src/commands/data_center.rs`
- `src-tauri/src/commands/mod.rs`
- `src-tauri/src/core/db.rs`
- `src-tauri/src/core/migrations.rs`
- `src-tauri/src/core/mod.rs`
- `src-tauri/src/core/patching.rs`
- `src-tauri/src/core/seed.rs`
- `src-tauri/src/domain/bootstrap.rs`
- `src-tauri/src/domain/models.rs`
- `src-tauri/src/lib.rs`

## Apply instructions

Apply this patch on top of a working Patch 4 project.

### macOS / Linux

```bash
./apply_patch.sh /path/to/patch4-project
```

### Windows PowerShell

```powershell
./apply_patch.ps1 -TargetDir C:\path\to\patch4-project
```

### Direct Node

```bash
node apply_patch.mjs /path/to/patch4-project --install
```

## Post-apply steps

```bash
npm install
npm run validate:patch5
npm run tauri dev
```

## Validation notes

This patch bundle was structurally validated before packaging:

- `node --check apply_patch.mjs` passed
- `node scripts/validate-patch5.mjs` passed on an applied Patch 4 target
- TypeScript syntax parsing passed for all frontend `.ts` / `.tsx` files included in Patch 5
- SQLite migration smoke test for `001 + 002 + 003 + 004 + 005` passed
- `rustfmt` passed on the modified Rust files

A full `cargo check` and a full `npm install` + Tauri desktop launch could not be completed in this container.

## Rollback notes

- restore the files backed up under `.patch-backups/P005_pos_checkout_core/`
- restore the SQLite database from a pre-patch backup if migration 005 has already been executed in a live workspace
- remove Patch 5 entries from `.patch-meta/` only if you are performing a manual rollback and understand the consequences

## Known limitations

- POS is local single-workstation foundation only in this patch
- payment capture stores rows but does not calculate cash change automatically
- sale completion does not yet link customers or ledgers
- import remains preview-only
- receipt printing is browser-popup based rather than device-printer integrated

```

## PATCH_NOTES.md

```md
# Patch Notes - Patch 5

## Overview

Patch 5 introduces the first operational checkout layer for the local-first business app.

The patch adds:
- POS page and navigation entry
- cart and held-cart workflow
- sales, payments, and receipt-ready sale history
- register session foundation
- stock deduction through the inventory ledger
- export / import preview coverage for POS records

## New modules / files

- `src/modules/pos/PosPage.tsx`
- `src-tauri/src/commands/pos.rs`
- `src-tauri/src/core/pos.rs`
- `src-tauri/src/core/migrations/005_pos_checkout_core.sql`
- `scripts/validate-patch5.mjs`

## Internal design notes

- Held carts are stored in `sale_holds.cart_json` as serialized line inputs.
- Completed sales persist normalized headers, lines, and payment rows.
- Stock deduction reuses the existing `inventory_stock_movements` table using `movement_type = 'pos_sale'`.
- Each business receives sale and hold sequence counters and a default register session foundation.

## Export scope additions

The export bundle now includes:
- `inventoryStockBalances`
- `registerSessions`
- `sales`
- `saleLines`
- `salePayments`
- `saleHolds`

The import preview now surfaces:
- `stockBalanceCount`
- `saleCount`
- `heldSaleCount`

## Known limitations

- no customer assignment to sales yet
- no return / refund flow yet
- no split-payment change handling yet
- no hardware printer or barcode scanner integration yet
- no sales-to-ledger posting yet

```

## TREE.txt

```
P05_pos_checkout_core/
├── files/
│   ├── scripts/
│   │   └── validate-patch5.mjs
│   ├── src/
│   │   ├── app/
│   │   │   └── AppProvider.tsx
│   │   ├── modules/
│   │   │   ├── dashboard/
│   │   │   │   └── DashboardPage.tsx
│   │   │   ├── data-center/
│   │   │   │   └── DataCenterPage.tsx
│   │   │   ├── pos/
│   │   │   │   └── PosPage.tsx
│   │   │   └── shell/
│   │   │       └── AppShell.tsx
│   │   ├── shared/
│   │   │   ├── api.ts
│   │   │   ├── types.ts
│   │   │   └── utils.ts
│   │   └── styles.css
│   ├── src-tauri/
│   │   ├── src/
│   │   │   ├── commands/
│   │   │   │   ├── bootstrap.rs
│   │   │   │   ├── data_center.rs
│   │   │   │   ├── mod.rs
│   │   │   │   └── pos.rs
│   │   │   ├── core/
│   │   │   │   ├── migrations/
│   │   │   │   │   └── 005_pos_checkout_core.sql
│   │   │   │   ├── db.rs
│   │   │   │   ├── migrations.rs
│   │   │   │   ├── mod.rs
│   │   │   │   ├── patching.rs
│   │   │   │   ├── pos.rs
│   │   │   │   └── seed.rs
│   │   │   ├── domain/
│   │   │   │   ├── bootstrap.rs
│   │   │   │   └── models.rs
│   │   │   └── lib.rs
│   │   ├── Cargo.toml
│   │   └── tauri.conf.json
│   └── package.json
├── migrations/
│   └── MIGRATION_NOTES.md
├── apply_patch.mjs
├── apply_patch.ps1
├── apply_patch.sh
├── PATCH-5-README.md
├── patch-manifest.json
├── PATCH_NOTES.md
├── rollback.md
└── validate.md

```

## apply_patch.mjs

```js
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const manifestPath = path.join(__dirname, "patch-manifest.json");
const filesDir = path.join(__dirname, "files");
const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));

const args = process.argv.slice(2);
const force = args.includes("--force");
const install = args.includes("--install");
const targetArg = args.find((arg) => !arg.startsWith("--"));
const targetPath = path.resolve(targetArg || process.cwd());
const patchBackupRoot = path.join(targetPath, ".patch-backups", manifest.patch_id);
const patchMetaRoot = path.join(targetPath, ".patch-meta");

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function listFilesRecursively(dir, prefix = "") {
  const results = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const entryRel = path.join(prefix, entry.name);
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...listFilesRecursively(full, entryRel));
    } else {
      results.push(entryRel);
    }
  }
  return results;
}

function readFileOrNull(filePath) {
  if (!fs.existsSync(filePath)) return null;
  return fs.readFileSync(filePath);
}

function sameFile(a, b) {
  if (a === null || b === null) return false;
  return Buffer.compare(a, b) === 0;
}

function validatePatch4Base() {
  const packageJsonPath = path.join(targetPath, "package.json");
  const patchingPath = path.join(targetPath, "src-tauri", "src", "core", "patching.rs");
  const migration4Path = path.join(
    targetPath,
    "src-tauri",
    "src",
    "core",
    "migrations",
    "004_inventory_ledger_core.sql"
  );

  if (!fs.existsSync(packageJsonPath) || !fs.existsSync(patchingPath) || !fs.existsSync(migration4Path)) {
    throw new Error(
      "Patch 5 expects an existing Patch 4 project. Missing package.json, patching.rs, or migration 004."
    );
  }

  const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, "utf8"));
  const patchingSource = fs.readFileSync(patchingPath, "utf8");
  const looksLikePatch4 =
    String(packageJson.version || "").startsWith("0.4") ||
    patchingSource.includes("P004_inventory_ledger_core");

  if (!looksLikePatch4 && !force) {
    throw new Error(
      "Target project does not look like a Patch 4 base. Re-run with --force only if you are sure."
    );
  }
}

function backupExistingFile(relativePath, existingContents) {
  const backupPath = path.join(patchBackupRoot, relativePath);
  ensureDir(path.dirname(backupPath));
  fs.writeFileSync(backupPath, existingContents);
}

function copyFile(relativePath) {
  const source = path.join(filesDir, relativePath);
  const target = path.join(targetPath, relativePath);
  ensureDir(path.dirname(target));

  const incoming = fs.readFileSync(source);
  const existing = readFileOrNull(target);

  if (existing !== null && !sameFile(existing, incoming)) {
    backupExistingFile(relativePath, existing);
  }

  fs.writeFileSync(target, incoming);
}

function loadAppliedPatches(metaFile) {
  if (!fs.existsSync(metaFile)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(metaFile, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function maybeRunInstall() {
  if (!install) return;

  const npmCommand = process.platform === "win32" ? "npm.cmd" : "npm";
  const result = spawnSync(npmCommand, ["install"], {
    cwd: targetPath,
    stdio: "inherit",
    shell: false
  });

  if (result.status !== 0) {
    throw new Error("npm install failed after applying the patch");
  }
}

function main() {
  if (!fs.existsSync(filesDir)) {
    throw new Error(`Patch bundle is missing files directory: ${filesDir}`);
  }

  ensureDir(targetPath);
  ensureDir(patchMetaRoot);
  validatePatch4Base();

  const fileList = listFilesRecursively(filesDir);
  for (const relativePath of fileList) {
    copyFile(relativePath);
  }

  const appliedPatchesFile = path.join(patchMetaRoot, "applied-patches.json");
  const appliedPatches = loadAppliedPatches(appliedPatchesFile).filter(
    (entry) => entry && entry.patchId !== manifest.patch_id
  );
  appliedPatches.push({
    patchId: manifest.patch_id,
    patchName: manifest.patch_name,
    appliedAt: new Date().toISOString(),
    fileCount: fileList.length,
    dependencies: manifest.dependencies
  });
  fs.writeFileSync(appliedPatchesFile, JSON.stringify(appliedPatches, null, 2) + "\n");

  fs.writeFileSync(
    path.join(patchMetaRoot, "last-applied.json"),
    JSON.stringify(
      {
        patchId: manifest.patch_id,
        patchName: manifest.patch_name,
        targetPath,
        appliedAt: new Date().toISOString(),
        fileCount: fileList.length,
        installRan: install
      },
      null,
      2
    ) + "\n"
  );

  maybeRunInstall();

  console.log(`[OK] Applied ${manifest.patch_id} to ${targetPath}`);
  console.log(`[INFO] Files copied: ${fileList.length}`);
  console.log(`[INFO] Backups stored in ${patchBackupRoot}`);
}

try {
  main();
} catch (error) {
  console.error(`[ERROR] ${error instanceof Error ? error.message : String(error)}`);
  process.exit(1);
}

```

## apply_patch.ps1

```powershell
param(
  [string]$TargetDir = "."
)

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
node "$scriptRoot/apply_patch.mjs" $TargetDir --install

```

## apply_patch.sh

```bash
#!/usr/bin/env bash
set -euo pipefail

TARGET_DIR="${1:-.}"
node "$(cd "$(dirname "$0")" && pwd)/apply_patch.mjs" "$TARGET_DIR" --install

```

## files/package.json

```json
{
  "name": "local-first-business-manager",
  "private": true,
  "version": "0.5.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview",
    "tauri": "tauri",
    "typecheck": "tsc --noEmit",
    "validate:patch3": "node scripts/validate-patch3.mjs",
    "validate:patch4": "node scripts/validate-patch4.mjs",
    "validate:patch5": "node scripts/validate-patch5.mjs"
  },
  "dependencies": {
    "@tauri-apps/api": "^2.0.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@tauri-apps/cli": "^2.0.0",
    "@types/react": "^18.3.7",
    "@types/react-dom": "^18.3.3",
    "@vitejs/plugin-react": "^4.3.3",
    "typescript": "^5.6.3",
    "vite": "^5.4.10"
  }
}

```

## files/scripts/validate-patch5.mjs

```js
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
let ts = null;
try {
  ts = require("typescript");
} catch {
  ts = null;
}

const requiredFiles = [
  "package.json",
  "src/shared/types.ts",
  "src/shared/api.ts",
  "src/modules/pos/PosPage.tsx",
  "src/modules/shell/AppShell.tsx",
  "src-tauri/src/core/pos.rs",
  "src-tauri/src/core/migrations/005_pos_checkout_core.sql",
  "src-tauri/src/commands/pos.rs",
  "src-tauri/src/lib.rs"
];

const requiredSnippets = [
  ["package.json", '"validate:patch5": "node scripts/validate-patch5.mjs"'],
  ["src/shared/types.ts", "export interface PosWorkspace"],
  ["src/shared/types.ts", '  | "pos"'],
  ["src/shared/api.ts", 'invoke<PosWorkspace>("load_pos_workspace")'],
  ["src/shared/api.ts", 'invoke<PosSaleDetail>("complete_pos_sale"'],
  ["src/modules/pos/PosPage.tsx", "Patch 5 POS checkout core"],
  ["src/modules/shell/AppShell.tsx", 'key: "pos"'],
  ["src-tauri/src/core/migrations.rs", "CURRENT_SCHEMA_VERSION: i64 = 5"],
  ["src-tauri/src/core/patching.rs", "P005_pos_checkout_core"],
  ["src-tauri/src/lib.rs", "commands::pos::load_pos_workspace"],
  ["src-tauri/src/lib.rs", "commands::pos::save_pos_hold"],
  ["src-tauri/src/lib.rs", "commands::pos::complete_pos_sale"]
];

let hasError = false;

for (const relativePath of requiredFiles) {
  const fullPath = path.resolve(relativePath);
  if (!fs.existsSync(fullPath)) {
    console.error(`[ERROR] Missing required file: ${relativePath}`);
    hasError = true;
  }
}

for (const [relativePath, snippet] of requiredSnippets) {
  const fullPath = path.resolve(relativePath);
  if (!fs.existsSync(fullPath)) continue;
  const contents = fs.readFileSync(fullPath, "utf8");
  if (!contents.includes(snippet)) {
    console.error(`[ERROR] Expected snippet not found in ${relativePath}: ${snippet}`);
    hasError = true;
  }
}

for (const relativePath of ["package.json", "src-tauri/tauri.conf.json"]) {
  try {
    JSON.parse(fs.readFileSync(path.resolve(relativePath), "utf8"));
  } catch (error) {
    hasError = true;
    console.error(
      `[ERROR] Invalid JSON in ${relativePath}: ${error instanceof Error ? error.message : String(error)}`
    );
  }
}

function walk(dir) {
  const output = [];
  if (!fs.existsSync(dir)) return output;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      output.push(...walk(fullPath));
      continue;
    }
    if (/\.(ts|tsx)$/.test(entry.name)) {
      output.push(fullPath);
    }
  }
  return output;
}

if (ts) {
  for (const fullPath of walk(path.resolve("src"))) {
    const source = fs.readFileSync(fullPath, "utf8");
    const scriptKind = fullPath.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
    const sourceFile = ts.createSourceFile(
      fullPath,
      source,
      ts.ScriptTarget.Latest,
      true,
      scriptKind
    );
    if (sourceFile.parseDiagnostics.length > 0) {
      hasError = true;
      console.error(`[ERROR] TypeScript parse diagnostics in ${path.relative(process.cwd(), fullPath)}`);
      for (const diagnostic of sourceFile.parseDiagnostics) {
        console.error(ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n"));
      }
    }
  }
} else {
  console.warn("[WARN] typescript module not installed; skipping TS parse diagnostics.");
}

const migrationSql = fs.readFileSync(
  path.resolve("src-tauri/src/core/migrations/005_pos_checkout_core.sql"),
  "utf8"
);
for (const token of [
  "register_sessions",
  "sales",
  "sale_lines",
  "sale_payments",
  "sale_holds",
  "idx_sales_business_sale_number"
]) {
  if (!migrationSql.includes(token)) {
    console.error(`[ERROR] Migration 005 is missing expected token: ${token}`);
    hasError = true;
  }
}

if (hasError) {
  process.exit(1);
}

console.log("[OK] Patch 5 structural validation passed.");

```

## files/src/app/AppProvider.tsx

```ts
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type PropsWithChildren
} from "react";
import {
  bootstrapApp,
  createBackupSnapshot,
  createBusinessWorkspace,
  exportFoundationSnapshot,
  previewImportBundle,
  saveBusinessProfile,
  saveWorkspaceConfiguration,
  switchActiveBusiness
} from "../shared/api";
import type {
  AppBootstrap,
  BackupRecord,
  BusinessProfile,
  ImportPreview,
  NewBusinessWorkspaceInput,
  WorkspaceConfigurationInput
} from "../shared/types";

type AppStatus = "loading" | "ready" | "error";

interface AppContextValue {
  status: AppStatus;
  errorMessage: string | null;
  data: AppBootstrap | null;
  refresh: () => Promise<void>;
  saveProfile: (profile: BusinessProfile) => Promise<BusinessProfile>;
  createBusiness: (input: NewBusinessWorkspaceInput) => Promise<BusinessProfile>;
  switchBusiness: (businessId: string) => Promise<BusinessProfile>;
  saveWorkspace: (input: WorkspaceConfigurationInput) => Promise<void>;
  createBackup: () => Promise<BackupRecord>;
  exportFoundation: () => Promise<string>;
  previewImport: (filePath: string) => Promise<ImportPreview>;
}

type RefreshMode = "blocking" | "background";

const AppContext = createContext<AppContextValue | undefined>(undefined);

export function AppProvider({ children }: PropsWithChildren) {
  const [status, setStatus] = useState<AppStatus>("loading");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [data, setData] = useState<AppBootstrap | null>(null);
  const hasLoadedOnceRef = useRef(false);

  const loadBootstrap = useCallback(async (mode: RefreshMode) => {
    if (mode === "blocking" || !hasLoadedOnceRef.current) {
      setStatus("loading");
    }
    setErrorMessage(null);
    try {
      const bootstrap = await bootstrapApp();
      setData(bootstrap);
      hasLoadedOnceRef.current = true;
      setStatus("ready");
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to bootstrap app";
      setErrorMessage(message);
      setStatus("error");
    }
  }, []);

  const refresh = useCallback(async () => {
    await loadBootstrap("background");
  }, [loadBootstrap]);

  useEffect(() => {
    void loadBootstrap("blocking");
  }, [loadBootstrap]);

  const saveProfile = useCallback(
    async (profile: BusinessProfile) => {
      const saved = await saveBusinessProfile(profile);
      await refresh();
      return saved;
    },
    [refresh]
  );

  const createBusiness = useCallback(
    async (input: NewBusinessWorkspaceInput) => {
      const created = await createBusinessWorkspace(input);
      await refresh();
      return created;
    },
    [refresh]
  );

  const switchBusiness = useCallback(
    async (businessId: string) => {
      const result = await switchActiveBusiness(businessId);
      await refresh();
      return result;
    },
    [refresh]
  );

  const saveWorkspace = useCallback(
    async (input: WorkspaceConfigurationInput) => {
      await saveWorkspaceConfiguration(input);
      await refresh();
    },
    [refresh]
  );

  const createBackupAction = useCallback(async () => {
    const result = await createBackupSnapshot();
    await refresh();
    return result;
  }, [refresh]);

  const exportFoundationAction = useCallback(async () => {
    const result = await exportFoundationSnapshot();
    await refresh();
    return result;
  }, [refresh]);

  const previewImportAction = useCallback(async (filePath: string) => {
    return previewImportBundle(filePath);
  }, []);

  const value = useMemo<AppContextValue>(
    () => ({
      status,
      errorMessage,
      data,
      refresh,
      saveProfile,
      createBusiness,
      switchBusiness,
      saveWorkspace,
      createBackup: createBackupAction,
      exportFoundation: exportFoundationAction,
      previewImport: previewImportAction
    }),
    [
      status,
      errorMessage,
      data,
      refresh,
      saveProfile,
      createBusiness,
      switchBusiness,
      saveWorkspace,
      createBackupAction,
      exportFoundationAction,
      previewImportAction
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppState(): AppContextValue {
  const value = useContext(AppContext);
  if (!value) {
    throw new Error("useAppState must be used inside AppProvider");
  }
  return value;
}

export function AppStateView({ children }: PropsWithChildren) {
  const { status, errorMessage, refresh } = useAppState();

  if (status === "loading") {
    return (
      <div className="app-loading-shell">
        <div className="spinner" />
        <h1>Preparing local workspace…</h1>
        <p>
          Initializing migrations, business workspaces, settings profiles,
          catalog foundations, inventory ledgers, POS checkout foundations, and the local patch registry.
        </p>
      </div>
    );
  }

  if (status === "error") {
    return (
      <div className="app-loading-shell">
        <h1>Failed to start the app</h1>
        <p>{errorMessage ?? "Unknown startup error"}</p>
        <button className="primary-button" onClick={() => void refresh()}>
          Retry startup
        </button>
      </div>
    );
  }

  return <>{children}</>;
}

```

## files/src/modules/dashboard/DashboardPage.tsx

```ts
import { useAppState } from "../../app/AppProvider";
import type { NavPage } from "../../shared/types";
import {
  formatCurrency,
  formatDateTime,
  formatModuleList,
  titleCaseWords
} from "../../shared/utils";

interface DashboardPageProps {
  onNavigate: (page: NavPage) => void;
}

export function DashboardPage({ onNavigate }: DashboardPageProps) {
  const { data } = useAppState();

  if (!data) return null;

  return (
    <div className="page-grid">
      <section className="hero-card">
        <div>
          <div className="section-kicker">Patch 5 POS checkout core</div>
          <h2>{data.dashboard.heroTitle}</h2>
          <p>{data.dashboard.heroBody}</p>
        </div>
        <div className="hero-actions">
          <button
            className="primary-button"
            type="button"
            onClick={() => onNavigate("pos")}
          >
            Open POS
          </button>
          <button
            className="secondary-button"
            type="button"
            onClick={() => onNavigate("inventory")}
          >
            Open Inventory
          </button>
        </div>
      </section>

      <section className="card-grid card-grid-5">
        {data.dashboard.kpis.map((kpi) => (
          <article className="card" key={kpi.id}>
            <div className="card-label">{kpi.label}</div>
            <div className="kpi-value">{kpi.value}</div>
            <p className="card-note">{kpi.note}</p>
          </article>
        ))}
      </section>

      <section className="split-grid">
        <article className="card">
          <div className="card-header">
            <h3>Business workspaces</h3>
            <span className="pill success">
              {data.businessWorkspaces.length} configured
            </span>
          </div>
          <div className="stack-list">
            {data.businessWorkspaces.map((workspace) => (
              <div className="list-row" key={workspace.businessId}>
                <div>
                  <strong>
                    {workspace.name}
                    {workspace.businessId === data.activeBusiness.id ? " · active" : ""}
                  </strong>
                  <div className="muted-text">
                    {workspace.code} · {workspace.currencyCode} · {workspace.timezone}
                  </div>
                  <div className="tag-list compact-tags">
                    {workspace.activeModules.map((module) => (
                      <span className="tag" key={`${workspace.businessId}-${module}`}>
                        {titleCaseWords(module)}
                      </span>
                    ))}
                  </div>
                </div>
                <span className="muted-text">{workspace.nextSaleSequence}</span>
              </div>
            ))}
          </div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Current business configuration</h3>
            <span className="pill neutral">{data.activeBusiness.code}</span>
          </div>
          <div className="detail-list">
            <div>
              <span>Theme</span>
              <code>{data.businessSettings.theme}</code>
            </div>
            <div>
              <span>Tax profile</span>
              <code>
                {data.activeTaxProfile.name} · {data.activeTaxProfile.taxLabel} · {data.activeTaxProfile.defaultRate}%
              </code>
            </div>
            <div>
              <span>Receipt profile</span>
              <code>
                {data.activeReceiptProfile.name} · {data.activeReceiptProfile.paperWidth}
              </code>
            </div>
            <div>
              <span>Enabled modules</span>
              <code>
                {formatModuleList(
                  data.businessWorkspaces.find(
                    (workspace) => workspace.businessId === data.activeBusiness.id
                  )?.activeModules ?? []
                )}
              </code>
            </div>
            <div>
              <span>Gross sales today</span>
              <code>
                {formatCurrency(
                  data.posSummary.todayGrossSales,
                  data.activeBusiness.currencyCode
                )}
              </code>
            </div>
            <div>
              <span>Low stock items</span>
              <code>{data.inventorySummary.lowStockItems}</code>
            </div>
          </div>
        </article>
      </section>

      <section className="split-grid">
        <article className="card">
          <div className="card-header">
            <h3>Recent local activity</h3>
            <span className="pill neutral">{data.dashboard.recentActivity.length} rows</span>
          </div>
          <div className="stack-list">
            {data.dashboard.recentActivity.length > 0 ? (
              data.dashboard.recentActivity.map((activity) => (
                <div className="list-row" key={activity.id}>
                  <div>
                    <strong>
                      {activity.category} · {activity.level}
                    </strong>
                    <div className="muted-text">{activity.message}</div>
                  </div>
                  <span className="muted-text">
                    {formatDateTime(activity.createdAt)}
                  </span>
                </div>
              ))
            ) : (
              <p className="muted-text">No local activity has been logged yet.</p>
            )}
          </div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Module status</h3>
          </div>
          <div className="stack-list">
            {data.dashboard.moduleStatuses.map((module) => (
              <div className="list-row" key={module.id}>
                <div>
                  <strong>{module.label}</strong>
                  <div className="muted-text">{module.note}</div>
                </div>
                <span className={`pill ${module.status === "planned" ? "warning" : "success"}`}>
                  {module.status === "coming-next" ? "Coming next" : titleCaseWords(module.status)}
                </span>
              </div>
            ))}
          </div>
        </article>
      </section>
    </div>
  );
}

```

## files/src/modules/data-center/DataCenterPage.tsx

```ts
import { useMemo, useState } from "react";
import { useAppState } from "../../app/AppProvider";
import { formatCurrency, formatDateTime } from "../../shared/utils";

export function DataCenterPage() {
  const { data, createBackup, exportFoundation, previewImport } = useAppState();
  const [statusMessage, setStatusMessage] = useState("");
  const [importPath, setImportPath] = useState("");
  const [previewResult, setPreviewResult] = useState("");

  const latestBackup = useMemo(() => {
    return data?.backups[0] ?? null;
  }, [data?.backups]);

  if (!data) return null;

  async function handleBackup() {
    setStatusMessage("Creating workspace backup snapshot…");
    try {
      const result = await createBackup();
      setStatusMessage(`Backup created: ${result.fileName}`);
    } catch (error) {
      setStatusMessage(
        error instanceof Error ? error.message : "Failed to create backup"
      );
    }
  }

  async function handleExport() {
    setStatusMessage("Exporting workspace foundation snapshot…");
    try {
      const targetPath = await exportFoundation();
      setStatusMessage(`Export written to: ${targetPath}`);
    } catch (error) {
      setStatusMessage(
        error instanceof Error ? error.message : "Failed to export foundation data"
      );
    }
  }

  async function handlePreviewImport() {
    setPreviewResult("Previewing bundle…");
    try {
      const preview = await previewImport(importPath);
      if (!preview.valid) {
        setPreviewResult(
          `Invalid bundle. Warnings: ${preview.warnings.join(" | ")}`
        );
        return;
      }

      setPreviewResult(
        `Bundle OK · type=${preview.bundleType ?? "unknown"} · source=${preview.sourcePatchLevel ?? "unknown"} · generated=${preview.generatedAt ?? "unknown"} · businesses=${preview.businessCount} · categories=${preview.categoryCount} · items=${preview.itemCount} · balances=${preview.stockBalanceCount} · movements=${preview.movementCount} · sales=${preview.saleCount} · held=${preview.heldSaleCount}`
      );
    } catch (error) {
      setPreviewResult(
        error instanceof Error ? error.message : "Preview failed."
      );
    }
  }

  return (
    <div className="page-grid">
      <section className="split-grid">
        <article className="card">
          <div className="card-header">
            <h2>Backup and transfer foundation</h2>
            <span className="pill success">Local only</span>
          </div>
          <p className="card-note">
            Patch 5 extends the local export scope again so workspace bundles now carry
            register sessions, held carts, completed sales, sale lines, and payment rows
            alongside the earlier business, catalog, and inventory foundations.
          </p>

          <div className="inline-actions">
            <button className="primary-button" type="button" onClick={() => void handleBackup()}>
              Create Backup Snapshot
            </button>
            <button className="secondary-button" type="button" onClick={() => void handleExport()}>
              Export Workspace Snapshot
            </button>
          </div>

          <div className="status-banner">{statusMessage || "No action run yet."}</div>

          <div className="detail-list">
            <div>
              <span>Database path</span>
              <code>{data.storage.databasePath}</code>
            </div>
            <div>
              <span>Backup directory</span>
              <code>{data.storage.backupDir}</code>
            </div>
            <div>
              <span>Export directory</span>
              <code>{data.storage.exportDir}</code>
            </div>
            <div>
              <span>Gross sales today</span>
              <code>
                {formatCurrency(data.posSummary.todayGrossSales, data.activeBusiness.currencyCode)}
              </code>
            </div>
          </div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Latest backup</h3>
            <span className="pill neutral">{data.storage.backupCount} total</span>
          </div>
          {latestBackup ? (
            <div className="detail-list">
              <div>
                <span>File name</span>
                <code>{latestBackup.fileName}</code>
              </div>
              <div>
                <span>Created</span>
                <code>{formatDateTime(latestBackup.createdAt)}</code>
              </div>
              <div>
                <span>Status</span>
                <code>{latestBackup.status}</code>
              </div>
              <div>
                <span>Checksum</span>
                <code>{latestBackup.checksum ?? "—"}</code>
              </div>
            </div>
          ) : (
            <p className="muted-text">No backup has been created yet.</p>
          )}
        </article>
      </section>

      <section className="split-grid">
        <article className="card">
          <div className="card-header">
            <h3>Import preview interface</h3>
            <span className="pill warning">Preview only</span>
          </div>
          <p className="card-note">
            Patch 5 still stops at preview validation, but the preview now understands
            POS-aware workspace bundles and surfaces sale and held-cart counts before any
            real restore or transfer flow is attempted.
          </p>

          <label className="form-span-2">
            <span>Existing export bundle path</span>
            <input
              placeholder={data.storage.exportDir}
              value={importPath}
              onChange={(event) => setImportPath(event.target.value)}
            />
          </label>

          <div className="inline-actions">
            <button
              className="secondary-button"
              type="button"
              onClick={() => void handlePreviewImport()}
              disabled={!importPath.trim()}
            >
              Preview Import Bundle
            </button>
          </div>

          <div className="status-banner">{previewResult || "No preview run yet."}</div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Recorded backups</h3>
          </div>
          <div className="stack-list">
            {data.backups.length > 0 ? (
              data.backups.map((backup) => (
                <div className="list-row" key={backup.id}>
                  <div>
                    <strong>{backup.fileName}</strong>
                    <div className="muted-text">{backup.status}</div>
                  </div>
                  <span className="muted-text">
                    {formatDateTime(backup.createdAt)}
                  </span>
                </div>
              ))
            ) : (
              <p className="muted-text">No backup rows yet.</p>
            )}
          </div>
        </article>
      </section>
    </div>
  );
}

```

## files/src/modules/pos/PosPage.tsx

```ts
import { useCallback, useEffect, useMemo, useState } from "react";
import { useAppState } from "../../app/AppProvider";
import {
  completePosSale,
  deletePosHold,
  loadPosWorkspace,
  savePosHold
} from "../../shared/api";
import type {
  PosCartLineInput,
  PosHoldSummary,
  PosPaymentEntryInput,
  PosSaleDetail,
  PosSellableItem,
  PosWorkspace
} from "../../shared/types";
import {
  clampNumber,
  formatCurrency,
  formatDateTime,
  formatPaymentMode,
  formatQuantity,
  roundMoney,
  titleCaseWords
} from "../../shared/utils";

const paymentModeOptions = [
  { value: "cash", label: "Cash" },
  { value: "card", label: "Card" },
  { value: "upi", label: "UPI" },
  { value: "bank_transfer", label: "Bank transfer" },
  { value: "other", label: "Other" }
] as const;

interface PreviewLine {
  item: PosSellableItem;
  quantity: number;
  unitPrice: number;
  grossAmount: number;
  discountAmount: number;
  netAmount: number;
  taxAmount: number;
  totalAmount: number;
  stockIssue: boolean;
  notes: string | null;
}

interface CartPreview {
  lines: PreviewLine[];
  subtotalAmount: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
  amountPaid: number;
  balanceDue: number;
  stockIssueCount: number;
}

const emptyPayment = (): PosPaymentEntryInput => ({
  paymentMode: "cash",
  amount: 0,
  referenceValue: null,
  notes: null
});

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function buildCartPreview(
  sellableItems: PosSellableItem[],
  cartLines: PosCartLineInput[],
  cartDiscountAmount: number,
  payments: PosPaymentEntryInput[]
): CartPreview {
  const itemById = new Map(sellableItems.map((item) => [item.itemId, item]));

  const draftLines = cartLines
    .map((line) => {
      const item = itemById.get(line.itemId);
      if (!item) return null;
      const quantity = clampNumber(line.quantity, 0);
      if (quantity <= 0) return null;
      const unitPrice = roundMoney(
        line.unitPrice !== null && Number.isFinite(line.unitPrice)
          ? line.unitPrice
          : item.sellingPrice
      );
      const grossAmount = roundMoney(unitPrice * quantity);
      const lineDiscount = roundMoney(
        Math.min(clampNumber(line.discountAmount, 0), grossAmount)
      );
      return {
        item,
        quantity,
        unitPrice,
        grossAmount,
        lineDiscount,
        baseAfterLineDiscount: roundMoney(grossAmount - lineDiscount),
        notes: line.notes
      };
    })
    .filter((line): line is NonNullable<typeof line> => Boolean(line));

  const totalEligible = roundMoney(
    draftLines.reduce((sum, line) => sum + line.baseAfterLineDiscount, 0)
  );
  const normalizedCartDiscount = roundMoney(
    Math.min(clampNumber(cartDiscountAmount, 0), totalEligible)
  );

  const allocatedCartDiscounts = draftLines.map(() => 0);
  if (draftLines.length > 0 && totalEligible > 0) {
    let consumed = 0;
    draftLines.forEach((line, index) => {
      if (index === draftLines.length - 1) {
        allocatedCartDiscounts[index] = roundMoney(normalizedCartDiscount - consumed);
        return;
      }
      const share = roundMoney(
        (normalizedCartDiscount * line.baseAfterLineDiscount) / totalEligible
      );
      allocatedCartDiscounts[index] = share;
      consumed = roundMoney(consumed + share);
    });
  }

  const previewLines: PreviewLine[] = draftLines.map((line, index) => {
    const allocatedCartDiscount = allocatedCartDiscounts[index] ?? 0;
    const discountAmount = roundMoney(line.lineDiscount + allocatedCartDiscount);
    const discountedAmount = roundMoney(
      Math.max(0, line.grossAmount - discountAmount)
    );
    const taxRate = clampNumber(line.item.taxRate, 0);
    const pricesIncludeTax = line.item.pricesIncludeTax;

    let netAmount = discountedAmount;
    let taxAmount = 0;
    let totalAmount = discountedAmount;

    if (pricesIncludeTax) {
      taxAmount =
        taxRate > 0
          ? roundMoney((discountedAmount * taxRate) / (100 + taxRate))
          : 0;
      netAmount = roundMoney(discountedAmount - taxAmount);
      totalAmount = discountedAmount;
    } else {
      netAmount = discountedAmount;
      taxAmount = taxRate > 0 ? roundMoney((netAmount * taxRate) / 100) : 0;
      totalAmount = roundMoney(netAmount + taxAmount);
    }

    return {
      item: line.item,
      quantity: line.quantity,
      unitPrice: line.unitPrice,
      grossAmount: line.grossAmount,
      discountAmount,
      netAmount,
      taxAmount,
      totalAmount,
      stockIssue:
        line.item.trackStock && line.quantity - line.item.onHandQuantity > 0.000001,
      notes: line.notes
    };
  });

  const subtotalAmount = roundMoney(
    previewLines.reduce((sum, line) => sum + line.grossAmount, 0)
  );
  const discountAmount = roundMoney(
    previewLines.reduce((sum, line) => sum + line.discountAmount, 0)
  );
  const taxAmount = roundMoney(
    previewLines.reduce((sum, line) => sum + line.taxAmount, 0)
  );
  const totalAmount = roundMoney(
    previewLines.reduce((sum, line) => sum + line.totalAmount, 0)
  );
  const amountPaid = roundMoney(
    payments.reduce((sum, payment) => sum + clampNumber(payment.amount, 0), 0)
  );
  const balanceDue = roundMoney(Math.max(0, totalAmount - amountPaid));

  return {
    lines: previewLines,
    subtotalAmount,
    discountAmount,
    taxAmount,
    totalAmount,
    amountPaid,
    balanceDue,
    stockIssueCount: previewLines.filter((line) => line.stockIssue).length
  };
}

function buildReceiptHtml(
  detail: PosSaleDetail,
  businessName: string,
  businessCode: string,
  currencyCode: string,
  receiptFooter: string | null
): string {
  const lineMarkup = detail.lines
    .map(
      (line) => `
        <tr>
          <td>${escapeHtml(line.itemName)}</td>
          <td style="text-align:right;">${escapeHtml(formatQuantity(line.quantity))}</td>
          <td style="text-align:right;">${escapeHtml(formatCurrency(line.totalAmount, currencyCode))}</td>
        </tr>
      `
    )
    .join("");

  const paymentMarkup =
    detail.payments.length > 0
      ? detail.payments
          .map(
            (payment) => `
              <tr>
                <td>${escapeHtml(formatPaymentMode(payment.paymentMode))}</td>
                <td style="text-align:right;">${escapeHtml(formatCurrency(payment.amount, currencyCode))}</td>
              </tr>
            `
          )
          .join("")
      : '<tr><td>Unpaid</td><td style="text-align:right;">—</td></tr>';

  return `
    <!doctype html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${escapeHtml(detail.sale.saleNumber)}</title>
        <style>
          body { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; margin: 18px; color: #111827; }
          h1, h2, p { margin: 0; }
          .receipt { max-width: 360px; margin: 0 auto; }
          .receipt-header { text-align: center; margin-bottom: 12px; }
          .muted { color: #4b5563; font-size: 12px; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; }
          td { padding: 4px 0; vertical-align: top; }
          .divider { border-top: 1px dashed #9ca3af; margin: 10px 0; }
          .totals td { font-weight: 700; }
        </style>
      </head>
      <body>
        <div class="receipt">
          <div class="receipt-header">
            <h1>${escapeHtml(businessName)}</h1>
            <p class="muted">${escapeHtml(businessCode)} · ${escapeHtml(detail.sale.saleNumber)}</p>
            <p class="muted">${escapeHtml(formatDateTime(detail.sale.completedAt))}</p>
          </div>
          <div class="divider"></div>
          <table>
            <tbody>${lineMarkup}</tbody>
          </table>
          <div class="divider"></div>
          <table>
            <tbody>
              <tr><td>Subtotal</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.subtotalAmount, currencyCode))}</td></tr>
              <tr><td>Discount</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.discountAmount, currencyCode))}</td></tr>
              <tr><td>Tax</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.taxAmount, currencyCode))}</td></tr>
              <tr class="totals"><td>Total</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.totalAmount, currencyCode))}</td></tr>
              <tr><td>Paid</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.amountPaid, currencyCode))}</td></tr>
              <tr><td>Due</td><td style="text-align:right;">${escapeHtml(formatCurrency(detail.sale.balanceDue, currencyCode))}</td></tr>
            </tbody>
          </table>
          <div class="divider"></div>
          <table>
            <tbody>${paymentMarkup}</tbody>
          </table>
          ${receiptFooter ? `<div class="divider"></div><p class="muted">${escapeHtml(receiptFooter)}</p>` : ""}
        </div>
        <script>window.print();</script>
      </body>
    </html>
  `;
}

export function PosPage() {
  const { data, refresh } = useAppState();
  const [workspace, setWorkspace] = useState<PosWorkspace | null>(null);
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [search, setSearch] = useState("");
  const [cartLines, setCartLines] = useState<PosCartLineInput[]>([]);
  const [cartDiscountAmount, setCartDiscountAmount] = useState("0");
  const [saleNotes, setSaleNotes] = useState("");
  const [holdLabel, setHoldLabel] = useState("");
  const [selectedHoldId, setSelectedHoldId] = useState<string | null>(null);
  const [payments, setPayments] = useState<PosPaymentEntryInput[]>([emptyPayment()]);
  const [lastReceipt, setLastReceipt] = useState<PosSaleDetail | null>(null);

  const loadWorkspace = useCallback(async () => {
    setLoading(true);
    try {
      const next = await loadPosWorkspace();
      setWorkspace(next);
    } catch (error) {
      setStatusMessage(
        error instanceof Error ? error.message : "Failed to load POS workspace."
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadWorkspace();
  }, [loadWorkspace, data?.activeBusiness.id]);

  const filteredItems = useMemo(() => {
    if (!workspace) return [];
    const query = search.trim().toLowerCase();
    return workspace.sellableItems.filter((item) => {
      if (!query) return true;
      const haystack = [
        item.name,
        item.displayName,
        item.categoryName,
        item.sku,
        item.primaryBarcode,
        item.itemKind,
        item.taxLabel
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return haystack.includes(query);
    });
  }, [workspace, search]);

  const preview = useMemo(
    () =>
      buildCartPreview(
        workspace?.sellableItems ?? [],
        cartLines,
        Number(cartDiscountAmount || 0),
        payments
      ),
    [workspace, cartLines, cartDiscountAmount, payments]
  );

  function resetComposer() {
    setCartLines([]);
    setCartDiscountAmount("0");
    setSaleNotes("");
    setHoldLabel("");
    setSelectedHoldId(null);
    setPayments([emptyPayment()]);
  }

  function addItemToCart(item: PosSellableItem) {
    setCartLines((current) => {
      const existing = current.find((line) => line.itemId === item.itemId);
      if (existing) {
        return current.map((line) =>
          line.itemId === item.itemId
            ? { ...line, quantity: roundMoney(line.quantity + 1) }
            : line
        );
      }
      return [
        ...current,
        {
          itemId: item.itemId,
          quantity: 1,
          unitPrice: item.sellingPrice,
          discountAmount: 0,
          notes: null
        }
      ];
    });
  }

  function updateCartLine(itemId: string, patch: Partial<PosCartLineInput>) {
    setCartLines((current) =>
      current.map((line) => (line.itemId === itemId ? { ...line, ...patch } : line))
    );
  }

  function removeCartLine(itemId: string) {
    setCartLines((current) => current.filter((line) => line.itemId !== itemId));
  }

  function setPaymentDraft(index: number, patch: Partial<PosPaymentEntryInput>) {
    setPayments((current) =>
      current.map((payment, paymentIndex) =>
        paymentIndex === index ? { ...payment, ...patch } : payment
      )
    );
  }

  async function handleSaveHold() {
    if (preview.lines.length === 0) {
      setStatusMessage("Add at least one item before saving a hold.");
      return;
    }

    setStatusMessage("Saving held cart…");
    try {
      const saved = await savePosHold({
        id: selectedHoldId,
        holdLabel: holdLabel.trim() || "Held cart",
        notes: saleNotes.trim() || null,
        cartLines,
        cartDiscountAmount: Number(cartDiscountAmount || 0)
      });
      setSelectedHoldId(saved.id);
      setHoldLabel(saved.holdLabel);
      setStatusMessage(`Held cart saved: ${saved.holdCode}`);
      await Promise.all([loadWorkspace(), refresh()]);
    } catch (error) {
      setStatusMessage(error instanceof Error ? error.message : "Failed to save hold.");
    }
  }

  function handleResumeHold(hold: PosHoldSummary) {
    setSelectedHoldId(hold.id);
    setHoldLabel(hold.holdLabel);
    setSaleNotes(hold.notes ?? "");
    setCartDiscountAmount(String(hold.cartDiscountAmount ?? 0));
    setCartLines(hold.cartLines);
    setPayments([emptyPayment()]);
    setStatusMessage(`Resumed held cart ${hold.holdCode}.`);
  }

  async function handleDeleteHold(holdId: string) {
    setStatusMessage("Removing held cart…");
    try {
      await deletePosHold(holdId);
      if (selectedHoldId === holdId) {
        resetComposer();
      }
      setStatusMessage("Held cart removed.");
      await Promise.all([loadWorkspace(), refresh()]);
    } catch (error) {
      setStatusMessage(error instanceof Error ? error.message : "Failed to remove hold.");
    }
  }

  async function handleCompleteSale() {
    if (preview.lines.length === 0) {
      setStatusMessage("Add at least one item before completing a sale.");
      return;
    }
    if (preview.stockIssueCount > 0) {
      setStatusMessage("Resolve stock shortages before completing this sale.");
      return;
    }

    setStatusMessage("Completing local sale…");
    try {
      const completed = await completePosSale({
        holdId: selectedHoldId,
        notes: saleNotes.trim() || null,
        cartLines,
        cartDiscountAmount: Number(cartDiscountAmount || 0),
        payments: payments.filter((payment) => clampNumber(payment.amount, 0) > 0)
      });
      setLastReceipt(completed);
      resetComposer();
      setStatusMessage(`Sale completed: ${completed.sale.saleNumber}`);
      await Promise.all([loadWorkspace(), refresh()]);
    } catch (error) {
      setStatusMessage(error instanceof Error ? error.message : "Failed to complete sale.");
    }
  }

  function handlePrepareExactCash() {
    setPayments([
      {
        paymentMode: "cash",
        amount: preview.totalAmount,
        referenceValue: null,
        notes: null
      }
    ]);
  }

  function handlePrintReceipt() {
    if (!lastReceipt || !data) return;
    const popup = window.open("", "_blank", "width=420,height=720");
    if (!popup) {
      setStatusMessage("The receipt window was blocked by the browser runtime.");
      return;
    }

    popup.document.open();
    popup.document.write(
      buildReceiptHtml(
        lastReceipt,
        data.activeBusiness.name,
        data.activeBusiness.code,
        data.activeBusiness.currencyCode,
        data.activeReceiptProfile.footerText ?? data.businessSettings.receiptFooter ?? null
      )
    );
    popup.document.close();
  }

  if (!data) return null;

  return (
    <div className="page-grid">
      <section className="hero-card">
        <div>
          <div className="section-kicker">Patch 5 POS checkout core</div>
          <h2>Fast local checkout foundation</h2>
          <p>
            Build bills from local catalog items, park carts as held orders, capture
            split or partial payments, and generate receipt-ready sale snapshots without
            any cloud dependency.
          </p>
        </div>
        <div className="hero-actions align-start">
          <div className="summary-chip">
            <strong>{workspace?.registerLabel ?? "Main register"}</strong>
            <span>Register</span>
          </div>
          <div className="summary-chip">
            <strong>{data.posSummary.heldSaleCount}</strong>
            <span>Held carts</span>
          </div>
          <div className="summary-chip">
            <strong>
              {formatCurrency(data.posSummary.todayGrossSales, data.activeBusiness.currencyCode)}
            </strong>
            <span>Gross today</span>
          </div>
        </div>
      </section>

      <section className="split-grid pos-layout">
        <article className="card pos-item-browser">
          <div className="card-header">
            <h2>Sellable items</h2>
            <span className="pill success">
              {workspace?.sellableItems.length ?? 0} available
            </span>
          </div>

          <label className="form-span-2">
            <span>Search by item, category, SKU, or barcode</span>
            <input
              placeholder="Espresso, bread, service fee, 8901..."
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </label>

          <div className="pos-item-list">
            {filteredItems.map((item) => (
              <button
                className="pos-item-card"
                key={item.itemId}
                type="button"
                onClick={() => addItemToCart(item)}
              >
                <div>
                  <strong>{item.displayName || item.name}</strong>
                  <div className="muted-text">
                    {item.categoryName || titleCaseWords(item.itemKind)}
                    {item.sku ? ` · ${item.sku}` : ""}
                  </div>
                </div>
                <div className="pos-item-meta">
                  <span>
                    {formatCurrency(item.sellingPrice, data.activeBusiness.currencyCode)}
                  </span>
                  {item.trackStock ? (
                    <small>
                      Stock {formatQuantity(item.onHandQuantity)}
                      {item.unitCode ? ` ${item.unitCode}` : ""}
                    </small>
                  ) : (
                    <small>No stock tracking</small>
                  )}
                </div>
              </button>
            ))}
            {!loading && filteredItems.length === 0 ? (
              <p className="muted-text">No sellable items matched the current search.</p>
            ) : null}
          </div>
        </article>

        <article className="card pos-cart-card">
          <div className="card-header">
            <h2>Cart and checkout</h2>
            <span className={`pill ${preview.stockIssueCount > 0 ? "warning" : "success"}`}>
              {preview.lines.length} line(s)
            </span>
          </div>

          <div className="stack-list">
            {preview.lines.length > 0 ? (
              preview.lines.map((line) => (
                <div className="pos-cart-line" key={line.item.itemId}>
                  <div className="pos-cart-line-main">
                    <strong>{line.item.displayName || line.item.name}</strong>
                    <div className="muted-text">
                      {titleCaseWords(line.item.itemKind)}
                      {line.item.taxLabel ? ` · ${line.item.taxLabel}` : ""}
                    </div>
                    {line.stockIssue ? (
                      <div className="pill warning">
                        Requested {formatQuantity(line.quantity)} but only {formatQuantity(line.item.onHandQuantity)} in stock
                      </div>
                    ) : null}
                  </div>
                  <div className="pos-cart-line-fields">
                    <label>
                      <span>Qty</span>
                      <input
                        type="number"
                        min={line.item.allowFractional ? "0.001" : "1"}
                        step={line.item.allowFractional ? "0.001" : "1"}
                        value={cartLines.find((entry) => entry.itemId === line.item.itemId)?.quantity ?? line.quantity}
                        onChange={(event) =>
                          updateCartLine(line.item.itemId, {
                            quantity: Number(event.target.value)
                          })
                        }
                      />
                    </label>
                    <label>
                      <span>Price</span>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={cartLines.find((entry) => entry.itemId === line.item.itemId)?.unitPrice ?? line.unitPrice}
                        onChange={(event) =>
                          updateCartLine(line.item.itemId, {
                            unitPrice: Number(event.target.value)
                          })
                        }
                      />
                    </label>
                    <label>
                      <span>Discount</span>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={cartLines.find((entry) => entry.itemId === line.item.itemId)?.discountAmount ?? 0}
                        onChange={(event) =>
                          updateCartLine(line.item.itemId, {
                            discountAmount: Number(event.target.value)
                          })
                        }
                      />
                    </label>
                    <button
                      className="secondary-button"
                      type="button"
                      onClick={() => removeCartLine(line.item.itemId)}
                    >
                      Remove
                    </button>
                  </div>
                  <div className="pos-cart-line-total">
                    {formatCurrency(line.totalAmount, data.activeBusiness.currencyCode)}
                  </div>
                </div>
              ))
            ) : (
              <p className="muted-text">
                No cart lines yet. Click a sellable item on the left to start a bill.
              </p>
            )}
          </div>

          <div className="form-grid pos-cart-form-grid">
            <label>
              <span>Cart discount</span>
              <input
                type="number"
                min="0"
                step="0.01"
                value={cartDiscountAmount}
                onChange={(event) => setCartDiscountAmount(event.target.value)}
              />
            </label>
            <label>
              <span>Hold label</span>
              <input
                placeholder="Counter order / takeaway"
                value={holdLabel}
                onChange={(event) => setHoldLabel(event.target.value)}
              />
            </label>
            <label className="form-span-2">
              <span>Sale notes</span>
              <textarea
                rows={3}
                value={saleNotes}
                onChange={(event) => setSaleNotes(event.target.value)}
              />
            </label>
          </div>

          <div className="card-header pos-payment-header">
            <h3>Payments</h3>
            <button
              className="secondary-button"
              type="button"
              onClick={() => setPayments((current) => [...current, emptyPayment()])}
            >
              Add payment row
            </button>
          </div>
          <div className="stack-list">
            {payments.map((payment, index) => (
              <div className="pos-payment-row" key={`payment-${index}`}>
                <select
                  value={payment.paymentMode}
                  onChange={(event) =>
                    setPaymentDraft(index, { paymentMode: event.target.value })
                  }
                >
                  {paymentModeOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={payment.amount}
                  onChange={(event) =>
                    setPaymentDraft(index, { amount: Number(event.target.value) })
                  }
                />
                <input
                  placeholder="Reference"
                  value={payment.referenceValue ?? ""}
                  onChange={(event) =>
                    setPaymentDraft(index, {
                      referenceValue: event.target.value || null
                    })
                  }
                />
                <button
                  className="secondary-button"
                  type="button"
                  onClick={() =>
                    setPayments((current) =>
                      current.length === 1
                        ? [emptyPayment()]
                        : current.filter((_, paymentIndex) => paymentIndex !== index)
                    )
                  }
                >
                  Remove
                </button>
              </div>
            ))}
          </div>

          <div className="detail-list pos-summary-list">
            <div>
              <span>Subtotal</span>
              <code>{formatCurrency(preview.subtotalAmount, data.activeBusiness.currencyCode)}</code>
            </div>
            <div>
              <span>Discount</span>
              <code>{formatCurrency(preview.discountAmount, data.activeBusiness.currencyCode)}</code>
            </div>
            <div>
              <span>Tax</span>
              <code>{formatCurrency(preview.taxAmount, data.activeBusiness.currencyCode)}</code>
            </div>
            <div>
              <span>Total</span>
              <code>{formatCurrency(preview.totalAmount, data.activeBusiness.currencyCode)}</code>
            </div>
            <div>
              <span>Paid</span>
              <code>{formatCurrency(preview.amountPaid, data.activeBusiness.currencyCode)}</code>
            </div>
            <div>
              <span>Balance due</span>
              <code>{formatCurrency(preview.balanceDue, data.activeBusiness.currencyCode)}</code>
            </div>
          </div>

          <div className="inline-actions">
            <button className="secondary-button" type="button" onClick={handlePrepareExactCash}>
              Use exact cash
            </button>
            <button className="secondary-button" type="button" onClick={() => void handleSaveHold()}>
              Save Hold
            </button>
            <button className="secondary-button" type="button" onClick={resetComposer}>
              Clear Cart
            </button>
            <button
              className="primary-button"
              type="button"
              onClick={() => void handleCompleteSale()}
              disabled={preview.lines.length === 0 || preview.stockIssueCount > 0}
            >
              Complete Sale
            </button>
          </div>

          <div className="status-banner">{statusMessage || "No POS action run yet."}</div>
        </article>
      </section>

      <section className="split-grid">
        <article className="card">
          <div className="card-header">
            <h3>Held carts</h3>
            <span className="pill neutral">{workspace?.heldSales.length ?? 0} total</span>
          </div>
          <div className="stack-list">
            {workspace?.heldSales.length ? (
              workspace.heldSales.map((hold) => (
                <div className="list-row" key={hold.id}>
                  <div>
                    <strong>
                      {hold.holdCode} · {hold.holdLabel}
                    </strong>
                    <div className="muted-text">
                      {hold.itemCount} line(s) · {formatCurrency(hold.totalAmount, data.activeBusiness.currencyCode)}
                    </div>
                    <div className="muted-text">Updated {formatDateTime(hold.updatedAt)}</div>
                  </div>
                  <div className="inline-actions compact-actions">
                    <button
                      className="secondary-button"
                      type="button"
                      onClick={() => handleResumeHold(hold)}
                    >
                      Resume
                    </button>
                    <button
                      className="secondary-button"
                      type="button"
                      onClick={() => void handleDeleteHold(hold.id)}
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <p className="muted-text">No held carts yet.</p>
            )}
          </div>
        </article>

        <article className="card">
          <div className="card-header">
            <h3>Recent sales</h3>
            <span className="pill success">{workspace?.recentSales.length ?? 0} shown</span>
          </div>
          <div className="stack-list">
            {workspace?.recentSales.length ? (
              workspace.recentSales.map((sale) => (
                <div className="list-row" key={sale.id}>
                  <div>
                    <strong>{sale.saleNumber}</strong>
                    <div className="muted-text">
                      {sale.itemCount} item(s) · {formatPaymentMode(sale.paymentStatus)}
                    </div>
                    <div className="muted-text">{formatDateTime(sale.completedAt)}</div>
                  </div>
                  <div className="align-right-text">
                    <strong>
                      {formatCurrency(sale.totalAmount, data.activeBusiness.currencyCode)}
                    </strong>
                    <div className="muted-text">
                      Paid {formatCurrency(sale.amountPaid, data.activeBusiness.currencyCode)}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="muted-text">No sales have been completed yet.</p>
            )}
          </div>
        </article>
      </section>

      {lastReceipt ? (
        <section className="card">
          <div className="card-header">
            <h3>Last completed receipt</h3>
            <div className="inline-actions compact-actions">
              <span className="pill success">{lastReceipt.sale.saleNumber}</span>
              <button className="secondary-button" type="button" onClick={handlePrintReceipt}>
                Print Receipt
              </button>
            </div>
          </div>
          <div className="split-grid receipt-preview-layout">
            <div>
              <div className="detail-list">
                <div>
                  <span>Total</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.totalAmount, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Paid</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.amountPaid, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Due</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.balanceDue, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Completed</span>
                  <code>{formatDateTime(lastReceipt.sale.completedAt)}</code>
                </div>
              </div>
            </div>
            <div className="receipt-preview">
              <div className="receipt-preview-title">{data.activeBusiness.name}</div>
              <div className="receipt-preview-subtitle">
                {data.activeBusiness.code} · {lastReceipt.sale.saleNumber}
              </div>
              <div className="receipt-preview-divider" />
              <div className="stack-list compact-stack">
                {lastReceipt.lines.map((line) => (
                  <div className="list-row" key={line.id}>
                    <div>
                      <strong>{line.itemName}</strong>
                      <div className="muted-text">
                        {formatQuantity(line.quantity)} × {formatCurrency(line.unitPrice, data.activeBusiness.currencyCode)}
                      </div>
                    </div>
                    <span>
                      {formatCurrency(line.totalAmount, data.activeBusiness.currencyCode)}
                    </span>
                  </div>
                ))}
              </div>
              <div className="receipt-preview-divider" />
              <div className="detail-list compact-detail-list">
                <div>
                  <span>Subtotal</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.subtotalAmount, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Discount</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.discountAmount, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Tax</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.taxAmount, data.activeBusiness.currencyCode)}
                  </code>
                </div>
                <div>
                  <span>Total</span>
                  <code>
                    {formatCurrency(lastReceipt.sale.totalAmount, data.activeBusiness.currencyCode)}
                  </code>
                </div>
              </div>
            </div>
          </div>
        </section>
      ) : null}
    </div>
  );
}

```

## files/src/modules/shell/AppShell.tsx

```ts
import { useEffect, useMemo, useState } from "react";
import { useAppState } from "../../app/AppProvider";
import type { NavPage } from "../../shared/types";
import { classNames, formatCurrency, formatModuleList } from "../../shared/utils";
import { DashboardPage } from "../dashboard/DashboardPage";
import { PosPage } from "../pos/PosPage";
import { CatalogPage } from "../catalog/CatalogPage";
import { InventoryPage } from "../inventory/InventoryPage";
import { BusinessPage } from "../business/BusinessPage";
import { SettingsPage } from "../settings/SettingsPage";
import { DataCenterPage } from "../data-center/DataCenterPage";

const NAV_STORAGE_KEY = "lfbm.activeNavPage";

const navItems: Array<{ key: NavPage; label: string; description: string }> = [
  {
    key: "dashboard",
    label: "Dashboard",
    description: "Local business overview"
  },
  {
    key: "pos",
    label: "POS",
    description: "Checkout, holds, receipts"
  },
  {
    key: "catalog",
    label: "Catalog",
    description: "Products, menu, services"
  },
  {
    key: "inventory",
    label: "Inventory",
    description: "Stock ledger and balances"
  },
  {
    key: "business",
    label: "Businesses",
    description: "Profiles and switching"
  },
  {
    key: "settings",
    label: "Settings",
    description: "Tax, receipt, modules"
  },
  {
    key: "data-center",
    label: "Data Center",
    description: "Backup and transfer foundation"
  }
];

export function AppShell() {
  const { data, switchBusiness } = useAppState();
  const [activePage, setActivePage] = useState<NavPage>(() => {
    const stored = window.localStorage.getItem(NAV_STORAGE_KEY) as NavPage | null;
    return stored ?? "dashboard";
  });
  const [switchStatus, setSwitchStatus] = useState<string>("");

  useEffect(() => {
    window.localStorage.setItem(NAV_STORAGE_KEY, activePage);
  }, [activePage]);

  useEffect(() => {
    setSwitchStatus("");
  }, [data?.activeBusiness.id]);

  const pageTitle = useMemo(() => {
    return navItems.find((item) => item.key === activePage)?.label ?? "Dashboard";
  }, [activePage]);

  const activeWorkspace = useMemo(() => {
    return data?.businessWorkspaces.find(
      (workspace) => workspace.businessId === data.activeBusiness.id
    );
  }, [data]);

  if (!data) {
    return null;
  }

  async function handleBusinessSwitch(nextBusinessId: string) {
    if (nextBusinessId === data.activeBusiness.id) {
      return;
    }

    setSwitchStatus("Switching active business…");
    try {
      const switched = await switchBusiness(nextBusinessId);
      setSwitchStatus(`Switched to ${switched.name}.`);
    } catch (error) {
      setSwitchStatus(
        error instanceof Error ? error.message : "Failed to switch business."
      );
    }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <div className="brand-badge">P5</div>
          <div>
            <strong>Local Business Manager</strong>
            <div className="muted-text">
              {data.appInfo.version} · {data.appInfo.patchLevel}
            </div>
          </div>
        </div>

        <div className="sidebar-section-label">Workspace</div>
        <nav className="nav-list">
          {navItems.map((item) => (
            <button
              key={item.key}
              type="button"
              className={classNames(
                "nav-item",
                activePage === item.key && "nav-item-active"
              )}
              onClick={() => setActivePage(item.key)}
            >
              <span className="nav-title">{item.label}</span>
              <span className="nav-description">{item.description}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-section-label">Active business</div>
        <div className="sidebar-card">
          <div className="sidebar-card-title">{data.activeBusiness.name}</div>
          <div className="muted-text">
            {data.activeBusiness.businessType} · {data.activeBusiness.currencyCode}
          </div>
          <label className="sidebar-field">
            <span>Switch workspace</span>
            <select
              className="sidebar-select"
              value={data.activeBusiness.id}
              onChange={(event) => void handleBusinessSwitch(event.target.value)}
            >
              {data.businessWorkspaces.map((workspace) => (
                <option key={workspace.businessId} value={workspace.businessId}>
                  {workspace.name} ({workspace.code})
                </option>
              ))}
            </select>
          </label>
          <div className="sidebar-metadata-grid">
            <div>
              <span>Today sales</span>
              <strong>{data.posSummary.todaySaleCount}</strong>
            </div>
            <div>
              <span>Held carts</span>
              <strong>{data.posSummary.heldSaleCount}</strong>
            </div>
            <div>
              <span>Tracked stock</span>
              <strong>{data.inventorySummary.totalTrackedItems}</strong>
            </div>
            <div>
              <span>Low stock</span>
              <strong>{data.inventorySummary.lowStockItems}</strong>
            </div>
          </div>
          <div className="muted-text small-text">
            {switchStatus ||
              `${formatCurrency(data.posSummary.todayGrossSales, data.activeBusiness.currencyCode)} today · ${activeWorkspace?.nextSaleSequence ?? "Sequence pending"}`}
          </div>
        </div>

        <div className="sidebar-section-label">Business mode</div>
        <div className="sidebar-card">
          <div className="sidebar-pill success">POS checkout ready</div>
          <div className="sidebar-pill neutral">Inventory ledger ready</div>
          <div className="sidebar-pill neutral">Catalog core ready</div>
          <div className="muted-text small-text">
            {formatModuleList(activeWorkspace?.activeModules ?? [])}
          </div>
        </div>
      </aside>

      <main className="workspace">
        <header className="workspace-header">
          <div>
            <h1>{pageTitle}</h1>
            <p>
              Patch 5 adds the first local checkout workflow with cart handling,
              split and partial payment capture, held orders, recent sales, and
              receipt-ready sale snapshots while keeping the app fully offline.
            </p>
          </div>
          <div className="workspace-header-meta">
            <span className="meta-chip">Business: {data.activeBusiness.code}</span>
            <span className="meta-chip">
              Sales today: {data.posSummary.todaySaleCount}
            </span>
            <span className="meta-chip">
              Gross today: {formatCurrency(data.posSummary.todayGrossSales, data.activeBusiness.currencyCode)}
            </span>
            <span className="meta-chip">Held carts: {data.posSummary.heldSaleCount}</span>
            <span className="meta-chip">Schema v{data.appInfo.schemaVersion}</span>
          </div>
        </header>

        <section className="workspace-content">
          {activePage === "dashboard" && (
            <DashboardPage onNavigate={setActivePage} />
          )}
          {activePage === "pos" && <PosPage />}
          {activePage === "catalog" && <CatalogPage />}
          {activePage === "inventory" && <InventoryPage />}
          {activePage === "business" && <BusinessPage />}
          {activePage === "settings" && <SettingsPage />}
          {activePage === "data-center" && <DataCenterPage />}
        </section>
      </main>
    </div>
  );
}

```

## files/src/shared/api.ts

```ts
import { invoke } from "@tauri-apps/api/core";
import type {
  AppBootstrap,
  BackupRecord,
  BusinessProfile,
  CatalogCategory,
  CatalogItem,
  CatalogUnit,
  CatalogWorkspace,
  CompletePosSaleInput,
  ImportPreview,
  InventoryMovement,
  InventoryStockItem,
  InventoryWorkspace,
  NewBusinessWorkspaceInput,
  PosHoldSummary,
  PosSaleDetail,
  PosWorkspace,
  SaveCatalogCategoryInput,
  SaveCatalogItemInput,
  SaveCatalogUnitInput,
  SaveInventoryMovementInput,
  SaveInventoryStockRuleInput,
  SavePosHoldInput,
  WorkspaceConfigurationInput
} from "./types";

export async function bootstrapApp(): Promise<AppBootstrap> {
  return invoke<AppBootstrap>("bootstrap_app");
}

export async function saveBusinessProfile(
  profile: BusinessProfile
): Promise<BusinessProfile> {
  return invoke<BusinessProfile>("save_business_profile", { profile });
}

export async function createBusinessWorkspace(
  input: NewBusinessWorkspaceInput
): Promise<BusinessProfile> {
  return invoke<BusinessProfile>("create_business_workspace", { input });
}

export async function switchActiveBusiness(
  businessId: string
): Promise<BusinessProfile> {
  return invoke<BusinessProfile>("switch_active_business", {
    businessId
  });
}

export async function saveWorkspaceConfiguration(
  input: WorkspaceConfigurationInput
): Promise<void> {
  return invoke<void>("save_workspace_configuration", { input });
}

export async function loadCatalogWorkspace(): Promise<CatalogWorkspace> {
  return invoke<CatalogWorkspace>("load_catalog_workspace");
}

export async function saveCatalogCategory(
  input: SaveCatalogCategoryInput
): Promise<CatalogCategory> {
  return invoke<CatalogCategory>("save_catalog_category", { input });
}

export async function saveCatalogUnit(
  input: SaveCatalogUnitInput
): Promise<CatalogUnit> {
  return invoke<CatalogUnit>("save_catalog_unit", { input });
}

export async function saveCatalogItem(
  input: SaveCatalogItemInput
): Promise<CatalogItem> {
  return invoke<CatalogItem>("save_catalog_item", { input });
}

export async function setCatalogItemArchived(
  itemId: string,
  archived: boolean
): Promise<CatalogItem> {
  return invoke<CatalogItem>("set_catalog_item_archived", {
    itemId,
    archived
  });
}

export async function loadInventoryWorkspace(): Promise<InventoryWorkspace> {
  return invoke<InventoryWorkspace>("load_inventory_workspace");
}

export async function recordInventoryMovement(
  input: SaveInventoryMovementInput
): Promise<InventoryMovement> {
  return invoke<InventoryMovement>("record_inventory_movement", { input });
}

export async function saveInventoryStockRule(
  input: SaveInventoryStockRuleInput
): Promise<InventoryStockItem> {
  return invoke<InventoryStockItem>("save_inventory_stock_rule", { input });
}

export async function loadPosWorkspace(): Promise<PosWorkspace> {
  return invoke<PosWorkspace>("load_pos_workspace");
}

export async function savePosHold(input: SavePosHoldInput): Promise<PosHoldSummary> {
  return invoke<PosHoldSummary>("save_pos_hold", { input });
}

export async function deletePosHold(holdId: string): Promise<void> {
  return invoke<void>("delete_pos_hold", { holdId });
}

export async function completePosSale(
  input: CompletePosSaleInput
): Promise<PosSaleDetail> {
  return invoke<PosSaleDetail>("complete_pos_sale", { input });
}

export async function createBackupSnapshot(): Promise<BackupRecord> {
  return invoke<BackupRecord>("create_backup_snapshot");
}

export async function exportFoundationSnapshot(): Promise<string> {
  return invoke<string>("export_foundation_snapshot");
}

export async function previewImportBundle(
  filePath: string
): Promise<ImportPreview> {
  return invoke<ImportPreview>("preview_import_bundle", { filePath });
}

```

## files/src/shared/types.ts

```ts
export interface BusinessProfile {
  id: string;
  name: string;
  legalName: string | null;
  code: string;
  businessType: string;
  currencyCode: string;
  taxMode: string;
  phone: string | null;
  email: string | null;
  addressLine1: string | null;
  addressLine2: string | null;
  city: string | null;
  state: string | null;
  postalCode: string | null;
  country: string | null;
  createdAt: string;
  updatedAt: string;
  archivedAt: string | null;
}

export interface BusinessSettings {
  businessId: string;
  timezone: string;
  locale: string;
  dateFormat: string;
  theme: string;
  taxLabel: string;
  defaultTaxRate: number;
  pricesIncludeTax: boolean;
  receiptFooter: string | null;
  receiptShowAddress: boolean;
  receiptShowPhone: boolean;
  autoBackupEnabled: boolean;
  backupDirectory: string | null;
  moduleRestaurantEnabled: boolean;
  moduleRetailEnabled: boolean;
  moduleInventoryEnabled: boolean;
  moduleServicesEnabled: boolean;
  updatedAt: string;
}

export interface TaxProfile {
  id: string;
  businessId: string;
  name: string;
  taxLabel: string;
  defaultRate: number;
  pricesIncludeTax: boolean;
  isDefault: boolean;
  updatedAt: string;
}

export interface ReceiptProfile {
  id: string;
  businessId: string;
  name: string;
  footerText: string | null;
  showAddress: boolean;
  showPhone: boolean;
  showEmail: boolean;
  showBusinessCode: boolean;
  paperWidth: string;
  isDefault: boolean;
  updatedAt: string;
}

export interface ModuleFlags {
  businessId: string;
  restaurantEnabled: boolean;
  retailEnabled: boolean;
  inventoryEnabled: boolean;
  servicesEnabled: boolean;
  customersEnabled: boolean;
  suppliersEnabled: boolean;
  expensesEnabled: boolean;
  reportingEnabled: boolean;
  dataCenterEnabled: boolean;
  updatedAt: string;
}

export interface SequenceCounter {
  id: string;
  businessId: string;
  scope: string;
  prefix: string;
  nextNumber: number;
  padding: number;
  resetPolicy: string;
  updatedAt: string;
}

export interface NewBusinessWorkspaceInput {
  name: string;
  legalName: string | null;
  code: string;
  businessType: string;
  currencyCode: string;
  taxMode: string;
  timezone: string;
  locale: string;
  activateNow: boolean;
}

export interface WorkspaceConfigurationInput {
  businessSettings: BusinessSettings;
  taxProfile: TaxProfile;
  receiptProfile: ReceiptProfile;
  moduleFlags: ModuleFlags;
  sequenceCounters: SequenceCounter[];
}

export interface AppInfo {
  appName: string;
  productName: string;
  version: string;
  schemaVersion: number;
  patchLevel: string;
  initializedAt: string;
}

export interface PatchRecord {
  patchId: string;
  patchName: string;
  appliedAt: string;
  schemaVersion: number;
}

export interface BackupRecord {
  id: string;
  businessId: string | null;
  fileName: string;
  filePath: string;
  checksum: string | null;
  status: string;
  createdAt: string;
}

export interface ExportJobRecord {
  id: string;
  businessId: string | null;
  format: string;
  status: string;
  targetPath: string | null;
  createdAt: string;
  completedAt: string | null;
}

export interface ImportPreview {
  filePath: string;
  valid: boolean;
  manifestVersion: string | null;
  bundleType: string | null;
  sourcePatchLevel: string | null;
  businessCount: number;
  categoryCount: number;
  itemCount: number;
  stockBalanceCount: number;
  movementCount: number;
  saleCount: number;
  heldSaleCount: number;
  generatedAt: string | null;
  warnings: string[];
}

export interface RecentActivity {
  id: string;
  level: string;
  category: string;
  message: string;
  createdAt: string;
}

export interface KpiCard {
  id: string;
  label: string;
  value: string;
  note: string;
}

export interface ModuleStatus {
  id: string;
  label: string;
  status: "active-foundation" | "planned" | "coming-next";
  note: string;
}

export interface DashboardShellData {
  heroTitle: string;
  heroBody: string;
  kpis: KpiCard[];
  recentActivity: RecentActivity[];
  moduleStatuses: ModuleStatus[];
}

export interface StorageStatus {
  dataDir: string;
  configDir: string;
  logDir: string;
  backupDir: string;
  exportDir: string;
  databasePath: string;
  databaseExists: boolean;
  backupCount: number;
  exportCount: number;
}

export interface BusinessWorkspaceSummary {
  businessId: string;
  name: string;
  code: string;
  businessType: string;
  currencyCode: string;
  theme: string;
  timezone: string;
  taxLabel: string;
  defaultTaxRate: number;
  nextSaleSequence: string;
  activeModules: string[];
  archivedAt: string | null;
  updatedAt: string;
}

export interface CatalogCategory {
  id: string;
  businessId: string;
  name: string;
  code: string;
  parentId: string | null;
  itemScope: string;
  sortOrder: number;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  archivedAt: string | null;
}

export interface CatalogUnit {
  id: string;
  businessId: string | null;
  name: string;
  code: string;
  symbol: string;
  allowFractional: boolean;
  isSystem: boolean;
  updatedAt: string;
  archivedAt: string | null;
}

export interface CatalogItem {
  id: string;
  businessId: string;
  categoryId: string | null;
  unitId: string | null;
  taxProfileId: string | null;
  itemKind: string;
  name: string;
  displayName: string | null;
  sku: string | null;
  primaryBarcode: string | null;
  description: string | null;
  sellingPrice: number;
  costPrice: number;
  trackStock: boolean;
  stockQuantity: number;
  reorderLevel: number;
  imagePath: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  archivedAt: string | null;
}

export interface CatalogBarcode {
  id: string;
  itemId: string;
  barcode: string;
  label: string | null;
  isPrimary: boolean;
  createdAt: string;
}

export interface CatalogItemView {
  item: CatalogItem;
  categoryName: string | null;
  unitCode: string | null;
  taxLabel: string | null;
  barcodes: CatalogBarcode[];
}

export interface CatalogSummary {
  totalItems: number;
  activeItems: number;
  archivedItems: number;
  categoryCount: number;
  menuItemCount: number;
  stockItemCount: number;
  serviceItemCount: number;
  lowStockCandidates: number;
}

export interface CatalogWorkspace {
  businessId: string;
  summary: CatalogSummary;
  categories: CatalogCategory[];
  units: CatalogUnit[];
  taxProfiles: TaxProfile[];
  items: CatalogItemView[];
}

export interface SaveCatalogCategoryInput {
  id?: string | null;
  name: string;
  code: string;
  parentId: string | null;
  itemScope: string;
  sortOrder: number;
  notes: string | null;
}

export interface SaveCatalogUnitInput {
  id?: string | null;
  name: string;
  code: string;
  symbol: string;
  allowFractional: boolean;
}

export interface SaveCatalogItemInput {
  id?: string | null;
  categoryId: string | null;
  unitId: string | null;
  taxProfileId: string | null;
  itemKind: string;
  name: string;
  displayName: string | null;
  sku: string | null;
  barcodes: string[];
  description: string | null;
  sellingPrice: number;
  costPrice: number;
  trackStock: boolean;
  stockQuantity: number;
  reorderLevel: number;
  imagePath: string | null;
  isActive: boolean;
}

export interface InventorySummary {
  totalTrackedItems: number;
  lowStockItems: number;
  movementCount: number;
  totalQuantityOnHand: number;
}

export interface InventoryStockItem {
  itemId: string;
  itemName: string;
  itemKind: string;
  sku: string | null;
  categoryName: string | null;
  unitCode: string | null;
  trackStock: boolean;
  stockQuantity: number;
  reorderLevel: number;
  lowStock: boolean;
  updatedAt: string;
}

export interface InventoryMovement {
  id: string;
  businessId: string;
  itemId: string;
  itemName: string;
  sku: string | null;
  unitCode: string | null;
  movementType: string;
  quantityDelta: number;
  quantityAfter: number;
  unitCost: number | null;
  note: string | null;
  occurredAt: string;
  createdAt: string;
}

export interface InventoryWorkspace {
  businessId: string;
  summary: InventorySummary;
  stockItems: InventoryStockItem[];
  recentMovements: InventoryMovement[];
}

export interface SaveInventoryMovementInput {
  itemId: string;
  movementType: string;
  quantity: number;
  unitCost: number | null;
  note: string | null;
}

export interface SaveInventoryStockRuleInput {
  itemId: string;
  trackStock: boolean;
  reorderLevel: number;
}

export interface PosSummary {
  completedSaleCount: number;
  todaySaleCount: number;
  heldSaleCount: number;
  todayGrossSales: number;
  todayCollectedAmount: number;
  todayDueAmount: number;
  averageSaleValue: number;
}

export interface PosSellableItem {
  itemId: string;
  name: string;
  displayName: string | null;
  itemKind: string;
  categoryName: string | null;
  unitCode: string | null;
  allowFractional: boolean;
  sku: string | null;
  primaryBarcode: string | null;
  sellingPrice: number;
  trackStock: boolean;
  onHandQuantity: number;
  taxLabel: string | null;
  taxRate: number;
  pricesIncludeTax: boolean;
  isAvailable: boolean;
}

export interface PosCartLineInput {
  itemId: string;
  quantity: number;
  unitPrice: number | null;
  discountAmount: number;
  notes: string | null;
}

export interface PosPaymentEntryInput {
  paymentMode: string;
  amount: number;
  referenceValue: string | null;
  notes: string | null;
}

export interface SavePosHoldInput {
  id?: string | null;
  holdLabel: string;
  notes: string | null;
  cartLines: PosCartLineInput[];
  cartDiscountAmount: number;
}

export interface CompletePosSaleInput {
  holdId: string | null;
  notes: string | null;
  cartLines: PosCartLineInput[];
  cartDiscountAmount: number;
  payments: PosPaymentEntryInput[];
}

export interface PosHoldSummary {
  id: string;
  businessId: string;
  holdCode: string;
  holdLabel: string;
  itemCount: number;
  subtotalAmount: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
  notes: string | null;
  cartLines: PosCartLineInput[];
  cartDiscountAmount: number;
  createdAt: string;
  updatedAt: string;
}

export interface PosSaleRecord {
  id: string;
  businessId: string;
  registerSessionId: string | null;
  saleNumber: string;
  saleStatus: string;
  paymentStatus: string;
  currencyCode: string;
  subtotalAmount: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
  amountPaid: number;
  balanceDue: number;
  itemCount: number;
  notes: string | null;
  completedAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface PosSaleLine {
  id: string;
  saleId: string;
  itemId: string | null;
  itemName: string;
  itemKind: string;
  categoryName: string | null;
  sku: string | null;
  primaryBarcode: string | null;
  unitCode: string | null;
  taxLabel: string | null;
  taxRate: number;
  pricesIncludeTax: boolean;
  quantity: number;
  unitPrice: number;
  grossAmount: number;
  discountAmount: number;
  netAmount: number;
  taxAmount: number;
  totalAmount: number;
  notes: string | null;
}

export interface PosSalePayment {
  id: string;
  saleId: string;
  paymentMode: string;
  amount: number;
  referenceValue: string | null;
  notes: string | null;
  createdAt: string;
}

export interface PosSaleDetail {
  sale: PosSaleRecord;
  lines: PosSaleLine[];
  payments: PosSalePayment[];
}

export interface PosWorkspace {
  businessId: string;
  summary: PosSummary;
  registerLabel: string | null;
  sellableItems: PosSellableItem[];
  heldSales: PosHoldSummary[];
  recentSales: PosSaleRecord[];
}

export interface AppBootstrap {
  appInfo: AppInfo;
  activeBusiness: BusinessProfile;
  businessSettings: BusinessSettings;
  activeTaxProfile: TaxProfile;
  activeReceiptProfile: ReceiptProfile;
  activeModuleFlags: ModuleFlags;
  activeSequences: SequenceCounter[];
  businesses: BusinessProfile[];
  businessWorkspaces: BusinessWorkspaceSummary[];
  patchHistory: PatchRecord[];
  backups: BackupRecord[];
  storage: StorageStatus;
  catalogSummary: CatalogSummary;
  inventorySummary: InventorySummary;
  posSummary: PosSummary;
  dashboard: DashboardShellData;
}

export type NavPage =
  | "dashboard"
  | "pos"
  | "catalog"
  | "inventory"
  | "business"
  | "settings"
  | "data-center";

```

## files/src/shared/utils.ts

```ts
export function formatDateTime(value: string | null | undefined): string {
  if (!value) return "—";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(parsed);
}

export function humanizeBoolean(value: boolean): string {
  return value ? "Enabled" : "Disabled";
}

export function classNames(...values: Array<string | false | null | undefined>): string {
  return values.filter(Boolean).join(" ");
}

export function titleCaseWords(value: string): string {
  return value
    .split(/[-_\s]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

export function humanizeMovementType(value: string): string {
  switch (value) {
    case "stock_in":
      return "Stock in";
    case "stock_out":
      return "Stock out";
    case "adjustment_in":
      return "Adjustment in";
    case "adjustment_out":
      return "Adjustment out";
    case "opening_balance":
      return "Opening balance";
    case "catalog_sync":
      return "Catalog sync";
    case "pos_sale":
      return "POS sale";
    default:
      return titleCaseWords(value);
  }
}

export function formatSequencePreview(
  prefix: string,
  nextNumber: number,
  padding: number
): string {
  const normalizedPadding = Math.max(1, Number.isFinite(padding) ? padding : 1);
  const normalizedNumber = Math.max(1, Number.isFinite(nextNumber) ? nextNumber : 1);
  return `${prefix}${String(normalizedNumber).padStart(normalizedPadding, "0")}`;
}

export function formatModuleList(modules: string[]): string {
  if (modules.length === 0) return "No modules enabled";
  return modules.map(titleCaseWords).join(", ");
}

export function formatCurrency(value: number, currencyCode = "INR"): string {
  return new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: currencyCode,
    maximumFractionDigits: 2
  }).format(Number.isFinite(value) ? value : 0);
}

export function formatQuantity(value: number, maximumFractionDigits = 3): string {
  const normalized = Number.isFinite(value) ? value : 0;
  return new Intl.NumberFormat(undefined, {
    minimumFractionDigits: Math.abs(normalized % 1) > 0.000001 ? 2 : 0,
    maximumFractionDigits
  }).format(normalized);
}

export function formatSignedQuantity(value: number, maximumFractionDigits = 3): string {
  const normalized = Number.isFinite(value) ? value : 0;
  const formatted = formatQuantity(Math.abs(normalized), maximumFractionDigits);
  if (normalized > 0) return `+${formatted}`;
  if (normalized < 0) return `-${formatted}`;
  return formatted;
}

export function linesFromMultilineValue(value: string): string[] {
  return value
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

export function multilineValueFromLines(values: string[]): string {
  return values.join("\n");
}

export function roundMoney(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function clampNumber(value: number, minimum = 0): number {
  if (!Number.isFinite(value)) return minimum;
  return value < minimum ? minimum : value;
}

export function formatPaymentMode(value: string): string {
  const normalized = value.trim().toLowerCase();
  if (normalized === "upi") return "UPI";
  if (normalized === "bank_transfer" || normalized === "bank") {
    return "Bank transfer";
  }
  return titleCaseWords(normalized || "other");
}

```

## files/src/styles.css

```css
:root {
  color-scheme: light;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont,
    "Segoe UI", sans-serif;
  background: #f4f6fb;
  color: #172033;
  line-height: 1.5;
  font-weight: 400;
}

* {
  box-sizing: border-box;
}

html,
body,
#root {
  margin: 0;
  min-height: 100%;
}

body {
  background:
    radial-gradient(circle at top right, #e8f0ff 0, transparent 26%),
    linear-gradient(180deg, #f7f9fd 0%, #eef3fb 100%);
}

button,
input,
select,
textarea {
  font: inherit;
}

button {
  cursor: pointer;
}

code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,
    "Liberation Mono", monospace;
  word-break: break-all;
}

.app-loading-shell {
  min-height: 100vh;
  display: grid;
  place-items: center;
  align-content: center;
  gap: 0.8rem;
  padding: 2rem;
  text-align: center;
}

.spinner {
  width: 3rem;
  height: 3rem;
  border-radius: 999px;
  border: 3px solid #d3def6;
  border-top-color: #305fdb;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.app-shell {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 310px minmax(0, 1fr);
}

.sidebar {
  padding: 1.5rem;
  background: #0f172a;
  color: #e5ecfa;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  border-right: 1px solid rgba(255, 255, 255, 0.08);
}

.sidebar-brand {
  display: flex;
  align-items: center;
  gap: 0.85rem;
}

.brand-badge {
  width: 2.55rem;
  height: 2.55rem;
  border-radius: 0.85rem;
  display: grid;
  place-items: center;
  background: linear-gradient(135deg, #60a5fa, #2563eb);
  font-weight: 700;
}

.sidebar-section-label {
  font-size: 0.78rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  opacity: 0.7;
  margin-top: 0.35rem;
}

.nav-list {
  display: grid;
  gap: 0.65rem;
}

.nav-item {
  background: rgba(255, 255, 255, 0.05);
  color: inherit;
  border: 1px solid transparent;
  border-radius: 0.95rem;
  padding: 0.9rem 1rem;
  text-align: left;
  display: grid;
  gap: 0.2rem;
  transition: 0.18s ease;
}

.nav-item:hover {
  border-color: rgba(255, 255, 255, 0.15);
  transform: translateY(-1px);
}

.nav-item-active {
  background: rgba(37, 99, 235, 0.24);
  border-color: rgba(96, 165, 250, 0.4);
}

.nav-title {
  font-weight: 700;
}

.nav-description {
  color: #9fb2d7;
  font-size: 0.88rem;
}

.sidebar-card {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 0.95rem;
  padding: 1rem;
  display: grid;
  gap: 0.7rem;
}

.sidebar-card-title {
  font-weight: 700;
}

.sidebar-pill {
  display: inline-flex;
  align-items: center;
  width: fit-content;
  padding: 0.35rem 0.6rem;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.08);
  font-size: 0.85rem;
}

.sidebar-field {
  display: grid;
  gap: 0.35rem;
  color: #d8e3fb;
  font-size: 0.88rem;
}

.sidebar-select {
  width: 100%;
  border-radius: 0.8rem;
  border: 1px solid rgba(255, 255, 255, 0.14);
  background: rgba(255, 255, 255, 0.08);
  color: #f5f9ff;
  padding: 0.7rem 0.8rem;
}

.sidebar-select option {
  color: #172033;
}

.sidebar-metadata-grid {
  display: grid;
  gap: 0.55rem;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.sidebar-metadata-grid span {
  display: block;
  color: #9fb2d7;
  font-size: 0.78rem;
  margin-bottom: 0.2rem;
}

.sidebar-metadata-grid strong {
  font-size: 0.9rem;
}

.small-text {
  font-size: 0.82rem;
}

.workspace {
  min-width: 0;
  padding: 1.5rem 2rem 2rem;
}

.workspace-header {
  display: flex;
  justify-content: space-between;
  gap: 1rem;
  align-items: flex-start;
  margin-bottom: 1.25rem;
}

.workspace-header h1 {
  margin: 0 0 0.25rem;
  font-size: 2rem;
}

.workspace-header p {
  margin: 0;
  color: #52607a;
}

.workspace-header-meta {
  display: flex;
  gap: 0.6rem;
  flex-wrap: wrap;
}

.meta-chip,
.pill {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.35rem 0.7rem;
  border-radius: 999px;
  font-size: 0.84rem;
  border: 1px solid transparent;
}

.meta-chip {
  background: #ffffff;
  color: #23304a;
  border-color: #d6e0f2;
}

.pill.success {
  background: #eaf8ef;
  color: #0f7a37;
  border-color: #bfe6c9;
}

.pill.warning {
  background: #fff6e5;
  color: #a75d00;
  border-color: #f4d39c;
}

.pill.neutral {
  background: #f0f4fb;
  color: #40506b;
  border-color: #d8e0f0;
}

.workspace-content {
  display: grid;
  gap: 1.25rem;
}

.page-grid {
  display: grid;
  gap: 1.25rem;
}

.hero-card,
.card {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(8px);
  border: 1px solid #dbe5f4;
  border-radius: 1.2rem;
  padding: 1.2rem 1.25rem;
  box-shadow: 0 14px 35px rgba(15, 23, 42, 0.05);
}

.hero-card {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 1rem;
}

.hero-card h2,
.card h2,
.card h3 {
  margin: 0;
}

.hero-card p,
.card-note {
  color: #5c6c89;
  margin-top: 0.5rem;
}

.hero-actions,
.inline-actions {
  display: flex;
  gap: 0.75rem;
  align-items: center;
  flex-wrap: wrap;
}

.align-start {
  align-items: flex-start;
}

.primary-button,
.secondary-button {
  border: none;
  border-radius: 0.9rem;
  padding: 0.75rem 1rem;
  font-weight: 700;
}

.primary-button {
  background: linear-gradient(135deg, #2563eb, #1d4ed8);
  color: white;
}

.primary-button:hover {
  filter: brightness(1.04);
}

.secondary-button {
  background: white;
  color: #24324a;
  border: 1px solid #d3def3;
}

.secondary-button:hover {
  background: #f5f8fd;
}

.secondary-button:disabled {
  opacity: 0.65;
  cursor: not-allowed;
}

.section-kicker {
  color: #3357aa;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  font-size: 0.78rem;
  font-weight: 700;
}

.card-grid {
  display: grid;
  gap: 1rem;
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.card-grid-5 {
  grid-template-columns: repeat(5, minmax(0, 1fr));
}

.card-label {
  color: #60708d;
  font-size: 0.92rem;
}

.kpi-value {
  font-size: 1.9rem;
  font-weight: 800;
  margin-top: 0.2rem;
}

.split-grid {
  display: grid;
  gap: 1rem;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.card-header {
  display: flex;
  justify-content: space-between;
  gap: 0.8rem;
  align-items: center;
  margin-bottom: 0.75rem;
}

.compact-card-header {
  margin-bottom: 0.5rem;
}

.stack-list {
  display: grid;
  gap: 0.75rem;
}

.list-row {
  display: flex;
  justify-content: space-between;
  gap: 0.75rem;
  align-items: flex-start;
  padding: 0.8rem 0;
  border-top: 1px solid #edf2fb;
}

.list-row:first-child {
  border-top: none;
  padding-top: 0;
}

.detail-list {
  display: grid;
  gap: 0.75rem;
}

.detail-list > div {
  display: grid;
  gap: 0.25rem;
}

.detail-list span {
  font-size: 0.88rem;
  color: #5f708c;
}

.compact-detail-list {
  gap: 0.6rem;
}

.two-column-detail-list {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.spaced-detail-list {
  margin-top: 1rem;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 0.9rem;
}

.compact-form-grid {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.form-grid label,
.form-span-2 {
  display: grid;
  gap: 0.35rem;
}

.form-span-2 {
  grid-column: 1 / -1;
}

input,
select,
textarea {
  width: 100%;
  border: 1px solid #ccd8ee;
  border-radius: 0.85rem;
  padding: 0.8rem 0.9rem;
  background: #fbfcff;
  color: #172033;
}

input:focus,
select:focus,
textarea:focus {
  outline: 3px solid rgba(37, 99, 235, 0.14);
  border-color: #78a6f8;
}

.toggle-stack,
.toggle-grid {
  display: grid;
  gap: 0.7rem;
}

.toggle-grid {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.toggle-row {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  padding: 0.7rem 0.1rem;
}

.toggle-row input[type="checkbox"] {
  width: auto;
}

.status-banner {
  padding: 0.8rem 0.95rem;
  background: #f3f7fd;
  border: 1px solid #dae4f5;
  border-radius: 0.95rem;
  color: #31405e;
}

.muted-text {
  color: #6a7a96;
  font-size: 0.92rem;
}

.directory-grid {
  display: grid;
  gap: 1rem;
}

.workspace-directory-card {
  border: 1px solid #d8e2f2;
  border-radius: 1rem;
  padding: 1rem;
  background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
  display: grid;
  gap: 0.9rem;
}

.workspace-directory-card.active {
  border-color: #8db4ff;
  box-shadow: inset 0 0 0 1px rgba(37, 99, 235, 0.1);
}

.tag-list {
  display: flex;
  flex-wrap: wrap;
  gap: 0.45rem;
}

.compact-tags {
  margin-top: 0.25rem;
}

.tag {
  display: inline-flex;
  align-items: center;
  padding: 0.28rem 0.58rem;
  border-radius: 999px;
  background: #edf3ff;
  border: 1px solid #d6e2ff;
  color: #34508c;
  font-size: 0.8rem;
}

.sequence-list {
  display: grid;
  gap: 0.95rem;
}

.sequence-row {
  border: 1px solid #deebf9;
  border-radius: 1rem;
  padding: 0.95rem;
  background: #fbfdff;
}

.sequence-row-header {
  display: flex;
  justify-content: space-between;
  gap: 0.8rem;
  align-items: flex-start;
  margin-bottom: 0.8rem;
}

.spacing-top {
  margin-top: 1.2rem;
}

@media (max-width: 1280px) {
  .card-grid-5 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }

  .compact-form-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 1120px) {
  .card-grid,
  .card-grid-5,
  .split-grid {
    grid-template-columns: 1fr 1fr;
  }
}

@media (max-width: 920px) {
  .app-shell {
    grid-template-columns: 1fr;
  }

  .sidebar {
    border-right: none;
    border-bottom: 1px solid rgba(15, 23, 42, 0.12);
  }

  .workspace {
    padding: 1.25rem;
  }

  .workspace-header,
  .hero-card,
  .split-grid,
  .card-grid,
  .card-grid-5,
  .form-grid,
  .compact-form-grid,
  .toggle-grid,
  .two-column-detail-list,
  .sidebar-metadata-grid {
    grid-template-columns: 1fr;
    display: grid;
  }

  .workspace-header {
    gap: 1rem;
  }

  .hero-card {
    align-items: stretch;
  }
}

.card-grid-4 {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.catalog-primary-grid,
.catalog-secondary-grid {
  grid-template-columns: 1.4fr 1fr;
}

.catalog-filter-bar {
  display: grid;
  grid-template-columns: minmax(0, 1.8fr) 180px auto;
  gap: 0.75rem;
  margin-bottom: 1rem;
  align-items: center;
}

.inline-toggle {
  min-height: 100%;
  padding: 0.7rem 0.85rem;
  border: 1px solid #d9e4f6;
  border-radius: 0.85rem;
  background: #fbfdff;
}

.catalog-list {
  display: grid;
  gap: 0.9rem;
}

.catalog-item-card {
  border: 1px solid #dbe5f5;
  border-radius: 1rem;
  padding: 1rem;
  background: linear-gradient(180deg, #ffffff 0%, #f9fbff 100%);
}

.catalog-item-description {
  margin: 0.65rem 0 0;
  color: #43516b;
  font-size: 0.94rem;
}

.compact-stack-list {
  gap: 0.55rem;
}

@media (max-width: 1280px) {
  .card-grid-4 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 1120px) {
  .catalog-primary-grid,
  .catalog-secondary-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 920px) {
  .catalog-filter-bar,
  .card-grid-4 {
    grid-template-columns: 1fr;
  }
}

.checkbox-field {
  display: flex;
  align-items: center;
  gap: 0.65rem;
}

.checkbox-field input[type="checkbox"] {
  width: auto;
}

.compact-checkbox {
  min-height: 100%;
  padding: 0.7rem 0.85rem;
  border: 1px solid #d9e4f6;
  border-radius: 0.85rem;
  background: #fbfdff;
}

.small-button {
  padding: 0.45rem 0.7rem;
  font-size: 0.86rem;
}

.inventory-main-grid,
.inventory-form-grid {
  grid-template-columns: 1.2fr 1fr;
}

.inventory-toolbar {
  display: grid;
  grid-template-columns: minmax(0, 1.8fr) auto;
  gap: 0.75rem;
  align-items: center;
  margin-bottom: 1rem;
}

.inventory-item-list,
.inventory-movement-list {
  gap: 0.9rem;
}

.inventory-item-row,
.inventory-movement-row {
  border-top: 1px solid #edf2fb;
}

.inventory-inline-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 0.45rem;
  margin-top: 0.4rem;
}

.inventory-qty-block {
  min-width: 132px;
  display: grid;
  justify-items: end;
  gap: 0.25rem;
  text-align: right;
}

.qty-positive {
  color: #0f7a37;
}

.qty-negative {
  color: #be2e2e;
}

@media (max-width: 1120px) {
  .inventory-main-grid,
  .inventory-form-grid {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 920px) {
  .inventory-toolbar {
    grid-template-columns: 1fr;
  }

  .inventory-qty-block {
    justify-items: start;
    text-align: left;
    min-width: 0;
  }
}

.summary-chip {
  display: grid;
  gap: 0.15rem;
  min-width: 140px;
  padding: 0.8rem 0.95rem;
  border: 1px solid #dce7f7;
  border-radius: 1rem;
  background: rgba(255, 255, 255, 0.82);
  box-shadow: 0 12px 24px rgba(22, 33, 59, 0.06);
}

.summary-chip strong {
  font-size: 1rem;
}

.summary-chip span {
  color: #5a6b88;
  font-size: 0.82rem;
}

.pos-layout {
  grid-template-columns: 1.2fr 1fr;
}

.pos-item-browser,
.pos-cart-card {
  min-height: 100%;
}

.pos-item-list {
  display: grid;
  gap: 0.8rem;
  margin-top: 1rem;
  max-height: 720px;
  overflow: auto;
  padding-right: 0.15rem;
}

.pos-item-card {
  width: 100%;
  display: flex;
  align-items: start;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.9rem 1rem;
  border: 1px solid #d9e4f6;
  border-radius: 0.95rem;
  background: linear-gradient(180deg, #ffffff 0%, #f7fbff 100%);
  cursor: pointer;
  text-align: left;
}

.pos-item-card:hover {
  border-color: #a7c4ff;
  transform: translateY(-1px);
}

.pos-item-meta {
  display: grid;
  justify-items: end;
  gap: 0.25rem;
  text-align: right;
}

.pos-item-meta span {
  font-weight: 700;
  color: #14213d;
}

.pos-item-meta small {
  color: #5d6f8d;
}

.pos-cart-line {
  display: grid;
  gap: 0.9rem;
  padding: 0.95rem 0;
  border-top: 1px solid #edf2fb;
}

.pos-cart-line:first-child {
  border-top: 0;
  padding-top: 0;
}

.pos-cart-line-main {
  display: grid;
  gap: 0.3rem;
}

.pos-cart-line-fields {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 0.8rem;
}

.pos-cart-line-fields label {
  display: grid;
  gap: 0.35rem;
}

.pos-cart-line-total {
  display: flex;
  flex-wrap: wrap;
  gap: 0.7rem;
  align-items: center;
  justify-content: space-between;
}

.pos-cart-form-grid {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.pos-payment-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.75rem;
}

.pos-payment-row {
  display: grid;
  grid-template-columns: 1.1fr 0.9fr 1.1fr auto;
  gap: 0.75rem;
  align-items: end;
}

.pos-summary-list {
  display: grid;
  gap: 0.5rem;
}

.pos-summary-list > div {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.55rem 0;
  border-top: 1px solid #edf2fb;
}

.pos-summary-list > div:first-child {
  border-top: 0;
}

.compact-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.55rem;
}

.align-right-text {
  text-align: right;
}

.align-start {
  align-items: start;
}

.receipt-preview-layout {
  grid-template-columns: 1fr 0.9fr;
}

.receipt-preview {
  padding: 1rem;
  border: 1px dashed #c8d5ea;
  border-radius: 1rem;
  background: #fbfdff;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

.receipt-preview-title {
  font-size: 1rem;
  font-weight: 700;
}

.receipt-preview-subtitle {
  margin-top: 0.35rem;
  color: #5d6f8d;
  font-size: 0.9rem;
}

.receipt-preview-divider {
  margin: 0.85rem 0;
  border-top: 1px dashed #bcc7d9;
}

.compact-stack {
  display: grid;
  gap: 0.5rem;
}

.compact-detail-list {
  display: grid;
  gap: 0.55rem;
}

.compact-detail-list > div {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}

@media (max-width: 1240px) {
  .pos-layout,
  .receipt-preview-layout {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 980px) {
  .pos-cart-line-fields,
  .pos-cart-form-grid,
  .pos-payment-row {
    grid-template-columns: 1fr;
  }

  .pos-item-card,
  .pos-cart-line-total,
  .pos-payment-header,
  .compact-detail-list > div,
  .pos-summary-list > div {
    align-items: start;
    justify-content: start;
  }

  .pos-item-meta,
  .align-right-text {
    justify-items: start;
    text-align: left;
  }
}

```

## files/src-tauri/Cargo.toml

```
[package]
name = "local-business-manager"
version = "0.5.0"
description = "Local-first business management desktop app POS checkout core"
authors = ["OpenAI"]
edition = "2021"

[lib]
name = "local_business_manager"
crate-type = ["staticlib", "cdylib", "rlib"]

[build-dependencies]
tauri-build = { version = "2.0.0", features = [] }

[dependencies]
chrono = { version = "0.4.38", features = ["serde"] }
rusqlite = { version = "0.32.1", features = ["bundled"] }
serde = { version = "1.0.215", features = ["derive"] }
serde_json = "1.0.133"
sha2 = "0.10.8"
tauri = { version = "2.0.0", features = [] }
uuid = { version = "1.11.0", features = ["v4", "serde"] }

```

## files/src-tauri/src/commands/bootstrap.rs

```rust
use tauri::AppHandle;

use crate::{
    core::{catalog, db, error::CommandResult, inventory, pos},
    domain::bootstrap::build_app_bootstrap,
};

#[tauri::command]
pub fn bootstrap_app(app: AppHandle) -> CommandResult<crate::domain::models::AppBootstrap> {
    db::with_connection(&app, |conn, paths| {
        let app_info = db::load_app_info(conn)?;
        let active_business = db::get_active_business(conn)?;
        let business_settings = db::get_business_settings(conn, &active_business.id)?;
        let active_tax_profile = db::get_default_tax_profile(conn, &active_business.id)?;
        let active_receipt_profile = db::get_default_receipt_profile(conn, &active_business.id)?;
        let active_module_flags = db::get_module_flags(conn, &active_business.id)?;
        let active_sequences = db::list_sequence_counters(conn, &active_business.id)?;
        let businesses = db::list_businesses(conn)?;
        let business_workspaces = db::list_business_workspace_summaries(conn)?;
        let patch_history = db::list_patch_history(conn)?;
        let backups = db::list_backups(conn)?;
        let storage = db::build_storage_status(conn, paths)?;
        let recent_activity = db::list_recent_activity(conn, 10)?;
        let catalog_summary = catalog::build_catalog_summary(conn, &active_business.id)?;
        let inventory_summary = inventory::build_inventory_summary(conn, &active_business.id)?;
        let pos_summary = pos::build_pos_summary(conn, &active_business.id)?;

        Ok(build_app_bootstrap(
            app_info,
            active_business,
            business_settings,
            active_tax_profile,
            active_receipt_profile,
            active_module_flags,
            active_sequences,
            businesses,
            business_workspaces,
            patch_history,
            backups,
            storage,
            recent_activity,
            catalog_summary,
            inventory_summary,
            pos_summary,
        ))
    })
}

```

## files/src-tauri/src/commands/data_center.rs

```rust
use std::{fs, path::PathBuf};

use chrono::Utc;
use rusqlite::params;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use tauri::AppHandle;
use uuid::Uuid;

use crate::{
    core::{
        catalog, db,
        error::{to_command_error, CommandResult},
        inventory,
        paths::resolve_paths,
        pos,
    },
    domain::models::{BackupRecord, ExportJobRecord, ImportPreview},
};

fn checksum_for_file(path: &PathBuf) -> Result<String, String> {
    let bytes = fs::read(path)
        .map_err(|error| to_command_error("failed to read file for checksum", error))?;
    let digest = Sha256::digest(&bytes);
    Ok(format!("{digest:x}"))
}

fn list_inventory_balance_snapshots(conn: &rusqlite::Connection) -> Result<Vec<Value>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT business_id, id, stock_quantity, reorder_level, updated_at
             FROM catalog_items
             WHERE archived_at IS NULL
               AND item_kind = 'stock'
               AND track_stock = 1
             ORDER BY updated_at DESC, id ASC",
        )
        .map_err(|error| to_command_error("failed to prepare stock balance snapshot query", error))?;

    let rows = stmt
        .query_map([], |row| {
            Ok(json!({
                "businessId": row.get::<_, String>(0)?,
                "itemId": row.get::<_, String>(1)?,
                "onHandQuantity": row.get::<_, f64>(2)?,
                "reorderLevel": row.get::<_, f64>(3)?,
                "updatedAt": row.get::<_, String>(4)?,
            }))
        })
        .map_err(|error| to_command_error("failed to query stock balance snapshots", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map stock balance snapshots", error))
}

#[tauri::command]
pub fn create_backup_snapshot(app: AppHandle) -> CommandResult<BackupRecord> {
    let paths = resolve_paths(&app)?;
    let (active_business, business_settings) = db::with_connection(&app, |conn, _paths| {
        let active_business = db::get_active_business(conn)?;
        let business_settings = db::get_business_settings(conn, &active_business.id)?;
        Ok((active_business, business_settings))
    })?;

    let timestamp = Utc::now().format("%Y%m%d_%H%M%S").to_string();
    let file_name = format!("workspace_snapshot_{timestamp}.sqlite");
    let backup_dir = business_settings
        .backup_directory
        .clone()
        .filter(|value| !value.trim().is_empty())
        .unwrap_or(paths.backup_dir.clone());
    fs::create_dir_all(&backup_dir)
        .map_err(|error| to_command_error("failed to prepare backup directory", error))?;
    let destination = PathBuf::from(backup_dir).join(&file_name);

    fs::copy(paths.database_path_buf(), &destination)
        .map_err(|error| to_command_error("failed to create backup snapshot", error))?;

    let checksum = checksum_for_file(&destination)?;
    let record = BackupRecord {
        id: Uuid::new_v4().to_string(),
        business_id: Some(active_business.id.clone()),
        file_name,
        file_path: destination.to_string_lossy().to_string(),
        checksum: Some(checksum),
        status: "completed".into(),
        created_at: db::now_iso(),
    };

    db::with_connection(&app, |conn, _paths| {
        db::insert_backup_record(conn, &record)?;
        db::insert_log(
            conn,
            "INFO",
            "backup",
            "Local backup snapshot created",
            None,
        )?;
        Ok(record.clone())
    })
}

#[tauri::command]
pub fn export_foundation_snapshot(app: AppHandle) -> CommandResult<String> {
    let paths = resolve_paths(&app)?;

    let (
        app_info,
        active_business,
        businesses,
        business_settings,
        tax_profiles,
        receipt_profiles,
        module_flags,
        sequence_counters,
        patch_history,
        backups,
        catalog_categories,
        catalog_units,
        catalog_items,
        catalog_barcodes,
        inventory_movements,
        inventory_balances,
        register_sessions,
        sales,
        sale_lines,
        sale_payments,
        sale_holds,
    ) = db::with_connection(&app, |conn, _paths| {
        let active_business = db::get_active_business(conn)?;

        Ok((
            db::load_app_info(conn)?,
            active_business,
            db::list_businesses(conn)?,
            db::list_all_business_settings(conn)?,
            db::list_all_tax_profiles(conn)?,
            db::list_all_receipt_profiles(conn)?,
            db::list_all_module_flags(conn)?,
            db::list_all_sequence_counters(conn)?,
            db::list_patch_history(conn)?,
            db::list_backups(conn)?,
            catalog::list_all_catalog_categories(conn)?,
            catalog::list_all_catalog_units(conn)?,
            catalog::list_all_catalog_items(conn)?,
            catalog::list_all_catalog_barcodes(conn)?,
            inventory::list_all_inventory_movements(conn)?,
            list_inventory_balance_snapshots(conn)?,
            pos::list_all_register_sessions(conn)?,
            pos::list_all_sales(conn)?,
            pos::list_all_sale_lines(conn)?,
            pos::list_all_sale_payments(conn)?,
            pos::list_all_sale_holds(conn)?,
        ))
    })?;

    let generated_at = db::now_iso();
    let timestamp = Utc::now().format("%Y%m%d_%H%M%S").to_string();
    let export_path =
        PathBuf::from(&paths.export_dir).join(format!("workspace_export_{timestamp}.json"));

    let source_patch_level = app_info.patch_level.clone();
    let product_name = app_info.product_name.clone();
    let active_business_id = active_business.id.clone();

    let bundle = json!({
        "manifest": {
            "bundleVersion": "5.0.0",
            "bundleType": "workspace-foundation-export",
            "sourcePatchLevel": source_patch_level,
            "schemaVersion": app_info.schema_version,
            "generatedAt": generated_at.clone(),
            "productName": product_name
        },
        "appInfo": app_info,
        "activeBusinessId": active_business_id.clone(),
        "businesses": businesses,
        "businessSettings": business_settings,
        "taxProfiles": tax_profiles,
        "receiptProfiles": receipt_profiles,
        "moduleFlags": module_flags,
        "sequenceCounters": sequence_counters,
        "patchHistory": patch_history,
        "backupRecords": backups,
        "catalogCategories": catalog_categories,
        "catalogUnits": catalog_units,
        "catalogItems": catalog_items,
        "catalogBarcodes": catalog_barcodes,
        "inventoryStockBalances": inventory_balances,
        "inventoryMovements": inventory_movements,
        "registerSessions": register_sessions,
        "sales": sales,
        "saleLines": sale_lines,
        "salePayments": sale_payments,
        "saleHolds": sale_holds
    });

    fs::write(
        &export_path,
        serde_json::to_string_pretty(&bundle)
            .map_err(|error| to_command_error("failed to serialize export bundle", error))?,
    )
    .map_err(|error| to_command_error("failed to write export bundle", error))?;

    let export_job = ExportJobRecord {
        id: Uuid::new_v4().to_string(),
        business_id: Some(active_business_id),
        format: "json-workspace-foundation-v5".into(),
        status: "completed".into(),
        target_path: Some(export_path.to_string_lossy().to_string()),
        created_at: generated_at.clone(),
        completed_at: Some(generated_at),
    };

    db::with_connection(&app, |conn, _paths| {
        db::insert_export_job(conn, &export_job)?;
        db::insert_log(
            conn,
            "INFO",
            "export",
            "Workspace export bundle created",
            None,
        )?;
        Ok(())
    })?;

    Ok(export_path.to_string_lossy().to_string())
}

#[tauri::command]
pub fn preview_import_bundle(app: AppHandle, file_path: String) -> CommandResult<ImportPreview> {
    let raw = fs::read_to_string(&file_path)
        .map_err(|error| to_command_error("failed to read import bundle", error))?;

    let parsed: Value = serde_json::from_str(&raw)
        .map_err(|error| to_command_error("invalid JSON bundle", error))?;

    let manifest = parsed.get("manifest").cloned().unwrap_or_else(|| json!({}));

    let businesses = parsed
        .get("businesses")
        .and_then(|value| value.as_array())
        .cloned()
        .unwrap_or_default();

    let categories = parsed
        .get("catalogCategories")
        .and_then(|value| value.as_array())
        .cloned()
        .unwrap_or_default();

    let items = parsed
        .get("catalogItems")
        .and_then(|value| value.as_array())
        .cloned()
        .unwrap_or_default();

    let balances = parsed
        .get("inventoryStockBalances")
        .and_then(|value| value.as_array())
        .cloned()
        .unwrap_or_default();

    let movements = parsed
        .get("inventoryMovements")
        .and_then(|value| value.as_array())
        .cloned()
        .unwrap_or_default();

    let sales = parsed
        .get("sales")
        .and_then(|value| value.as_array())
        .cloned()
        .unwrap_or_default();

    let holds = parsed
        .get("saleHolds")
        .and_then(|value| value.as_array())
        .cloned()
        .unwrap_or_default();

    let mut warnings = Vec::new();

    if manifest.get("bundleType").is_none() {
        warnings.push("Bundle is missing manifest.bundleType".into());
    }

    if manifest.get("bundleVersion").is_none() {
        warnings.push("Bundle is missing manifest.bundleVersion".into());
    }

    if parsed.get("businessSettings").is_none() {
        warnings.push("Bundle is missing businessSettings".into());
    }

    if parsed.get("inventoryMovements").is_none() {
        warnings.push("Bundle does not include inventoryMovements".into());
    }

    if parsed.get("sales").is_none() {
        warnings.push("Bundle does not include sales".into());
    }

    let preview = ImportPreview {
        file_path: file_path.clone(),
        valid: warnings.is_empty(),
        manifest_version: manifest
            .get("bundleVersion")
            .and_then(|value| value.as_str())
            .map(ToString::to_string),
        bundle_type: manifest
            .get("bundleType")
            .and_then(|value| value.as_str())
            .map(ToString::to_string),
        source_patch_level: manifest
            .get("sourcePatchLevel")
            .and_then(|value| value.as_str())
            .map(ToString::to_string),
        business_count: businesses.len(),
        category_count: categories.len(),
        item_count: items.len(),
        stock_balance_count: balances.len(),
        movement_count: movements.len(),
        sale_count: sales.len(),
        held_sale_count: holds.len(),
        generated_at: manifest
            .get("generatedAt")
            .and_then(|value| value.as_str())
            .map(ToString::to_string),
        warnings,
    };

    db::with_connection(&app, |conn, _paths| {
        db::insert_import_job(
            conn,
            None,
            "json-workspace-foundation-v5",
            "previewed",
            &file_path,
        )?;
        db::insert_log(conn, "INFO", "import", "Import bundle previewed", None)?;
        Ok(())
    })?;

    Ok(preview)
}

```

## files/src-tauri/src/commands/mod.rs

```rust
pub mod bootstrap;
pub mod business;
pub mod catalog;
pub mod data_center;
pub mod inventory;
pub mod pos;
pub mod settings;

```

## files/src-tauri/src/commands/pos.rs

```rust
use tauri::AppHandle;

use crate::{
    core::{db, error::CommandResult, pos},
    domain::models::{CompletePosSaleInput, PosHoldSummary, PosSaleDetail, PosWorkspace, SavePosHoldInput},
};

#[tauri::command]
pub fn load_pos_workspace(app: AppHandle) -> CommandResult<PosWorkspace> {
    db::with_connection(&app, |conn, _paths| {
        let active_business = db::get_active_business(conn)?;
        pos::load_pos_workspace(conn, &active_business.id)
    })
}

#[tauri::command]
pub fn save_pos_hold(app: AppHandle, input: SavePosHoldInput) -> CommandResult<PosHoldSummary> {
    db::with_connection(&app, |conn, _paths| {
        let active_business = db::get_active_business(conn)?;
        pos::save_pos_hold(conn, &active_business.id, &input)
    })
}

#[tauri::command]
pub fn delete_pos_hold(app: AppHandle, hold_id: String) -> CommandResult<()> {
    db::with_connection(&app, |conn, _paths| {
        let active_business = db::get_active_business(conn)?;
        pos::delete_pos_hold(conn, &active_business.id, &hold_id)
    })
}

#[tauri::command]
pub fn complete_pos_sale(
    app: AppHandle,
    input: CompletePosSaleInput,
) -> CommandResult<PosSaleDetail> {
    db::with_connection(&app, |conn, _paths| {
        let active_business = db::get_active_business(conn)?;
        pos::complete_pos_sale(conn, &active_business, &input)
    })
}

```

## files/src-tauri/src/core/db.rs

```rust
use std::fs;

use chrono::Utc;
use rusqlite::{params, Connection, OptionalExtension, Row};
use tauri::AppHandle;
use uuid::Uuid;

use crate::domain::models::{
    AppInfo, BackupRecord, BusinessProfile, BusinessSettings, BusinessWorkspaceSummary,
    ExportJobRecord, ModuleFlags, NewBusinessWorkspaceInput, PatchRecord, ReceiptProfile,
    RecentActivity, SequenceCounter, StorageStatus, TaxProfile, WorkspaceConfigurationInput,
};

use super::{
    error::to_command_error,
    inventory,
    migrations::{self, CURRENT_SCHEMA_VERSION},
    patching,
    paths::{ensure_directories, resolve_paths, AppPaths},
    pos,
    seed,
};

pub fn initialize(app: &AppHandle) -> Result<(), String> {
    let paths = resolve_paths(app)?;
    ensure_directories(&paths)?;
    let conn = open_connection(&paths)
        .map_err(|error| to_command_error("failed to open local database", error))?;
    migrations::run(&conn).map_err(|error| to_command_error("failed to run migrations", error))?;
    patching::register_patch(&conn)
        .map_err(|error| to_command_error("failed to register patch history", error))?;
    seed::seed_if_empty(&conn)
        .map_err(|error| to_command_error("failed to seed local data", error))?;
    inventory::backfill_opening_balances(&conn)
        .map_err(|error| to_command_error("failed to backfill opening stock balances", error))?;
    Ok(())
}

pub fn with_connection<T, F>(app: &AppHandle, action: F) -> Result<T, String>
where
    F: FnOnce(&Connection, &AppPaths) -> Result<T, String>,
{
    let paths = resolve_paths(app)?;
    ensure_directories(&paths)?;
    let conn = open_connection(&paths)
        .map_err(|error| to_command_error("failed to open local database", error))?;
    action(&conn, &paths)
}

pub fn open_connection(paths: &AppPaths) -> rusqlite::Result<Connection> {
    let conn = Connection::open(&paths.database_path)?;
    conn.pragma_update(None, "foreign_keys", "ON")?;
    conn.pragma_update(None, "journal_mode", "DELETE")?;
    conn.pragma_update(None, "synchronous", "NORMAL")?;
    Ok(conn)
}

pub fn now_iso() -> String {
    Utc::now().to_rfc3339()
}

fn bool_from_row(row: &Row, index: usize) -> rusqlite::Result<bool> {
    let value: i64 = row.get(index)?;
    Ok(value != 0)
}

fn bool_to_i64(value: bool) -> i64 {
    if value {
        1
    } else {
        0
    }
}

fn normalize_optional(value: &Option<String>) -> Option<String> {
    value.as_ref().and_then(|raw| {
        let trimmed = raw.trim();
        if trimmed.is_empty() {
            None
        } else {
            Some(trimmed.to_string())
        }
    })
}

fn normalize_text(value: &str, field: &str) -> Result<String, String> {
    let trimmed = value.trim();
    if trimmed.is_empty() {
        return Err(format!("{field} cannot be empty"));
    }
    Ok(trimmed.to_string())
}

fn normalize_code(value: &str, field: &str) -> Result<String, String> {
    let normalized = normalize_text(value, field)?;
    Ok(normalized.to_uppercase())
}

fn business_from_row(row: &Row) -> rusqlite::Result<BusinessProfile> {
    Ok(BusinessProfile {
        id: row.get(0)?,
        name: row.get(1)?,
        legal_name: row.get(2)?,
        code: row.get(3)?,
        business_type: row.get(4)?,
        currency_code: row.get(5)?,
        tax_mode: row.get(6)?,
        phone: row.get(7)?,
        email: row.get(8)?,
        address_line1: row.get(9)?,
        address_line2: row.get(10)?,
        city: row.get(11)?,
        state: row.get(12)?,
        postal_code: row.get(13)?,
        country: row.get(14)?,
        created_at: row.get(15)?,
        updated_at: row.get(16)?,
        archived_at: row.get(17)?,
    })
}

fn settings_from_row(row: &Row) -> rusqlite::Result<BusinessSettings> {
    Ok(BusinessSettings {
        business_id: row.get(0)?,
        timezone: row.get(1)?,
        locale: row.get(2)?,
        date_format: row.get(3)?,
        theme: row.get(4)?,
        tax_label: row.get(5)?,
        default_tax_rate: row.get(6)?,
        prices_include_tax: bool_from_row(row, 7)?,
        receipt_footer: row.get(8)?,
        receipt_show_address: bool_from_row(row, 9)?,
        receipt_show_phone: bool_from_row(row, 10)?,
        auto_backup_enabled: bool_from_row(row, 11)?,
        backup_directory: row.get(12)?,
        module_restaurant_enabled: bool_from_row(row, 13)?,
        module_retail_enabled: bool_from_row(row, 14)?,
        module_inventory_enabled: bool_from_row(row, 15)?,
        module_services_enabled: bool_from_row(row, 16)?,
        updated_at: row.get(17)?,
    })
}

fn tax_profile_from_row(row: &Row) -> rusqlite::Result<TaxProfile> {
    Ok(TaxProfile {
        id: row.get(0)?,
        business_id: row.get(1)?,
        name: row.get(2)?,
        tax_label: row.get(3)?,
        default_rate: row.get(4)?,
        prices_include_tax: bool_from_row(row, 5)?,
        is_default: bool_from_row(row, 6)?,
        updated_at: row.get(7)?,
    })
}

fn receipt_profile_from_row(row: &Row) -> rusqlite::Result<ReceiptProfile> {
    Ok(ReceiptProfile {
        id: row.get(0)?,
        business_id: row.get(1)?,
        name: row.get(2)?,
        footer_text: row.get(3)?,
        show_address: bool_from_row(row, 4)?,
        show_phone: bool_from_row(row, 5)?,
        show_email: bool_from_row(row, 6)?,
        show_business_code: bool_from_row(row, 7)?,
        paper_width: row.get(8)?,
        is_default: bool_from_row(row, 9)?,
        updated_at: row.get(10)?,
    })
}

fn backup_from_row(row: &Row) -> rusqlite::Result<BackupRecord> {
    Ok(BackupRecord {
        id: row.get(0)?,
        business_id: row.get(1)?,
        file_name: row.get(2)?,
        file_path: row.get(3)?,
        checksum: row.get(4)?,
        status: row.get(5)?,
        created_at: row.get(6)?,
    })
}

fn patch_from_row(row: &Row) -> rusqlite::Result<PatchRecord> {
    Ok(PatchRecord {
        patch_id: row.get(0)?,
        patch_name: row.get(1)?,
        schema_version: row.get(2)?,
        applied_at: row.get(3)?,
    })
}

fn activity_from_row(row: &Row) -> rusqlite::Result<RecentActivity> {
    Ok(RecentActivity {
        id: row.get(0)?,
        level: row.get(1)?,
        category: row.get(2)?,
        message: row.get(3)?,
        created_at: row.get(4)?,
    })
}

fn sequence_from_row(row: &Row) -> rusqlite::Result<SequenceCounter> {
    let business_id: String = row.get(0)?;
    let scope: String = row.get(1)?;
    Ok(SequenceCounter {
        id: format!("{business_id}:{scope}"),
        business_id,
        scope,
        prefix: row.get(2)?,
        next_number: row.get(3)?,
        padding: row.get(4)?,
        reset_policy: row.get(5)?,
        updated_at: row.get(6)?,
    })
}

pub fn get_meta(conn: &Connection, key: &str) -> Result<Option<String>, String> {
    conn.query_row(
        "SELECT value FROM app_meta WHERE key = ?1 LIMIT 1",
        params![key],
        |row| row.get::<_, String>(0),
    )
    .optional()
    .map_err(|error| to_command_error("failed to read app meta", error))
}

pub fn set_meta(conn: &Connection, key: &str, value: &str) -> Result<(), String> {
    conn.execute(
        "INSERT INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        params![key, value, now_iso()],
    )
    .map_err(|error| to_command_error("failed to write app meta", error))?;
    Ok(())
}

pub fn insert_log(
    conn: &Connection,
    level: &str,
    category: &str,
    message: &str,
    payload_json: Option<&str>,
) -> Result<(), String> {
    conn.execute(
        "INSERT INTO app_logs (id, level, category, message, payload_json, created_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
        params![
            Uuid::new_v4().to_string(),
            level,
            category,
            message,
            payload_json,
            now_iso()
        ],
    )
    .map_err(|error| to_command_error("failed to insert app log", error))?;
    Ok(())
}

pub fn load_app_info(conn: &Connection) -> Result<AppInfo, String> {
    let app_name =
        get_meta(conn, "app_name")?.unwrap_or_else(|| "local-first-business-manager".into());
    let product_name =
        get_meta(conn, "product_name")?.unwrap_or_else(|| "Local Business Manager".into());
    let version = get_meta(conn, "app_version")?.unwrap_or_else(|| "0.5.0".into());
    let initialized_at = get_meta(conn, "initialized_at")?.unwrap_or_else(now_iso);
    let patch_level =
        get_meta(conn, "patch_level")?.unwrap_or_else(|| patching::PATCH_ID.to_string());
    let schema_version = get_meta(conn, "schema_version")?
        .and_then(|value| value.parse::<i64>().ok())
        .unwrap_or(CURRENT_SCHEMA_VERSION);

    Ok(AppInfo {
        app_name,
        product_name,
        version,
        schema_version,
        patch_level,
        initialized_at,
    })
}

pub fn list_patch_history(conn: &Connection) -> Result<Vec<PatchRecord>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT patch_id, patch_name, schema_version, applied_at
             FROM patch_history
             ORDER BY schema_version ASC, applied_at ASC",
        )
        .map_err(|error| to_command_error("failed to prepare patch history query", error))?;

    let rows = stmt
        .query_map([], patch_from_row)
        .map_err(|error| to_command_error("failed to query patch history", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map patch history", error))
}

pub fn list_recent_activity(
    conn: &Connection,
    limit: usize,
) -> Result<Vec<RecentActivity>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, level, category, message, created_at
             FROM app_logs
             ORDER BY created_at DESC
             LIMIT ?1",
        )
        .map_err(|error| to_command_error("failed to prepare activity query", error))?;

    let rows = stmt
        .query_map(params![limit as i64], activity_from_row)
        .map_err(|error| to_command_error("failed to query recent activity", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map recent activity", error))
}

pub fn get_business_by_id(conn: &Connection, business_id: &str) -> Result<BusinessProfile, String> {
    conn.query_row(
        "SELECT
            id, name, legal_name, code, business_type, currency_code, tax_mode,
            phone, email, address_line1, address_line2, city, state, postal_code,
            country, created_at, updated_at, archived_at
         FROM businesses
         WHERE id = ?1
         LIMIT 1",
        params![business_id],
        business_from_row,
    )
    .map_err(|error| to_command_error("failed to load business profile", error))
}

pub fn list_businesses(conn: &Connection) -> Result<Vec<BusinessProfile>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT
                id, name, legal_name, code, business_type, currency_code, tax_mode,
                phone, email, address_line1, address_line2, city, state, postal_code,
                country, created_at, updated_at, archived_at
             FROM businesses
             ORDER BY CASE WHEN archived_at IS NULL THEN 0 ELSE 1 END, updated_at DESC",
        )
        .map_err(|error| to_command_error("failed to prepare business list query", error))?;

    let rows = stmt
        .query_map([], business_from_row)
        .map_err(|error| to_command_error("failed to query businesses", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map businesses", error))
}

pub fn get_active_business(conn: &Connection) -> Result<BusinessProfile, String> {
    if let Some(active_business_id) = get_meta(conn, "active_business_id")? {
        if let Ok(business) = get_business_by_id(conn, &active_business_id) {
            if business.archived_at.is_none() {
                return Ok(business);
            }
        }
    }

    let businesses = list_businesses(conn)?;
    if let Some(business) = businesses
        .iter()
        .find(|item| item.archived_at.is_none())
        .cloned()
        .or_else(|| businesses.first().cloned())
    {
        set_meta(conn, "active_business_id", &business.id)?;
        return Ok(business);
    }

    Err("no business profile is available".into())
}

fn default_module_booleans(business_type: &str) -> (bool, bool, bool, bool) {
    let normalized = business_type.to_lowercase();
    let restaurant = normalized.contains("restaurant")
        || normalized.contains("cafe")
        || normalized.contains("bakery")
        || normalized.contains("food");
    let services = normalized.contains("service");
    let retail = !services;
    (restaurant, retail, true, services)
}

pub fn create_business_workspace(
    conn: &Connection,
    input: &NewBusinessWorkspaceInput,
) -> Result<BusinessProfile, String> {
    let business_id = Uuid::new_v4().to_string();
    let now = now_iso();
    let name = normalize_text(&input.name, "business name")?;
    let code = normalize_code(&input.code, "business code")?;
    let business_type = normalize_text(&input.business_type, "business type")?;
    let currency_code = normalize_code(&input.currency_code, "currency code")?;
    let tax_mode = normalize_text(&input.tax_mode, "tax mode")?;
    let timezone = normalize_text(&input.timezone, "timezone")?;
    let locale = normalize_text(&input.locale, "locale")?;
    let (restaurant_enabled, retail_enabled, inventory_enabled, services_enabled) =
        default_module_booleans(&business_type);

    conn.execute(
        "INSERT INTO businesses (
            id, name, legal_name, code, business_type, currency_code, tax_mode,
            phone, email, address_line1, address_line2, city, state, postal_code,
            country, created_at, updated_at, archived_at
         ) VALUES (
            ?1, ?2, ?3, ?4, ?5, ?6, ?7,
            ?8, ?9, ?10, ?11, ?12, ?13, ?14,
            ?15, ?16, ?17, ?18
         )",
        params![
            &business_id,
            &name,
            normalize_optional(&input.legal_name),
            &code,
            &business_type,
            &currency_code,
            &tax_mode,
            Option::<String>::None,
            Option::<String>::None,
            Option::<String>::None,
            Option::<String>::None,
            Option::<String>::None,
            Option::<String>::None,
            Option::<String>::None,
            Option::<String>::None,
            &now,
            &now,
            Option::<String>::None
        ],
    )
    .map_err(|error| to_command_error("failed to create business profile", error))?;

    let settings = BusinessSettings {
        business_id: business_id.clone(),
        timezone,
        locale,
        date_format: "DD-MM-YYYY".into(),
        theme: "system".into(),
        tax_label: "GST".into(),
        default_tax_rate: 0.0,
        prices_include_tax: false,
        receipt_footer: Some("Thank you for supporting local business.".into()),
        receipt_show_address: true,
        receipt_show_phone: true,
        auto_backup_enabled: false,
        backup_directory: None,
        module_restaurant_enabled: restaurant_enabled,
        module_retail_enabled: retail_enabled,
        module_inventory_enabled: inventory_enabled,
        module_services_enabled: services_enabled,
        updated_at: now.clone(),
    };
    save_business_settings(conn, &settings)?;
    seed::ensure_workspace_support_for_business(conn, &business_id)
        .map_err(|error| to_command_error("failed to seed workspace support", error))?;
    pos::ensure_pos_support_for_business(conn, &business_id)?;

    if input.activate_now {
        set_meta(conn, "active_business_id", &business_id)?;
    }

    insert_log(
        conn,
        "INFO",
        "workspace",
        "Business workspace created",
        None,
    )?;
    get_business_by_id(conn, &business_id)
}

pub fn switch_active_business(
    conn: &Connection,
    business_id: &str,
) -> Result<BusinessProfile, String> {
    let business = get_business_by_id(conn, business_id)?;
    if business.archived_at.is_some() {
        return Err("cannot switch to an archived business".into());
    }
    set_meta(conn, "active_business_id", business_id)?;
    insert_log(conn, "INFO", "workspace", "Active business switched", None)?;
    Ok(business)
}

pub fn save_business_profile(
    conn: &Connection,
    profile: &BusinessProfile,
) -> Result<BusinessProfile, String> {
    let now = now_iso();
    let rows = conn
        .execute(
            "UPDATE businesses
             SET name = ?2,
                 legal_name = ?3,
                 code = ?4,
                 business_type = ?5,
                 currency_code = ?6,
                 tax_mode = ?7,
                 phone = ?8,
                 email = ?9,
                 address_line1 = ?10,
                 address_line2 = ?11,
                 city = ?12,
                 state = ?13,
                 postal_code = ?14,
                 country = ?15,
                 updated_at = ?16
             WHERE id = ?1",
            params![
                &profile.id,
                normalize_text(&profile.name, "business name")?,
                normalize_optional(&profile.legal_name),
                normalize_code(&profile.code, "business code")?,
                normalize_text(&profile.business_type, "business type")?,
                normalize_code(&profile.currency_code, "currency code")?,
                normalize_text(&profile.tax_mode, "tax mode")?,
                normalize_optional(&profile.phone),
                normalize_optional(&profile.email),
                normalize_optional(&profile.address_line1),
                normalize_optional(&profile.address_line2),
                normalize_optional(&profile.city),
                normalize_optional(&profile.state),
                normalize_optional(&profile.postal_code),
                normalize_optional(&profile.country),
                &now,
            ],
        )
        .map_err(|error| to_command_error("failed to update business profile", error))?;

    if rows == 0 {
        return Err("business profile was not found".into());
    }

    insert_log(conn, "INFO", "business", "Business profile updated", None)?;
    get_business_by_id(conn, &profile.id)
}

pub fn get_business_settings(
    conn: &Connection,
    business_id: &str,
) -> Result<BusinessSettings, String> {
    conn.query_row(
        "SELECT
            business_id, timezone, locale, date_format, theme, tax_label,
            default_tax_rate, prices_include_tax, receipt_footer,
            receipt_show_address, receipt_show_phone, auto_backup_enabled,
            backup_directory, module_restaurant_enabled, module_retail_enabled,
            module_inventory_enabled, module_services_enabled, updated_at
         FROM business_settings
         WHERE business_id = ?1
         LIMIT 1",
        params![business_id],
        settings_from_row,
    )
    .map_err(|error| to_command_error("failed to load business settings", error))
}

pub fn list_all_business_settings(conn: &Connection) -> Result<Vec<BusinessSettings>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT
                business_id, timezone, locale, date_format, theme, tax_label,
                default_tax_rate, prices_include_tax, receipt_footer,
                receipt_show_address, receipt_show_phone, auto_backup_enabled,
                backup_directory, module_restaurant_enabled, module_retail_enabled,
                module_inventory_enabled, module_services_enabled, updated_at
             FROM business_settings
             ORDER BY updated_at DESC",
        )
        .map_err(|error| to_command_error("failed to prepare business settings query", error))?;

    let rows = stmt
        .query_map([], settings_from_row)
        .map_err(|error| to_command_error("failed to query business settings", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map business settings", error))
}

pub fn save_business_settings(
    conn: &Connection,
    settings: &BusinessSettings,
) -> Result<(), String> {
    conn.execute(
        "INSERT INTO business_settings (
            business_id, timezone, locale, date_format, theme, tax_label,
            default_tax_rate, prices_include_tax, receipt_footer,
            receipt_show_address, receipt_show_phone, auto_backup_enabled,
            backup_directory, module_restaurant_enabled, module_retail_enabled,
            module_inventory_enabled, module_services_enabled, updated_at
         ) VALUES (
            ?1, ?2, ?3, ?4, ?5, ?6,
            ?7, ?8, ?9,
            ?10, ?11, ?12,
            ?13, ?14, ?15,
            ?16, ?17, ?18
         )
         ON CONFLICT(business_id) DO UPDATE SET
            timezone = excluded.timezone,
            locale = excluded.locale,
            date_format = excluded.date_format,
            theme = excluded.theme,
            tax_label = excluded.tax_label,
            default_tax_rate = excluded.default_tax_rate,
            prices_include_tax = excluded.prices_include_tax,
            receipt_footer = excluded.receipt_footer,
            receipt_show_address = excluded.receipt_show_address,
            receipt_show_phone = excluded.receipt_show_phone,
            auto_backup_enabled = excluded.auto_backup_enabled,
            backup_directory = excluded.backup_directory,
            module_restaurant_enabled = excluded.module_restaurant_enabled,
            module_retail_enabled = excluded.module_retail_enabled,
            module_inventory_enabled = excluded.module_inventory_enabled,
            module_services_enabled = excluded.module_services_enabled,
            updated_at = excluded.updated_at",
        params![
            &settings.business_id,
            normalize_text(&settings.timezone, "timezone")?,
            normalize_text(&settings.locale, "locale")?,
            normalize_text(&settings.date_format, "date format")?,
            normalize_text(&settings.theme, "theme")?,
            normalize_text(&settings.tax_label, "tax label")?,
            settings.default_tax_rate.max(0.0),
            bool_to_i64(settings.prices_include_tax),
            normalize_optional(&settings.receipt_footer),
            bool_to_i64(settings.receipt_show_address),
            bool_to_i64(settings.receipt_show_phone),
            bool_to_i64(settings.auto_backup_enabled),
            normalize_optional(&settings.backup_directory),
            bool_to_i64(settings.module_restaurant_enabled),
            bool_to_i64(settings.module_retail_enabled),
            bool_to_i64(settings.module_inventory_enabled),
            bool_to_i64(settings.module_services_enabled),
            now_iso(),
        ],
    )
    .map_err(|error| to_command_error("failed to save business settings", error))?;
    Ok(())
}

pub fn list_tax_profiles(conn: &Connection, business_id: &str) -> Result<Vec<TaxProfile>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, name, label, rate, prices_include_tax, is_default, updated_at
             FROM tax_profiles
             WHERE business_id = ?1
             ORDER BY is_default DESC, updated_at DESC",
        )
        .map_err(|error| to_command_error("failed to prepare tax profile query", error))?;

    let rows = stmt
        .query_map(params![business_id], tax_profile_from_row)
        .map_err(|error| to_command_error("failed to query tax profiles", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map tax profiles", error))
}

pub fn get_default_tax_profile(conn: &Connection, business_id: &str) -> Result<TaxProfile, String> {
    if let Some(profile) = list_tax_profiles(conn, business_id)?.into_iter().next() {
        return Ok(profile);
    }

    seed::ensure_workspace_support_for_business(conn, business_id)
        .map_err(|error| to_command_error("failed to ensure tax profile", error))?;
    list_tax_profiles(conn, business_id)?
        .into_iter()
        .next()
        .ok_or_else(|| "default tax profile was not found".into())
}

pub fn list_all_tax_profiles(conn: &Connection) -> Result<Vec<TaxProfile>, String> {
    let businesses = list_businesses(conn)?;
    let mut profiles = Vec::new();
    for business in businesses {
        profiles.extend(list_tax_profiles(conn, &business.id)?);
    }
    Ok(profiles)
}

pub fn save_default_tax_profile(
    conn: &Connection,
    profile: &TaxProfile,
) -> Result<TaxProfile, String> {
    let name = normalize_text(&profile.name, "tax profile name")?;
    let label = normalize_text(&profile.tax_label, "tax label")?;
    let now = now_iso();

    conn.execute(
        "UPDATE tax_profiles SET is_default = 0, updated_at = ?2 WHERE business_id = ?1",
        params![&profile.business_id, &now],
    )
    .map_err(|error| to_command_error("failed to clear default tax profile", error))?;

    let existing_id = profile.id.trim();
    let target_id = if existing_id.is_empty() {
        Uuid::new_v4().to_string()
    } else {
        existing_id.to_string()
    };

    conn.execute(
        "INSERT INTO tax_profiles (
            id, business_id, name, label, rate, prices_include_tax, is_default, created_at, updated_at
         ) VALUES (
            ?1, ?2, ?3, ?4, ?5, ?6, 1, ?7, ?8
         )
         ON CONFLICT(id) DO UPDATE SET
            name = excluded.name,
            label = excluded.label,
            rate = excluded.rate,
            prices_include_tax = excluded.prices_include_tax,
            is_default = excluded.is_default,
            updated_at = excluded.updated_at",
        params![
            &target_id,
            &profile.business_id,
            &name,
            &label,
            profile.default_rate.max(0.0),
            bool_to_i64(profile.prices_include_tax),
            &now,
            &now,
        ],
    )
    .map_err(|error| to_command_error("failed to save tax profile", error))?;

    get_default_tax_profile(conn, &profile.business_id)
}

pub fn get_default_receipt_profile(
    conn: &Connection,
    business_id: &str,
) -> Result<ReceiptProfile, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, name, footer_text, show_address, show_phone, show_email, show_business_code, paper_width, is_default, updated_at
             FROM receipt_profiles
             WHERE business_id = ?1
             ORDER BY is_default DESC, updated_at DESC
             LIMIT 1",
        )
        .map_err(|error| to_command_error("failed to prepare receipt profile query", error))?;

    let profile = stmt
        .query_row(params![business_id], receipt_profile_from_row)
        .optional()
        .map_err(|error| to_command_error("failed to query receipt profile", error))?;

    if let Some(profile) = profile {
        return Ok(profile);
    }

    seed::ensure_workspace_support_for_business(conn, business_id)
        .map_err(|error| to_command_error("failed to ensure receipt profile", error))?;

    conn.query_row(
        "SELECT id, business_id, name, footer_text, show_address, show_phone, show_email, show_business_code, paper_width, is_default, updated_at
         FROM receipt_profiles
         WHERE business_id = ?1
         ORDER BY is_default DESC, updated_at DESC
         LIMIT 1",
        params![business_id],
        receipt_profile_from_row,
    )
    .map_err(|error| to_command_error("failed to load default receipt profile", error))
}

pub fn list_all_receipt_profiles(conn: &Connection) -> Result<Vec<ReceiptProfile>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, name, footer_text, show_address, show_phone, show_email, show_business_code, paper_width, is_default, updated_at
             FROM receipt_profiles
             ORDER BY updated_at DESC",
        )
        .map_err(|error| to_command_error("failed to prepare receipt profile list", error))?;

    let rows = stmt
        .query_map([], receipt_profile_from_row)
        .map_err(|error| to_command_error("failed to query receipt profiles", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map receipt profiles", error))
}

pub fn save_default_receipt_profile(
    conn: &Connection,
    profile: &ReceiptProfile,
) -> Result<ReceiptProfile, String> {
    let now = now_iso();
    let name = normalize_text(&profile.name, "receipt profile name")?;
    let paper_width = normalize_text(&profile.paper_width, "paper width")?;

    conn.execute(
        "UPDATE receipt_profiles SET is_default = 0, updated_at = ?2 WHERE business_id = ?1",
        params![&profile.business_id, &now],
    )
    .map_err(|error| to_command_error("failed to clear receipt defaults", error))?;

    let existing_id = profile.id.trim();
    let target_id = if existing_id.is_empty() {
        Uuid::new_v4().to_string()
    } else {
        existing_id.to_string()
    };

    conn.execute(
        "INSERT INTO receipt_profiles (
            id, business_id, name, header_line1, header_line2, footer_text,
            show_address, show_phone, show_tax_breakdown, paper_width,
            copies, is_default, created_at, updated_at, show_email, show_business_code
         ) VALUES (
            ?1, ?2, ?3, NULL, NULL, ?4,
            ?5, ?6, 1, ?7,
            1, 1, ?8, ?9, ?10, ?11
         )
         ON CONFLICT(id) DO UPDATE SET
            name = excluded.name,
            footer_text = excluded.footer_text,
            show_address = excluded.show_address,
            show_phone = excluded.show_phone,
            paper_width = excluded.paper_width,
            is_default = excluded.is_default,
            updated_at = excluded.updated_at,
            show_email = excluded.show_email,
            show_business_code = excluded.show_business_code",
        params![
            &target_id,
            &profile.business_id,
            &name,
            normalize_optional(&profile.footer_text),
            bool_to_i64(profile.show_address),
            bool_to_i64(profile.show_phone),
            &paper_width,
            &now,
            &now,
            bool_to_i64(profile.show_email),
            bool_to_i64(profile.show_business_code),
        ],
    )
    .map_err(|error| to_command_error("failed to save receipt profile", error))?;

    get_default_receipt_profile(conn, &profile.business_id)
}

fn set_flag(flags: &mut ModuleFlags, key: &str, enabled: bool) {
    match key {
        "restaurant" => flags.restaurant_enabled = enabled,
        "retail" => flags.retail_enabled = enabled,
        "inventory" => flags.inventory_enabled = enabled,
        "services" => flags.services_enabled = enabled,
        "customers" => flags.customers_enabled = enabled,
        "suppliers" => flags.suppliers_enabled = enabled,
        "expenses" => flags.expenses_enabled = enabled,
        "reporting" => flags.reporting_enabled = enabled,
        "data_center" => flags.data_center_enabled = enabled,
        _ => {}
    }
}

fn active_module_keys(flags: &ModuleFlags) -> Vec<String> {
    let mut modules = Vec::new();
    if flags.restaurant_enabled {
        modules.push("restaurant".to_string());
    }
    if flags.retail_enabled {
        modules.push("retail".to_string());
    }
    if flags.inventory_enabled {
        modules.push("inventory".to_string());
    }
    if flags.services_enabled {
        modules.push("services".to_string());
    }
    if flags.customers_enabled {
        modules.push("customers".to_string());
    }
    if flags.suppliers_enabled {
        modules.push("suppliers".to_string());
    }
    if flags.expenses_enabled {
        modules.push("expenses".to_string());
    }
    if flags.reporting_enabled {
        modules.push("reporting".to_string());
    }
    if flags.data_center_enabled {
        modules.push("data_center".to_string());
    }
    modules
}

pub fn get_module_flags(conn: &Connection, business_id: &str) -> Result<ModuleFlags, String> {
    let settings = get_business_settings(conn, business_id)?;
    let mut flags = ModuleFlags {
        business_id: business_id.to_string(),
        restaurant_enabled: settings.module_restaurant_enabled,
        retail_enabled: settings.module_retail_enabled,
        inventory_enabled: settings.module_inventory_enabled,
        services_enabled: settings.module_services_enabled,
        customers_enabled: false,
        suppliers_enabled: false,
        expenses_enabled: false,
        reporting_enabled: false,
        data_center_enabled: true,
        updated_at: settings.updated_at.clone(),
    };

    let mut stmt = conn
        .prepare(
            "SELECT module_key, enabled, updated_at
             FROM module_flags
             WHERE business_id = ?1
             ORDER BY module_key ASC",
        )
        .map_err(|error| to_command_error("failed to prepare module flag query", error))?;

    let mut rows = stmt
        .query(params![business_id])
        .map_err(|error| to_command_error("failed to query module flags", error))?;

    while let Some(row) = rows
        .next()
        .map_err(|error| to_command_error("failed to iterate module flags", error))?
    {
        let module_key: String = row
            .get(0)
            .map_err(|error| to_command_error("failed to read module key", error))?;
        let enabled = row
            .get::<_, i64>(1)
            .map_err(|error| to_command_error("failed to read module enabled value", error))?
            != 0;
        let updated_at: String = row
            .get(2)
            .map_err(|error| to_command_error("failed to read module updated timestamp", error))?;
        set_flag(&mut flags, &module_key, enabled);
        flags.updated_at = updated_at;
    }

    Ok(flags)
}

pub fn list_all_module_flags(conn: &Connection) -> Result<Vec<ModuleFlags>, String> {
    let businesses = list_businesses(conn)?;
    let mut output = Vec::new();
    for business in businesses {
        output.push(get_module_flags(conn, &business.id)?);
    }
    Ok(output)
}

pub fn save_module_flags(conn: &Connection, flags: &ModuleFlags) -> Result<(), String> {
    let now = now_iso();
    for (module_key, enabled) in [
        ("restaurant", flags.restaurant_enabled),
        ("retail", flags.retail_enabled),
        ("inventory", flags.inventory_enabled),
        ("services", flags.services_enabled),
        ("customers", flags.customers_enabled),
        ("suppliers", flags.suppliers_enabled),
        ("expenses", flags.expenses_enabled),
        ("reporting", flags.reporting_enabled),
        ("data_center", flags.data_center_enabled),
    ] {
        conn.execute(
            "INSERT INTO module_flags (business_id, module_key, enabled, updated_at)
             VALUES (?1, ?2, ?3, ?4)
             ON CONFLICT(business_id, module_key)
             DO UPDATE SET enabled = excluded.enabled, updated_at = excluded.updated_at",
            params![&flags.business_id, module_key, bool_to_i64(enabled), &now],
        )
        .map_err(|error| to_command_error("failed to save module flags", error))?;
    }
    Ok(())
}

pub fn list_sequence_counters(
    conn: &Connection,
    business_id: &str,
) -> Result<Vec<SequenceCounter>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT business_id, counter_key, prefix, next_number, padding, reset_policy, updated_at
             FROM sequence_counters
             WHERE business_id = ?1
             ORDER BY counter_key ASC",
        )
        .map_err(|error| to_command_error("failed to prepare sequence query", error))?;

    let rows = stmt
        .query_map(params![business_id], sequence_from_row)
        .map_err(|error| to_command_error("failed to query sequence counters", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map sequence counters", error))
}

pub fn list_all_sequence_counters(conn: &Connection) -> Result<Vec<SequenceCounter>, String> {
    let businesses = list_businesses(conn)?;
    let mut output = Vec::new();
    for business in businesses {
        output.extend(list_sequence_counters(conn, &business.id)?);
    }
    Ok(output)
}

pub fn save_sequence_counters(
    conn: &Connection,
    counters: &[SequenceCounter],
) -> Result<(), String> {
    let now = now_iso();
    for counter in counters {
        conn.execute(
            "INSERT INTO sequence_counters (business_id, counter_key, prefix, next_number, padding, reset_policy, updated_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)
             ON CONFLICT(business_id, counter_key)
             DO UPDATE SET
                prefix = excluded.prefix,
                next_number = excluded.next_number,
                padding = excluded.padding,
                reset_policy = excluded.reset_policy,
                updated_at = excluded.updated_at",
            params![
                &counter.business_id,
                normalize_text(&counter.scope, "sequence scope")?,
                normalize_text(&counter.prefix, "sequence prefix")?.to_uppercase(),
                counter.next_number.max(1),
                counter.padding.max(1),
                normalize_text(&counter.reset_policy, "reset policy")?,
                &now,
            ],
        )
        .map_err(|error| to_command_error("failed to save sequence counters", error))?;
    }
    Ok(())
}

pub fn save_workspace_configuration(
    conn: &Connection,
    input: &WorkspaceConfigurationInput,
) -> Result<(), String> {
    let business_id = input.business_settings.business_id.clone();
    let mut settings = input.business_settings.clone();
    settings.tax_label = input.tax_profile.tax_label.clone();
    settings.default_tax_rate = input.tax_profile.default_rate;
    settings.prices_include_tax = input.tax_profile.prices_include_tax;
    settings.receipt_footer = input.receipt_profile.footer_text.clone();
    settings.receipt_show_address = input.receipt_profile.show_address;
    settings.receipt_show_phone = input.receipt_profile.show_phone;
    settings.module_restaurant_enabled = input.module_flags.restaurant_enabled;
    settings.module_retail_enabled = input.module_flags.retail_enabled;
    settings.module_inventory_enabled = input.module_flags.inventory_enabled;
    settings.module_services_enabled = input.module_flags.services_enabled;
    settings.updated_at = now_iso();

    save_business_settings(conn, &settings)?;

    let tax_profile = TaxProfile {
        business_id: business_id.clone(),
        ..input.tax_profile.clone()
    };
    save_default_tax_profile(conn, &tax_profile)?;

    let receipt_profile = ReceiptProfile {
        business_id: business_id.clone(),
        ..input.receipt_profile.clone()
    };
    save_default_receipt_profile(conn, &receipt_profile)?;

    let module_flags = ModuleFlags {
        business_id: business_id.clone(),
        updated_at: now_iso(),
        ..input.module_flags.clone()
    };
    save_module_flags(conn, &module_flags)?;

    let counters = input
        .sequence_counters
        .iter()
        .cloned()
        .map(|mut counter| {
            counter.business_id = business_id.clone();
            counter
        })
        .collect::<Vec<_>>();
    save_sequence_counters(conn, &counters)?;

    insert_log(
        conn,
        "INFO",
        "settings",
        "Workspace configuration saved",
        None,
    )?;
    Ok(())
}

fn format_sequence_preview(prefix: &str, next_number: i64, padding: i64) -> String {
    let normalized_padding = padding.max(1) as usize;
    let normalized_number = next_number.max(1);
    format!(
        "{prefix}{:0width$}",
        normalized_number,
        width = normalized_padding
    )
}

pub fn list_business_workspace_summaries(
    conn: &Connection,
) -> Result<Vec<BusinessWorkspaceSummary>, String> {
    let businesses = list_businesses(conn)?;
    let mut output = Vec::new();

    for business in businesses {
        let settings = get_business_settings(conn, &business.id)?;
        let tax_profile = get_default_tax_profile(conn, &business.id)?;
        let module_flags = get_module_flags(conn, &business.id)?;
        let sequences = list_sequence_counters(conn, &business.id)?;
        let sale_sequence = sequences
            .iter()
            .find(|counter| counter.scope == "sale")
            .cloned();
        let next_sale_sequence = sale_sequence
            .map(|sequence| {
                format_sequence_preview(&sequence.prefix, sequence.next_number, sequence.padding)
            })
            .unwrap_or_else(|| "SAL-00001".into());

        output.push(BusinessWorkspaceSummary {
            business_id: business.id.clone(),
            name: business.name.clone(),
            code: business.code.clone(),
            business_type: business.business_type.clone(),
            currency_code: business.currency_code.clone(),
            theme: settings.theme.clone(),
            timezone: settings.timezone.clone(),
            tax_label: tax_profile.tax_label.clone(),
            default_tax_rate: tax_profile.default_rate,
            next_sale_sequence,
            active_modules: active_module_keys(&module_flags),
            archived_at: business.archived_at.clone(),
            updated_at: business.updated_at.clone(),
        });
    }

    Ok(output)
}

pub fn build_storage_status(conn: &Connection, paths: &AppPaths) -> Result<StorageStatus, String> {
    let backup_count: usize = conn
        .query_row("SELECT COUNT(*) FROM backup_records", [], |row| {
            row.get::<_, i64>(0)
        })
        .map_err(|error| to_command_error("failed to count backup records", error))?
        as usize;
    let export_count: usize =
        conn.query_row("SELECT COUNT(*) FROM export_jobs", [], |row| {
            row.get::<_, i64>(0)
        })
        .map_err(|error| to_command_error("failed to count export jobs", error))? as usize;

    Ok(StorageStatus {
        data_dir: paths.data_dir.clone(),
        config_dir: paths.config_dir.clone(),
        log_dir: paths.log_dir.clone(),
        backup_dir: paths.backup_dir.clone(),
        export_dir: paths.export_dir.clone(),
        database_path: paths.database_path.clone(),
        database_exists: fs::metadata(&paths.database_path).is_ok(),
        backup_count,
        export_count,
    })
}

pub fn insert_backup_record(conn: &Connection, record: &BackupRecord) -> Result<(), String> {
    conn.execute(
        "INSERT INTO backup_records (id, business_id, file_name, file_path, checksum, status, created_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
        params![
            &record.id,
            &record.business_id,
            &record.file_name,
            &record.file_path,
            &record.checksum,
            &record.status,
            &record.created_at,
        ],
    )
    .map_err(|error| to_command_error("failed to insert backup record", error))?;
    Ok(())
}

pub fn list_backups(conn: &Connection) -> Result<Vec<BackupRecord>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, file_name, file_path, checksum, status, created_at
             FROM backup_records
             ORDER BY created_at DESC",
        )
        .map_err(|error| to_command_error("failed to prepare backup query", error))?;

    let rows = stmt
        .query_map([], backup_from_row)
        .map_err(|error| to_command_error("failed to query backups", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map backups", error))
}

pub fn insert_export_job(conn: &Connection, record: &ExportJobRecord) -> Result<(), String> {
    conn.execute(
        "INSERT INTO export_jobs (id, business_id, format, status, target_path, created_at, completed_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
        params![
            &record.id,
            &record.business_id,
            &record.format,
            &record.status,
            &record.target_path,
            &record.created_at,
            &record.completed_at,
        ],
    )
    .map_err(|error| to_command_error("failed to insert export job", error))?;
    Ok(())
}

pub fn insert_import_job(
    conn: &Connection,
    business_id: Option<&str>,
    format: &str,
    status: &str,
    source_path: &str,
) -> Result<(), String> {
    conn.execute(
        "INSERT INTO import_jobs (id, business_id, format, status, source_path, created_at, completed_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, NULL)",
        params![
            Uuid::new_v4().to_string(),
            business_id,
            format,
            status,
            source_path,
            now_iso(),
        ],
    )
    .map_err(|error| to_command_error("failed to insert import job", error))?;
    Ok(())
}

```

## files/src-tauri/src/core/migrations/005_pos_checkout_core.sql

```sql
CREATE TABLE IF NOT EXISTS register_sessions (
  id TEXT PRIMARY KEY,
  business_id TEXT NOT NULL,
  label TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  opened_at TEXT NOT NULL,
  closed_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS sales (
  id TEXT PRIMARY KEY,
  business_id TEXT NOT NULL,
  register_session_id TEXT,
  sale_number TEXT NOT NULL,
  sale_status TEXT NOT NULL,
  payment_status TEXT NOT NULL,
  currency_code TEXT NOT NULL,
  subtotal_amount REAL NOT NULL DEFAULT 0,
  discount_amount REAL NOT NULL DEFAULT 0,
  tax_amount REAL NOT NULL DEFAULT 0,
  total_amount REAL NOT NULL DEFAULT 0,
  amount_paid REAL NOT NULL DEFAULT 0,
  balance_due REAL NOT NULL DEFAULT 0,
  item_count INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  completed_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  FOREIGN KEY (register_session_id) REFERENCES register_sessions(id) ON DELETE SET NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_business_sale_number
  ON sales (business_id, sale_number);

CREATE INDEX IF NOT EXISTS idx_sales_business_completed_at
  ON sales (business_id, completed_at DESC, created_at DESC);

CREATE TABLE IF NOT EXISTS sale_lines (
  id TEXT PRIMARY KEY,
  sale_id TEXT NOT NULL,
  business_id TEXT NOT NULL,
  item_id TEXT,
  item_name TEXT NOT NULL,
  item_kind TEXT NOT NULL,
  category_name TEXT,
  sku TEXT,
  primary_barcode TEXT,
  unit_code TEXT,
  tax_label TEXT,
  tax_rate REAL NOT NULL DEFAULT 0,
  prices_include_tax INTEGER NOT NULL DEFAULT 0,
  quantity REAL NOT NULL,
  unit_price REAL NOT NULL,
  gross_amount REAL NOT NULL DEFAULT 0,
  discount_amount REAL NOT NULL DEFAULT 0,
  net_amount REAL NOT NULL DEFAULT 0,
  tax_amount REAL NOT NULL DEFAULT 0,
  total_amount REAL NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
  FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
  FOREIGN KEY (item_id) REFERENCES catalog_items(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_sale_lines_sale_id
  ON sale_lines (sale_id, created_at ASC);

CREATE INDEX IF NOT EXISTS idx_sale_lines_business_item
  ON sale_lines (business_id, item_id, created_at DESC);

CREATE TABLE IF NOT EXISTS sale_payments (
  id TEXT PRIMARY KEY,
  sale_id TEXT NOT NULL,
  business_id TEXT NOT NULL,
  payment_mode TEXT NOT NULL,
  amount REAL NOT NULL DEFAULT 0,
  reference_value TEXT,
  notes TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
  FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_sale_payments_sale_id
  ON sale_payments (sale_id, created_at ASC);

CREATE TABLE IF NOT EXISTS sale_holds (
  id TEXT PRIMARY KEY,
  business_id TEXT NOT NULL,
  hold_code TEXT NOT NULL,
  hold_label TEXT NOT NULL,
  item_count INTEGER NOT NULL DEFAULT 0,
  subtotal_amount REAL NOT NULL DEFAULT 0,
  discount_amount REAL NOT NULL DEFAULT 0,
  tax_amount REAL NOT NULL DEFAULT 0,
  total_amount REAL NOT NULL DEFAULT 0,
  notes TEXT,
  cart_json TEXT NOT NULL,
  cart_discount_amount REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_sale_holds_business_hold_code
  ON sale_holds (business_id, hold_code);

CREATE INDEX IF NOT EXISTS idx_sale_holds_business_updated_at
  ON sale_holds (business_id, updated_at DESC, created_at DESC);

```

## files/src-tauri/src/core/migrations.rs

```rust
use rusqlite::{Connection, OptionalExtension};

pub const CURRENT_SCHEMA_VERSION: i64 = 5;

const MIGRATION_001: &str = include_str!("migrations/001_base.sql");
const MIGRATION_002: &str = include_str!("migrations/002_multi_business_workspace.sql");
const MIGRATION_003: &str = include_str!("migrations/003_catalog_core.sql");
const MIGRATION_004: &str = include_str!("migrations/004_inventory_ledger_core.sql");
const MIGRATION_005: &str = include_str!("migrations/005_pos_checkout_core.sql");

fn table_exists(conn: &Connection, table_name: &str) -> rusqlite::Result<bool> {
    let exists: Option<String> = conn
        .query_row(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?1 LIMIT 1",
            [table_name],
            |row| row.get(0),
        )
        .optional()?;
    Ok(exists.is_some())
}

fn detect_current_schema_version(conn: &Connection) -> rusqlite::Result<i64> {
    let user_version: i64 = conn.query_row("PRAGMA user_version", [], |row| row.get(0))?;
    if user_version > 0 {
        return Ok(user_version);
    }

    if table_exists(conn, "sales")? || table_exists(conn, "sale_holds")? {
        return Ok(5);
    }

    if table_exists(conn, "inventory_stock_movements")? {
        return Ok(4);
    }

    if table_exists(conn, "catalog_items")? {
        return Ok(3);
    }

    if table_exists(conn, "tax_profiles")? {
        return Ok(2);
    }

    if table_exists(conn, "app_meta")? {
        let legacy_version = conn
            .query_row(
                "SELECT value FROM app_meta WHERE key = 'schema_version' LIMIT 1",
                [],
                |row| row.get::<_, String>(0),
            )
            .optional()?;

        if let Some(value) = legacy_version {
            if let Ok(parsed) = value.parse::<i64>() {
                return Ok(parsed);
            }
        }

        return Ok(1);
    }

    if table_exists(conn, "businesses")? {
        return Ok(1);
    }

    Ok(0)
}

pub fn run(conn: &Connection) -> rusqlite::Result<()> {
    let mut current_version = detect_current_schema_version(conn)?;

    if current_version < 1 {
        conn.execute_batch(MIGRATION_001)?;
        current_version = 1;
    }

    if current_version < 2 {
        conn.execute_batch(MIGRATION_002)?;
        current_version = 2;
    }

    if current_version < 3 {
        conn.execute_batch(MIGRATION_003)?;
        current_version = 3;
    }

    if current_version < 4 {
        conn.execute_batch(MIGRATION_004)?;
        current_version = 4;
    }

    if current_version < 5 {
        conn.execute_batch(MIGRATION_005)?;
        current_version = 5;
    }

    conn.pragma_update(None, "user_version", current_version)?;
    Ok(())
}

```

## files/src-tauri/src/core/mod.rs

```rust
pub mod catalog;
pub mod db;
pub mod error;
pub mod inventory;
pub mod migrations;
pub mod patching;
pub mod paths;
pub mod pos;
pub mod seed;

```

## files/src-tauri/src/core/patching.rs

```rust
use chrono::Utc;
use rusqlite::{params, Connection};
use serde_json::json;

use super::migrations::CURRENT_SCHEMA_VERSION;

struct PatchDefinition {
    patch_id: &'static str,
    patch_name: &'static str,
    schema_version: i64,
    notes: &'static str,
}

const PATCHES: [PatchDefinition; 5] = [
    PatchDefinition {
        patch_id: "P001_foundation_base_structure",
        patch_name: "Foundation Base Structure",
        schema_version: 1,
        notes: "Initial desktop foundation with local storage, business/settings shell, backup/export foundation.",
    },
    PatchDefinition {
        patch_id: "P002_multi_business_workspace_settings_core",
        patch_name: "Multi-Business Workspace & Settings Core",
        schema_version: 2,
        notes: "Adds multi-business switching, business-scoped settings profiles, normalized module flags, receipt profiles, tax profiles, and sequence counters.",
    },
    PatchDefinition {
        patch_id: "P003_catalog_core",
        patch_name: "Catalog Core",
        schema_version: 3,
        notes: "Adds categories, units, item master data, barcode foundations, and catalog-aware export scope for local businesses.",
    },
    PatchDefinition {
        patch_id: "P004_inventory_ledger_core",
        patch_name: "Inventory Ledger Core",
        schema_version: 4,
        notes: "Adds stock movement history, on-hand stock balances, reorder monitoring, and inventory-aware export data.",
    },
    PatchDefinition {
        patch_id: "P005_pos_checkout_core",
        patch_name: "POS Checkout Core",
        schema_version: 5,
        notes: "Adds local checkout with held carts, completed sales, payment capture, receipt-ready sale history, and stock deduction through the existing inventory ledger.",
    },
];

pub const PATCH_ID: &str = "P005_pos_checkout_core";
pub const PATCH_NAME: &str = "POS Checkout Core";
pub const APP_VERSION: &str = "0.5.0";

pub fn register_patch(conn: &Connection) -> rusqlite::Result<()> {
    for patch in PATCHES {
        let now = Utc::now().to_rfc3339();
        let manifest = json!({
            "patch_id": patch.patch_id,
            "patch_name": patch.patch_name,
            "schema_version": patch.schema_version,
            "applied_at": now.clone(),
            "notes": patch.notes,
        });

        conn.execute(
            "INSERT OR IGNORE INTO patch_history (patch_id, patch_name, schema_version, applied_at, manifest_json)
             VALUES (?1, ?2, ?3, ?4, ?5)",
            params![
                patch.patch_id,
                patch.patch_name,
                patch.schema_version,
                now,
                manifest.to_string()
            ],
        )?;
    }

    let now = Utc::now().to_rfc3339();

    conn.execute(
        "INSERT INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        params![
            "schema_version",
            CURRENT_SCHEMA_VERSION.to_string(),
            now.clone()
        ],
    )?;

    conn.execute(
        "INSERT INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        params!["patch_level", PATCH_ID, now.clone()],
    )?;

    conn.execute(
        "INSERT INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        params!["app_version", APP_VERSION, now],
    )?;

    Ok(())
}

```

## files/src-tauri/src/core/pos.rs

```rust
use std::collections::HashMap;

use chrono::Utc;
use rusqlite::{params, Connection, OptionalExtension, Row};
use serde_json::{from_str, to_string};
use uuid::Uuid;

use crate::domain::models::{
    BusinessProfile, CompletePosSaleInput, PosCartLineInput, PosHoldSummary, PosPaymentEntryInput,
    PosSaleDetail, PosSaleLine, PosSalePayment, PosSaleRecord, PosSellableItem, PosSummary,
    PosWorkspace, RegisterSession, SavePosHoldInput,
};

use super::{db, error::to_command_error};

const EPSILON: f64 = 0.000_001;

#[derive(Debug, Clone)]
struct PosDraftLine {
    item: PosSellableItem,
    quantity: f64,
    unit_price: f64,
    gross_amount: f64,
    line_discount: f64,
    base_after_line_discount: f64,
    notes: Option<String>,
    cost_price: f64,
}

#[derive(Debug, Clone)]
struct ComputedSaleLine {
    item_id: Option<String>,
    item_name: String,
    item_kind: String,
    category_name: Option<String>,
    sku: Option<String>,
    primary_barcode: Option<String>,
    unit_code: Option<String>,
    tax_label: Option<String>,
    tax_rate: f64,
    prices_include_tax: bool,
    quantity: f64,
    unit_price: f64,
    gross_amount: f64,
    discount_amount: f64,
    net_amount: f64,
    tax_amount: f64,
    total_amount: f64,
    notes: Option<String>,
    track_stock: bool,
    on_hand_quantity: f64,
    cost_price: f64,
}

#[derive(Debug, Clone)]
struct ComputedSale {
    lines: Vec<ComputedSaleLine>,
    subtotal_amount: f64,
    discount_amount: f64,
    tax_amount: f64,
    total_amount: f64,
}

#[derive(Debug, Clone)]
struct RegisterSessionRow {
    pub session: RegisterSession,
}

fn round2(value: f64) -> f64 {
    if !value.is_finite() {
        return 0.0;
    }
    ((value + f64::EPSILON) * 100.0).round() / 100.0
}

fn canonical_zero(value: f64) -> f64 {
    if value.abs() < EPSILON {
        0.0
    } else {
        value
    }
}

fn bool_from_row(row: &Row, index: usize) -> rusqlite::Result<bool> {
    let value: i64 = row.get(index)?;
    Ok(value != 0)
}

fn bool_to_i64(value: bool) -> i64 {
    if value {
        1
    } else {
        0
    }
}

fn normalize_optional(value: &Option<String>) -> Option<String> {
    value.as_ref().and_then(|raw| {
        let trimmed = raw.trim();
        if trimmed.is_empty() {
            None
        } else {
            Some(trimmed.to_string())
        }
    })
}

fn normalize_text(value: &str, field: &str) -> Result<String, String> {
    let trimmed = value.trim();
    if trimmed.is_empty() {
        return Err(format!("{field} cannot be empty"));
    }
    Ok(trimmed.to_string())
}

fn normalize_payment_mode(value: &str) -> String {
    match value.trim().to_lowercase().as_str() {
        "cash" => "cash".into(),
        "card" => "card".into(),
        "upi" => "upi".into(),
        "bank" | "bank_transfer" => "bank_transfer".into(),
        _ => "other".into(),
    }
}

fn register_session_from_row(row: &Row) -> rusqlite::Result<RegisterSessionRow> {
    Ok(RegisterSessionRow {
        session: RegisterSession {
            id: row.get(0)?,
            business_id: row.get(1)?,
            label: row.get(2)?,
            status: row.get(3)?,
            opened_at: row.get(4)?,
            closed_at: row.get(5)?,
            created_at: row.get(6)?,
            updated_at: row.get(7)?,
        },
    })
}

fn sellable_item_with_cost_from_row(row: &Row) -> rusqlite::Result<(PosSellableItem, f64)> {
    let track_stock = bool_from_row(row, 10)?;
    let on_hand_quantity: f64 = row.get(11)?;
    let allow_fractional = bool_from_row(row, 6)?;
    let is_active = bool_from_row(row, 15)?;

    Ok((
        PosSellableItem {
            item_id: row.get(0)?,
            name: row.get(1)?,
            display_name: row.get(2)?,
            item_kind: row.get(3)?,
            category_name: row.get(4)?,
            unit_code: row.get(5)?,
            allow_fractional,
            sku: row.get(7)?,
            primary_barcode: row.get(8)?,
            selling_price: row.get(9)?,
            track_stock,
            on_hand_quantity,
            tax_label: row.get(12)?,
            tax_rate: row.get::<_, Option<f64>>(13)?.unwrap_or(0.0),
            prices_include_tax: bool_from_row(row, 14)?,
            is_available: is_active && (!track_stock || on_hand_quantity > 0.0),
        },
        row.get::<_, Option<f64>>(16)?.unwrap_or(0.0),
    ))
}

fn sale_record_from_row(row: &Row) -> rusqlite::Result<PosSaleRecord> {
    Ok(PosSaleRecord {
        id: row.get(0)?,
        business_id: row.get(1)?,
        register_session_id: row.get(2)?,
        sale_number: row.get(3)?,
        sale_status: row.get(4)?,
        payment_status: row.get(5)?,
        currency_code: row.get(6)?,
        subtotal_amount: row.get(7)?,
        discount_amount: row.get(8)?,
        tax_amount: row.get(9)?,
        total_amount: row.get(10)?,
        amount_paid: row.get(11)?,
        balance_due: row.get(12)?,
        item_count: row.get::<_, i64>(13)? as usize,
        notes: row.get(14)?,
        completed_at: row.get(15)?,
        created_at: row.get(16)?,
        updated_at: row.get(17)?,
    })
}

fn sale_line_from_row(row: &Row) -> rusqlite::Result<PosSaleLine> {
    Ok(PosSaleLine {
        id: row.get(0)?,
        sale_id: row.get(1)?,
        item_id: row.get(2)?,
        item_name: row.get(3)?,
        item_kind: row.get(4)?,
        category_name: row.get(5)?,
        sku: row.get(6)?,
        primary_barcode: row.get(7)?,
        unit_code: row.get(8)?,
        tax_label: row.get(9)?,
        tax_rate: row.get::<_, Option<f64>>(10)?.unwrap_or(0.0),
        prices_include_tax: bool_from_row(row, 11)?,
        quantity: row.get(12)?,
        unit_price: row.get(13)?,
        gross_amount: row.get(14)?,
        discount_amount: row.get(15)?,
        net_amount: row.get(16)?,
        tax_amount: row.get(17)?,
        total_amount: row.get(18)?,
        notes: row.get(19)?,
    })
}

fn sale_payment_from_row(row: &Row) -> rusqlite::Result<PosSalePayment> {
    Ok(PosSalePayment {
        id: row.get(0)?,
        sale_id: row.get(1)?,
        payment_mode: row.get(2)?,
        amount: row.get(3)?,
        reference_value: row.get(4)?,
        notes: row.get(5)?,
        created_at: row.get(6)?,
    })
}

fn hold_summary_from_row(row: &Row) -> rusqlite::Result<PosHoldSummary> {
    let cart_json: String = row.get(9)?;
    let cart_lines = from_str::<Vec<PosCartLineInput>>(&cart_json).unwrap_or_default();

    Ok(PosHoldSummary {
        id: row.get(0)?,
        business_id: row.get(1)?,
        hold_code: row.get(2)?,
        hold_label: row.get(3)?,
        item_count: row.get::<_, i64>(4)? as usize,
        subtotal_amount: row.get(5)?,
        discount_amount: row.get(6)?,
        tax_amount: row.get(7)?,
        total_amount: row.get(8)?,
        notes: row.get(10)?,
        cart_lines,
        cart_discount_amount: row.get(11)?,
        created_at: row.get(12)?,
        updated_at: row.get(13)?,
    })
}

fn list_register_sessions_for_business(
    conn: &Connection,
    business_id: &str,
) -> Result<Vec<RegisterSession>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, label, status, opened_at, closed_at, created_at, updated_at
             FROM register_sessions
             WHERE business_id = ?1
             ORDER BY status = 'open' DESC, created_at ASC",
        )
        .map_err(|error| to_command_error("failed to prepare register session query", error))?;

    let rows = stmt
        .query_map(params![business_id], register_session_from_row)
        .map_err(|error| to_command_error("failed to query register sessions", error))?;

    rows.map(|row| row.map(|record| record.session))
        .collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map register sessions", error))
}

fn get_primary_register(conn: &Connection, business_id: &str) -> Result<RegisterSession, String> {
    ensure_pos_support_for_business(conn, business_id)?;
    list_register_sessions_for_business(conn, business_id)?
        .into_iter()
        .next()
        .ok_or_else(|| "no register session available".into())
}

fn list_sellable_items_with_cost(
    conn: &Connection,
    business_id: &str,
) -> Result<Vec<(PosSellableItem, f64)>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT
                i.id,
                i.name,
                i.display_name,
                i.item_kind,
                c.name,
                u.code,
                COALESCE(u.allow_fractional, 0),
                i.sku,
                i.primary_barcode,
                i.selling_price,
                i.track_stock,
                i.stock_quantity,
                t.label,
                COALESCE(t.rate, 0),
                COALESCE(t.prices_include_tax, 0),
                i.is_active,
                i.cost_price
             FROM catalog_items i
             LEFT JOIN catalog_categories c ON c.id = i.category_id
             LEFT JOIN catalog_units u ON u.id = i.unit_id
             LEFT JOIN tax_profiles t ON t.id = i.tax_profile_id
             WHERE i.business_id = ?1
               AND i.archived_at IS NULL
               AND i.is_active = 1
             ORDER BY i.name COLLATE NOCASE ASC",
        )
        .map_err(|error| to_command_error("failed to prepare sellable item query", error))?;

    let rows = stmt
        .query_map(params![business_id], sellable_item_with_cost_from_row)
        .map_err(|error| to_command_error("failed to query sellable items", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map sellable items", error))
}

fn list_sellable_items(conn: &Connection, business_id: &str) -> Result<Vec<PosSellableItem>, String> {
    Ok(list_sellable_items_with_cost(conn, business_id)?
        .into_iter()
        .map(|(item, _cost)| item)
        .collect())
}

fn build_sale_calculation(
    conn: &Connection,
    business_id: &str,
    cart_lines: &[PosCartLineInput],
    cart_discount_amount: f64,
) -> Result<ComputedSale, String> {
    let mut item_map = HashMap::new();
    for (item, cost_price) in list_sellable_items_with_cost(conn, business_id)? {
        item_map.insert(item.item_id.clone(), (item, cost_price));
    }

    let mut draft_lines = Vec::new();
    for line in cart_lines {
        let Some((item, cost_price)) = item_map.get(&line.item_id) else {
            return Err(format!("item {} is not available in the active business", line.item_id));
        };

        let quantity = if line.quantity.is_finite() { line.quantity } else { 0.0 };
        if quantity <= 0.0 {
            return Err("line quantity must be greater than zero".into());
        }
        if !item.allow_fractional && (quantity.fract().abs() > EPSILON) {
            return Err(format!("{} does not allow fractional quantity", item.name));
        }

        let unit_price = line
            .unit_price
            .filter(|value| value.is_finite() && *value >= 0.0)
            .unwrap_or(item.selling_price);
        let gross_amount = round2(unit_price * quantity);
        let line_discount = round2(line.discount_amount.max(0.0).min(gross_amount));
        let base_after_line_discount = round2(gross_amount - line_discount);

        draft_lines.push(PosDraftLine {
            item: item.clone(),
            quantity,
            unit_price,
            gross_amount,
            line_discount,
            base_after_line_discount,
            notes: normalize_optional(&line.notes),
            cost_price: *cost_price,
        });
    }

    let total_eligible = round2(
        draft_lines
            .iter()
            .map(|line| line.base_after_line_discount)
            .sum::<f64>(),
    );

    let normalized_cart_discount = round2(cart_discount_amount.max(0.0).min(total_eligible));
    let mut allocated_discounts = vec![0.0; draft_lines.len()];

    if !draft_lines.is_empty() && total_eligible > 0.0 {
        let mut consumed = 0.0;
        for (index, line) in draft_lines.iter().enumerate() {
            if index == draft_lines.len() - 1 {
                allocated_discounts[index] = round2(normalized_cart_discount - consumed);
            } else {
                let share = round2(
                    (normalized_cart_discount * line.base_after_line_discount) / total_eligible,
                );
                allocated_discounts[index] = share;
                consumed = round2(consumed + share);
            }
        }
    }

    let lines = draft_lines
        .into_iter()
        .enumerate()
        .map(|(index, draft)| {
            let discount_amount = round2(draft.line_discount + allocated_discounts[index]);
            let discounted_amount = round2((draft.gross_amount - discount_amount).max(0.0));
            let mut net_amount = discounted_amount;
            let mut tax_amount = 0.0;
            let mut total_amount = discounted_amount;

            if draft.item.prices_include_tax {
                tax_amount = if draft.item.tax_rate > 0.0 {
                    round2((discounted_amount * draft.item.tax_rate) / (100.0 + draft.item.tax_rate))
                } else {
                    0.0
                };
                net_amount = round2(discounted_amount - tax_amount);
                total_amount = discounted_amount;
            } else {
                net_amount = discounted_amount;
                tax_amount = if draft.item.tax_rate > 0.0 {
                    round2((net_amount * draft.item.tax_rate) / 100.0)
                } else {
                    0.0
                };
                total_amount = round2(net_amount + tax_amount);
            }

            ComputedSaleLine {
                item_id: Some(draft.item.item_id),
                item_name: draft.item.name,
                item_kind: draft.item.item_kind,
                category_name: draft.item.category_name,
                sku: draft.item.sku,
                primary_barcode: draft.item.primary_barcode,
                unit_code: draft.item.unit_code,
                tax_label: draft.item.tax_label,
                tax_rate: draft.item.tax_rate,
                prices_include_tax: draft.item.prices_include_tax,
                quantity: draft.quantity,
                unit_price: draft.unit_price,
                gross_amount: draft.gross_amount,
                discount_amount,
                net_amount,
                tax_amount,
                total_amount,
                notes: draft.notes,
                track_stock: draft.item.track_stock,
                on_hand_quantity: draft.item.on_hand_quantity,
                cost_price: draft.cost_price,
            }
        })
        .collect::<Vec<_>>();

    Ok(ComputedSale {
        subtotal_amount: round2(lines.iter().map(|line| line.gross_amount).sum()),
        discount_amount: round2(lines.iter().map(|line| line.discount_amount).sum()),
        tax_amount: round2(lines.iter().map(|line| line.tax_amount).sum()),
        total_amount: round2(lines.iter().map(|line| line.total_amount).sum()),
        lines,
    })
}

fn get_sale_record(conn: &Connection, sale_id: &str) -> Result<PosSaleRecord, String> {
    conn.query_row(
        "SELECT id, business_id, register_session_id, sale_number, sale_status, payment_status, currency_code,
                subtotal_amount, discount_amount, tax_amount, total_amount, amount_paid, balance_due,
                item_count, notes, completed_at, created_at, updated_at
         FROM sales
         WHERE id = ?1
         LIMIT 1",
        params![sale_id],
        sale_record_from_row,
    )
    .map_err(|error| to_command_error("failed to load sale", error))
}

fn list_sale_lines_for_sale(conn: &Connection, sale_id: &str) -> Result<Vec<PosSaleLine>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, sale_id, item_id, item_name, item_kind, category_name, sku, primary_barcode,
                    unit_code, tax_label, tax_rate, prices_include_tax, quantity, unit_price,
                    gross_amount, discount_amount, net_amount, tax_amount, total_amount, notes
             FROM sale_lines
             WHERE sale_id = ?1
             ORDER BY created_at ASC, id ASC",
        )
        .map_err(|error| to_command_error("failed to prepare sale line query", error))?;

    let rows = stmt
        .query_map(params![sale_id], sale_line_from_row)
        .map_err(|error| to_command_error("failed to query sale lines", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map sale lines", error))
}

fn list_sale_payments_for_sale(
    conn: &Connection,
    sale_id: &str,
) -> Result<Vec<PosSalePayment>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, sale_id, payment_mode, amount, reference_value, notes, created_at
             FROM sale_payments
             WHERE sale_id = ?1
             ORDER BY created_at ASC, id ASC",
        )
        .map_err(|error| to_command_error("failed to prepare sale payment query", error))?;

    let rows = stmt
        .query_map(params![sale_id], sale_payment_from_row)
        .map_err(|error| to_command_error("failed to query sale payments", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map sale payments", error))
}

fn list_recent_sales(
    conn: &Connection,
    business_id: &str,
    limit: usize,
) -> Result<Vec<PosSaleRecord>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, register_session_id, sale_number, sale_status, payment_status, currency_code,
                    subtotal_amount, discount_amount, tax_amount, total_amount, amount_paid, balance_due,
                    item_count, notes, completed_at, created_at, updated_at
             FROM sales
             WHERE business_id = ?1
             ORDER BY completed_at DESC, created_at DESC
             LIMIT ?2",
        )
        .map_err(|error| to_command_error("failed to prepare recent sale query", error))?;

    let rows = stmt
        .query_map(params![business_id, limit as i64], sale_record_from_row)
        .map_err(|error| to_command_error("failed to query recent sales", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map recent sales", error))
}

fn get_hold_summary(
    conn: &Connection,
    business_id: &str,
    hold_id: &str,
) -> Result<PosHoldSummary, String> {
    conn.query_row(
        "SELECT id, business_id, hold_code, hold_label, item_count, subtotal_amount, discount_amount,
                tax_amount, total_amount, cart_json, notes, cart_discount_amount, created_at, updated_at
         FROM sale_holds
         WHERE business_id = ?1 AND id = ?2
         LIMIT 1",
        params![business_id, hold_id],
        hold_summary_from_row,
    )
    .map_err(|error| to_command_error("failed to load held sale", error))
}

fn list_held_sales(conn: &Connection, business_id: &str) -> Result<Vec<PosHoldSummary>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, hold_code, hold_label, item_count, subtotal_amount, discount_amount,
                    tax_amount, total_amount, cart_json, notes, cart_discount_amount, created_at, updated_at
             FROM sale_holds
             WHERE business_id = ?1
             ORDER BY updated_at DESC, created_at DESC",
        )
        .map_err(|error| to_command_error("failed to prepare held sale query", error))?;

    let rows = stmt
        .query_map(params![business_id], hold_summary_from_row)
        .map_err(|error| to_command_error("failed to query held sales", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map held sales", error))
}

fn next_sequence_value(
    conn: &Connection,
    business_id: &str,
    counter_key: &str,
    default_prefix: &str,
    default_padding: i64,
) -> Result<String, String> {
    let now = db::now_iso();

    conn.execute(
        "INSERT OR IGNORE INTO sequence_counters (
            business_id, counter_key, prefix, next_number, padding, reset_policy, updated_at
         ) VALUES (?1, ?2, ?3, 1, ?4, 'none', ?5)",
        params![business_id, counter_key, default_prefix, default_padding.max(1), &now],
    )
    .map_err(|error| to_command_error("failed to seed sequence counter", error))?;

    let (prefix, next_number, padding): (String, i64, i64) = conn
        .query_row(
            "SELECT prefix, next_number, padding
             FROM sequence_counters
             WHERE business_id = ?1 AND counter_key = ?2
             LIMIT 1",
            params![business_id, counter_key],
            |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)),
        )
        .map_err(|error| to_command_error("failed to read sequence counter", error))?;

    conn.execute(
        "UPDATE sequence_counters
         SET next_number = ?3, updated_at = ?4
         WHERE business_id = ?1 AND counter_key = ?2",
        params![business_id, counter_key, next_number.max(1) + 1, &now],
    )
    .map_err(|error| to_command_error("failed to increment sequence counter", error))?;

    let width = padding.max(1) as usize;
    Ok(format!("{}{number:0width$}", prefix, number = next_number.max(1), width = width))
}

pub fn ensure_pos_support_for_business(conn: &Connection, business_id: &str) -> Result<(), String> {
    let now = db::now_iso();

    conn.execute(
        "INSERT OR IGNORE INTO sequence_counters (
            business_id, counter_key, prefix, next_number, padding, reset_policy, updated_at
         ) VALUES (?1, 'sale', 'SAL-', 1, 5, 'none', ?2)",
        params![business_id, &now],
    )
    .map_err(|error| to_command_error("failed to ensure sale sequence", error))?;

    conn.execute(
        "INSERT OR IGNORE INTO sequence_counters (
            business_id, counter_key, prefix, next_number, padding, reset_policy, updated_at
         ) VALUES (?1, 'hold', 'HOLD-', 1, 5, 'none', ?2)",
        params![business_id, &now],
    )
    .map_err(|error| to_command_error("failed to ensure hold sequence", error))?;

    conn.execute(
        "INSERT OR IGNORE INTO register_sessions (
            id, business_id, label, status, opened_at, closed_at, created_at, updated_at
         ) VALUES (?1, ?2, ?3, 'open', ?4, NULL, ?5, ?6)",
        params![
            format!("register-main:{business_id}"),
            business_id,
            "Main register",
            &now,
            &now,
            &now,
        ],
    )
    .map_err(|error| to_command_error("failed to ensure main register", error))?;

    Ok(())
}

pub fn ensure_pos_support_foundation(conn: &Connection) -> Result<(), String> {
    let mut stmt = conn
        .prepare("SELECT id FROM businesses ORDER BY created_at ASC")
        .map_err(|error| to_command_error("failed to prepare business list", error))?;

    let rows = stmt
        .query_map([], |row| row.get::<_, String>(0))
        .map_err(|error| to_command_error("failed to query businesses", error))?;

    for business_id in rows {
        ensure_pos_support_for_business(conn, &business_id.map_err(|error| {
            to_command_error("failed to map business id for pos support", error)
        })?)?;
    }

    Ok(())
}

pub fn build_pos_summary(conn: &Connection, business_id: &str) -> Result<PosSummary, String> {
    ensure_pos_support_for_business(conn, business_id)?;
    let today = Utc::now().format("%Y-%m-%d").to_string();

    let completed_sale_count: usize = conn
        .query_row(
            "SELECT COUNT(*) FROM sales WHERE business_id = ?1 AND sale_status = 'completed'",
            params![business_id],
            |row| row.get::<_, i64>(0),
        )
        .map_err(|error| to_command_error("failed to count completed sales", error))?
        as usize;

    let (today_sale_count, today_gross_sales, today_collected_amount, today_due_amount): (
        usize,
        f64,
        f64,
        f64,
    ) = conn
        .query_row(
            "SELECT
                COUNT(*),
                COALESCE(SUM(total_amount), 0),
                COALESCE(SUM(amount_paid), 0),
                COALESCE(SUM(balance_due), 0)
             FROM sales
             WHERE business_id = ?1
               AND sale_status = 'completed'
               AND substr(completed_at, 1, 10) = ?2",
            params![business_id, today],
            |row| {
                Ok((
                    row.get::<_, i64>(0)? as usize,
                    row.get(1)?,
                    row.get(2)?,
                    row.get(3)?,
                ))
            },
        )
        .map_err(|error| to_command_error("failed to summarize today's sales", error))?;

    let held_sale_count: usize = conn
        .query_row(
            "SELECT COUNT(*) FROM sale_holds WHERE business_id = ?1",
            params![business_id],
            |row| row.get::<_, i64>(0),
        )
        .map_err(|error| to_command_error("failed to count held sales", error))?
        as usize;

    let average_sale_value = if completed_sale_count > 0 {
        let total: f64 = conn
            .query_row(
                "SELECT COALESCE(SUM(total_amount), 0)
                 FROM sales
                 WHERE business_id = ?1 AND sale_status = 'completed'",
                params![business_id],
                |row| row.get(0),
            )
            .map_err(|error| to_command_error("failed to total sales", error))?;
        round2(total / completed_sale_count as f64)
    } else {
        0.0
    };

    Ok(PosSummary {
        completed_sale_count,
        today_sale_count,
        held_sale_count,
        today_gross_sales: round2(today_gross_sales),
        today_collected_amount: round2(today_collected_amount),
        today_due_amount: round2(today_due_amount),
        average_sale_value,
    })
}

pub fn load_pos_workspace(conn: &Connection, business_id: &str) -> Result<PosWorkspace, String> {
    let register = get_primary_register(conn, business_id)?;
    Ok(PosWorkspace {
        business_id: business_id.to_string(),
        summary: build_pos_summary(conn, business_id)?,
        register_label: Some(register.label),
        sellable_items: list_sellable_items(conn, business_id)?,
        held_sales: list_held_sales(conn, business_id)?,
        recent_sales: list_recent_sales(conn, business_id, 20)?,
    })
}

pub fn save_pos_hold(
    conn: &Connection,
    business_id: &str,
    input: &SavePosHoldInput,
) -> Result<PosHoldSummary, String> {
    ensure_pos_support_for_business(conn, business_id)?;
    let hold_label = normalize_text(&input.hold_label, "hold label")?;
    let notes = normalize_optional(&input.notes);
    let calculation = build_sale_calculation(
        conn,
        business_id,
        &input.cart_lines,
        input.cart_discount_amount,
    )?;

    if calculation.lines.is_empty() {
        return Err("at least one cart line is required".into());
    }

    let now = db::now_iso();
    let cart_json = to_string(&input.cart_lines)
        .map_err(|error| to_command_error("failed to serialize held cart", error))?;

    let (hold_id, hold_code, created_at) = if let Some(existing_id) = input.id.clone() {
        let existing: Option<(String, String)> = conn
            .query_row(
                "SELECT hold_code, created_at FROM sale_holds WHERE business_id = ?1 AND id = ?2 LIMIT 1",
                params![business_id, &existing_id],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .optional()
            .map_err(|error| to_command_error("failed to load existing hold", error))?;

        let Some((existing_code, existing_created_at)) = existing else {
            return Err("held cart was not found for this business".into());
        };
        (existing_id, existing_code, existing_created_at)
    } else {
        (
            Uuid::new_v4().to_string(),
            next_sequence_value(conn, business_id, "hold", "HOLD-", 5)?,
            now.clone(),
        )
    };

    conn.execute(
        "INSERT INTO sale_holds (
            id, business_id, hold_code, hold_label, item_count, subtotal_amount, discount_amount,
            tax_amount, total_amount, notes, cart_json, cart_discount_amount, created_at, updated_at
         ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14)
         ON CONFLICT(id) DO UPDATE SET
            hold_label = excluded.hold_label,
            item_count = excluded.item_count,
            subtotal_amount = excluded.subtotal_amount,
            discount_amount = excluded.discount_amount,
            tax_amount = excluded.tax_amount,
            total_amount = excluded.total_amount,
            notes = excluded.notes,
            cart_json = excluded.cart_json,
            cart_discount_amount = excluded.cart_discount_amount,
            updated_at = excluded.updated_at",
        params![
            &hold_id,
            business_id,
            &hold_code,
            hold_label,
            calculation.lines.len() as i64,
            calculation.subtotal_amount,
            calculation.discount_amount,
            calculation.tax_amount,
            calculation.total_amount,
            notes,
            cart_json,
            round2(input.cart_discount_amount.max(0.0)),
            created_at,
            &now,
        ],
    )
    .map_err(|error| to_command_error("failed to save held cart", error))?;

    db::insert_log(conn, "INFO", "pos", "Held cart saved", None)?;
    get_hold_summary(conn, business_id, &hold_id)
}

pub fn delete_pos_hold(conn: &Connection, business_id: &str, hold_id: &str) -> Result<(), String> {
    let deleted = conn
        .execute(
            "DELETE FROM sale_holds WHERE business_id = ?1 AND id = ?2",
            params![business_id, hold_id],
        )
        .map_err(|error| to_command_error("failed to delete held cart", error))?;

    if deleted == 0 {
        return Err("held cart was not found for this business".into());
    }

    db::insert_log(conn, "INFO", "pos", "Held cart removed", None)?;
    Ok(())
}

pub fn complete_pos_sale(
    conn: &Connection,
    business: &BusinessProfile,
    input: &CompletePosSaleInput,
) -> Result<PosSaleDetail, String> {
    let business_id = &business.id;
    ensure_pos_support_for_business(conn, business_id)?;
    let register = get_primary_register(conn, business_id)?;
    let calculation = build_sale_calculation(
        conn,
        business_id,
        &input.cart_lines,
        input.cart_discount_amount,
    )?;

    if calculation.lines.is_empty() {
        return Err("at least one cart line is required".into());
    }

    for line in &calculation.lines {
        if line.track_stock && line.quantity - line.on_hand_quantity > EPSILON {
            return Err(format!(
                "{} has insufficient stock for this sale",
                line.item_name
            ));
        }
    }

    let payments = input
        .payments
        .iter()
        .filter_map(|payment| {
            let amount = if payment.amount.is_finite() {
                payment.amount.max(0.0)
            } else {
                0.0
            };
            if amount <= 0.0 {
                None
            } else {
                Some(PosPaymentEntryInput {
                    payment_mode: normalize_payment_mode(&payment.payment_mode),
                    amount: round2(amount),
                    reference_value: normalize_optional(&payment.reference_value),
                    notes: normalize_optional(&payment.notes),
                })
            }
        })
        .collect::<Vec<_>>();

    let amount_paid = round2(payments.iter().map(|payment| payment.amount).sum());
    if amount_paid - calculation.total_amount > EPSILON {
        return Err("payment amount cannot exceed sale total in this patch".into());
    }

    let balance_due = round2((calculation.total_amount - amount_paid).max(0.0));
    let payment_status = if amount_paid <= EPSILON {
        "unpaid"
    } else if balance_due <= EPSILON {
        "paid"
    } else {
        "partial"
    };

    let sale_id = Uuid::new_v4().to_string();
    let sale_number = next_sequence_value(conn, business_id, "sale", "SAL-", 5)?;
    let now = db::now_iso();
    let notes = normalize_optional(&input.notes);

    conn.execute(
        "INSERT INTO sales (
            id, business_id, register_session_id, sale_number, sale_status, payment_status,
            currency_code, subtotal_amount, discount_amount, tax_amount, total_amount,
            amount_paid, balance_due, item_count, notes, completed_at, created_at, updated_at
         ) VALUES (
            ?1, ?2, ?3, ?4, 'completed', ?5,
            ?6, ?7, ?8, ?9, ?10,
            ?11, ?12, ?13, ?14, ?15, ?16, ?17
         )",
        params![
            &sale_id,
            business_id,
            &register.session.id,
            &sale_number,
            payment_status,
            &business.currency_code,
            calculation.subtotal_amount,
            calculation.discount_amount,
            calculation.tax_amount,
            calculation.total_amount,
            amount_paid,
            balance_due,
            calculation.lines.len() as i64,
            notes,
            &now,
            &now,
            &now,
        ],
    )
    .map_err(|error| to_command_error("failed to create sale", error))?;

    for line in &calculation.lines {
        let line_id = Uuid::new_v4().to_string();
        conn.execute(
            "INSERT INTO sale_lines (
                id, sale_id, business_id, item_id, item_name, item_kind, category_name, sku,
                primary_barcode, unit_code, tax_label, tax_rate, prices_include_tax, quantity,
                unit_price, gross_amount, discount_amount, net_amount, tax_amount, total_amount,
                notes, created_at
             ) VALUES (
                ?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8,
                ?9, ?10, ?11, ?12, ?13, ?14,
                ?15, ?16, ?17, ?18, ?19, ?20,
                ?21, ?22
             )",
            params![
                &line_id,
                &sale_id,
                business_id,
                &line.item_id,
                &line.item_name,
                &line.item_kind,
                &line.category_name,
                &line.sku,
                &line.primary_barcode,
                &line.unit_code,
                &line.tax_label,
                line.tax_rate,
                bool_to_i64(line.prices_include_tax),
                line.quantity,
                line.unit_price,
                line.gross_amount,
                line.discount_amount,
                line.net_amount,
                line.tax_amount,
                line.total_amount,
                &line.notes,
                &now,
            ],
        )
        .map_err(|error| to_command_error("failed to create sale line", error))?;

        if line.track_stock {
            let quantity_after = canonical_zero(line.on_hand_quantity - line.quantity);
            if quantity_after < -EPSILON {
                return Err(format!(
                    "{} would fall below zero stock",
                    line.item_name
                ));
            }

            if let Some(item_id) = &line.item_id {
                conn.execute(
                    "UPDATE catalog_items
                     SET stock_quantity = ?3, updated_at = ?4
                     WHERE business_id = ?1 AND id = ?2",
                    params![business_id, item_id, quantity_after.max(0.0), &now],
                )
                .map_err(|error| to_command_error("failed to update stock after sale", error))?;

                conn.execute(
                    "INSERT INTO inventory_stock_movements (
                        id, business_id, item_id, movement_type, quantity_delta, quantity_after,
                        unit_cost, note, occurred_at, created_at
                     ) VALUES (?1, ?2, ?3, 'pos_sale', ?4, ?5, ?6, ?7, ?8, ?9)",
                    params![
                        Uuid::new_v4().to_string(),
                        business_id,
                        item_id,
                        -line.quantity,
                        quantity_after.max(0.0),
                        if line.cost_price > 0.0 {
                            Some(line.cost_price)
                        } else {
                            None
                        },
                        format!("POS sale {sale_number}"),
                        &now,
                        &now,
                    ],
                )
                .map_err(|error| to_command_error("failed to record inventory deduction", error))?;
            }
        }
    }

    for payment in payments {
        conn.execute(
            "INSERT INTO sale_payments (
                id, sale_id, business_id, payment_mode, amount, reference_value, notes, created_at
             ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
            params![
                Uuid::new_v4().to_string(),
                &sale_id,
                business_id,
                payment.payment_mode,
                payment.amount,
                payment.reference_value,
                payment.notes,
                &now,
            ],
        )
        .map_err(|error| to_command_error("failed to create sale payment", error))?;
    }

    if let Some(hold_id) = input.hold_id.as_ref() {
        conn.execute(
            "DELETE FROM sale_holds WHERE business_id = ?1 AND id = ?2",
            params![business_id, hold_id],
        )
        .map_err(|error| to_command_error("failed to clear held cart", error))?;
    }

    db::insert_log(conn, "INFO", "pos", "POS sale completed", None)?;

    Ok(PosSaleDetail {
        sale: get_sale_record(conn, &sale_id)?,
        lines: list_sale_lines_for_sale(conn, &sale_id)?,
        payments: list_sale_payments_for_sale(conn, &sale_id)?,
    })
}

pub fn seed_demo_pos_for_business(conn: &Connection, business_id: &str) -> Result<(), String> {
    ensure_pos_support_for_business(conn, business_id)?;

    let sale_count: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM sales WHERE business_id = ?1",
            params![business_id],
            |row| row.get(0),
        )
        .map_err(|error| to_command_error("failed to count demo sales", error))?;

    let hold_count: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM sale_holds WHERE business_id = ?1",
            params![business_id],
            |row| row.get(0),
        )
        .map_err(|error| to_command_error("failed to count demo held carts", error))?;

    let items = list_sellable_items(conn, business_id)?;
    let Some(first_item) = items.first() else {
        return Ok(());
    };
    let sale_item = items
        .iter()
        .find(|item| !item.track_stock || item.on_hand_quantity >= 1.0)
        .unwrap_or(first_item);

    if hold_count == 0 {
        let hold_input = SavePosHoldInput {
            id: None,
            hold_label: "Demo held cart".into(),
            notes: Some("Seeded held cart for checkout testing".into()),
            cart_lines: vec![PosCartLineInput {
                item_id: sale_item.item_id.clone(),
                quantity: 1.0,
                unit_price: Some(sale_item.selling_price),
                discount_amount: 0.0,
                notes: None,
            }],
            cart_discount_amount: 0.0,
        };
        let _ = save_pos_hold(conn, business_id, &hold_input)?;
    }

    if sale_count == 0 {
        let demo_business = BusinessProfile {
            id: business_id.to_string(),
            name: "Demo".into(),
            legal_name: None,
            code: "DEMO".into(),
            business_type: "Demo".into(),
            currency_code: conn
                .query_row(
                    "SELECT currency_code FROM businesses WHERE id = ?1 LIMIT 1",
                    params![business_id],
                    |row| row.get(0),
                )
                .map_err(|error| to_command_error("failed to load demo business currency", error))?,
            tax_mode: "exclusive".into(),
            phone: None,
            email: None,
            address_line1: None,
            address_line2: None,
            city: None,
            state: None,
            postal_code: None,
            country: None,
            created_at: db::now_iso(),
            updated_at: db::now_iso(),
            archived_at: None,
        };

        let sale_input = CompletePosSaleInput {
            hold_id: None,
            notes: Some("Seeded demo sale".into()),
            cart_lines: vec![PosCartLineInput {
                item_id: sale_item.item_id.clone(),
                quantity: 1.0,
                unit_price: Some(sale_item.selling_price),
                discount_amount: 0.0,
                notes: None,
            }],
            cart_discount_amount: 0.0,
            payments: vec![PosPaymentEntryInput {
                payment_mode: "cash".into(),
                amount: sale_item.selling_price,
                reference_value: None,
                notes: Some("Seeded payment".into()),
            }],
        };
        let _ = complete_pos_sale(conn, &demo_business, &sale_input)?;
    }

    Ok(())
}

pub fn list_all_register_sessions(conn: &Connection) -> Result<Vec<RegisterSession>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, label, status, opened_at, closed_at, created_at, updated_at
             FROM register_sessions
             ORDER BY created_at ASC",
        )
        .map_err(|error| to_command_error("failed to prepare all register query", error))?;

    let rows = stmt
        .query_map([], register_session_from_row)
        .map_err(|error| to_command_error("failed to query all registers", error))?;

    rows.map(|row| row.map(|record| record.session))
        .collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map all registers", error))
}

pub fn list_all_sales(conn: &Connection) -> Result<Vec<PosSaleRecord>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, register_session_id, sale_number, sale_status, payment_status, currency_code,
                    subtotal_amount, discount_amount, tax_amount, total_amount, amount_paid, balance_due,
                    item_count, notes, completed_at, created_at, updated_at
             FROM sales
             ORDER BY completed_at DESC, created_at DESC",
        )
        .map_err(|error| to_command_error("failed to prepare all sales query", error))?;

    let rows = stmt
        .query_map([], sale_record_from_row)
        .map_err(|error| to_command_error("failed to query all sales", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map all sales", error))
}

pub fn list_all_sale_lines(conn: &Connection) -> Result<Vec<PosSaleLine>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, sale_id, item_id, item_name, item_kind, category_name, sku, primary_barcode,
                    unit_code, tax_label, tax_rate, prices_include_tax, quantity, unit_price,
                    gross_amount, discount_amount, net_amount, tax_amount, total_amount, notes
             FROM sale_lines
             ORDER BY created_at ASC, id ASC",
        )
        .map_err(|error| to_command_error("failed to prepare all sale lines query", error))?;

    let rows = stmt
        .query_map([], sale_line_from_row)
        .map_err(|error| to_command_error("failed to query all sale lines", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map all sale lines", error))
}

pub fn list_all_sale_payments(conn: &Connection) -> Result<Vec<PosSalePayment>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, sale_id, payment_mode, amount, reference_value, notes, created_at
             FROM sale_payments
             ORDER BY created_at ASC, id ASC",
        )
        .map_err(|error| to_command_error("failed to prepare all sale payments query", error))?;

    let rows = stmt
        .query_map([], sale_payment_from_row)
        .map_err(|error| to_command_error("failed to query all sale payments", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map all sale payments", error))
}

pub fn list_all_sale_holds(conn: &Connection) -> Result<Vec<PosHoldSummary>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT id, business_id, hold_code, hold_label, item_count, subtotal_amount, discount_amount,
                    tax_amount, total_amount, cart_json, notes, cart_discount_amount, created_at, updated_at
             FROM sale_holds
             ORDER BY updated_at DESC, created_at DESC",
        )
        .map_err(|error| to_command_error("failed to prepare all held carts query", error))?;

    let rows = stmt
        .query_map([], hold_summary_from_row)
        .map_err(|error| to_command_error("failed to query all held carts", error))?;

    rows.collect::<rusqlite::Result<Vec<_>>>()
        .map_err(|error| to_command_error("failed to map all held carts", error))
}

```

## files/src-tauri/src/core/seed.rs

```rust
use chrono::Utc;
use rusqlite::{params, Connection};
use uuid::Uuid;

use super::{catalog, pos};

fn upsert_meta(conn: &Connection, key: &str, value: &str) -> rusqlite::Result<()> {
    conn.execute(
        "INSERT INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
        params![key, value, Utc::now().to_rfc3339()],
    )?;
    Ok(())
}

fn insert_meta_if_missing(conn: &Connection, key: &str, value: &str) -> rusqlite::Result<()> {
    conn.execute(
        "INSERT OR IGNORE INTO app_meta (key, value, updated_at)
         VALUES (?1, ?2, ?3)",
        params![key, value, Utc::now().to_rfc3339()],
    )?;
    Ok(())
}

fn bool_to_i64(value: bool) -> i64 {
    if value {
        1
    } else {
        0
    }
}

pub fn ensure_workspace_support_for_business(
    conn: &Connection,
    business_id: &str,
) -> rusqlite::Result<()> {
    let (
        tax_label,
        default_tax_rate,
        prices_include_tax,
        receipt_footer,
        receipt_show_address,
        receipt_show_phone,
        module_restaurant_enabled,
        module_retail_enabled,
        module_inventory_enabled,
        module_services_enabled,
    ) = conn.query_row(
        "SELECT
            tax_label,
            default_tax_rate,
            prices_include_tax,
            receipt_footer,
            receipt_show_address,
            receipt_show_phone,
            module_restaurant_enabled,
            module_retail_enabled,
            module_inventory_enabled,
            module_services_enabled
         FROM business_settings
         WHERE business_id = ?1
         LIMIT 1",
        params![business_id],
        |row| {
            Ok((
                row.get::<_, String>(0)?,
                row.get::<_, f64>(1)?,
                row.get::<_, i64>(2)? != 0,
                row.get::<_, Option<String>>(3)?,
                row.get::<_, i64>(4)? != 0,
                row.get::<_, i64>(5)? != 0,
                row.get::<_, i64>(6)? != 0,
                row.get::<_, i64>(7)? != 0,
                row.get::<_, i64>(8)? != 0,
                row.get::<_, i64>(9)? != 0,
            ))
        },
    )?;

    let now = Utc::now().to_rfc3339();

    let tax_count: i64 = conn.query_row(
        "SELECT COUNT(*) FROM tax_profiles WHERE business_id = ?1",
        params![business_id],
        |row| row.get(0),
    )?;
    if tax_count == 0 {
        conn.execute(
            "INSERT INTO tax_profiles (
                id, business_id, name, label, rate, prices_include_tax,
                is_default, created_at, updated_at
             ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, 1, ?7, ?8)",
            params![
                Uuid::new_v4().to_string(),
                business_id,
                "Standard tax",
                tax_label,
                default_tax_rate,
                bool_to_i64(prices_include_tax),
                &now,
                &now,
            ],
        )?;
    }

    let receipt_count: i64 = conn.query_row(
        "SELECT COUNT(*) FROM receipt_profiles WHERE business_id = ?1",
        params![business_id],
        |row| row.get(0),
    )?;
    if receipt_count == 0 {
        conn.execute(
            "INSERT INTO receipt_profiles (
                id, business_id, name, header_line1, header_line2, footer_text,
                show_address, show_phone, show_tax_breakdown, paper_width, copies,
                is_default, created_at, updated_at, show_email, show_business_code
             ) VALUES (
                ?1, ?2, ?3, NULL, NULL, ?4,
                ?5, ?6, 1, '80mm', 1,
                1, ?7, ?8, 0, 1
             )",
            params![
                Uuid::new_v4().to_string(),
                business_id,
                "Default receipt",
                receipt_footer,
                bool_to_i64(receipt_show_address),
                bool_to_i64(receipt_show_phone),
                &now,
                &now,
            ],
        )?;
    }

    for (module_key, enabled) in [
        ("restaurant", module_restaurant_enabled),
        ("retail", module_retail_enabled),
        ("inventory", module_inventory_enabled),
        ("services", module_services_enabled),
        ("customers", false),
        ("suppliers", false),
        ("expenses", false),
        ("reporting", false),
        ("data_center", true),
    ] {
        conn.execute(
            "INSERT OR IGNORE INTO module_flags (business_id, module_key, enabled, updated_at)
             VALUES (?1, ?2, ?3, ?4)",
            params![business_id, module_key, bool_to_i64(enabled), &now],
        )?;
    }

    for (counter_key, prefix, padding, reset_policy) in [
        ("sale", "SAL-", 5_i64, "none"),
        ("purchase", "PUR-", 5_i64, "none"),
        ("expense", "EXP-", 5_i64, "none"),
        ("customer", "CUS-", 4_i64, "none"),
        ("supplier", "SUP-", 4_i64, "none"),
    ] {
        conn.execute(
            "INSERT OR IGNORE INTO sequence_counters (
                business_id, counter_key, prefix, next_number, padding, reset_policy, updated_at
             ) VALUES (?1, ?2, ?3, 1, ?4, ?5, ?6)",
            params![
                business_id,
                counter_key,
                prefix,
                padding,
                reset_policy,
                &now
            ],
        )?;
    }

    Ok(())
}

fn ensure_workspace_support_foundation(conn: &Connection) -> rusqlite::Result<()> {
    let mut stmt = conn.prepare("SELECT id FROM businesses ORDER BY created_at ASC")?;
    let business_ids = stmt.query_map([], |row| row.get::<_, String>(0))?;

    for business_id in business_ids {
        ensure_workspace_support_for_business(conn, &business_id?)?;
    }

    Ok(())
}

fn seed_demo_catalog_foundation(conn: &Connection) -> rusqlite::Result<()> {
    let seeded_demo = conn
        .query_row(
            "SELECT value FROM app_meta WHERE key = 'seeded_demo_data' LIMIT 1",
            [],
            |row| row.get::<_, String>(0),
        )
        .unwrap_or_else(|_| "false".to_string());

    if seeded_demo != "true" {
        return Ok(());
    }

    let mut stmt = conn.prepare(
        "SELECT id
         FROM businesses
         WHERE code = 'DEMO-001' OR name LIKE 'Demo %'
         ORDER BY created_at ASC",
    )?;
    let business_ids = stmt.query_map([], |row| row.get::<_, String>(0))?;
    for business_id in business_ids {
        catalog::seed_demo_catalog_for_business(conn, &business_id?)?;
    }

    Ok(())
}

fn seed_demo_pos_foundation(conn: &Connection) -> rusqlite::Result<()> {
    let seeded_demo = conn
        .query_row(
            "SELECT value FROM app_meta WHERE key = 'seeded_demo_data' LIMIT 1",
            [],
            |row| row.get::<_, String>(0),
        )
        .unwrap_or_else(|_| "false".to_string());

    if seeded_demo != "true" {
        return Ok(());
    }

    let mut stmt = conn.prepare(
        "SELECT id
         FROM businesses
         WHERE code = 'DEMO-001' OR name LIKE 'Demo %'
         ORDER BY created_at ASC",
    )?;
    let business_ids = stmt.query_map([], |row| row.get::<_, String>(0))?;
    for business_id in business_ids {
        pos::seed_demo_pos_for_business(conn, &business_id?)?;
    }

    Ok(())
}

pub fn seed_if_empty(conn: &Connection) -> rusqlite::Result<()> {
    let business_count: i64 =
        conn.query_row("SELECT COUNT(*) FROM businesses", [], |row| row.get(0))?;

    upsert_meta(conn, "app_name", "local-first-business-manager")?;
    upsert_meta(conn, "product_name", "Local Business Manager")?;
    upsert_meta(conn, "app_version", "0.5.0")?;
    insert_meta_if_missing(conn, "initialized_at", &Utc::now().to_rfc3339())?;

    if business_count == 0 {
        let business_id = Uuid::new_v4().to_string();
        let now = Utc::now().to_rfc3339();

        conn.execute(
            "INSERT INTO businesses (
                id, name, legal_name, code, business_type, currency_code, tax_mode,
                phone, email, address_line1, address_line2, city, state, postal_code,
                country, created_at, updated_at, archived_at
             ) VALUES (
                ?1, ?2, ?3, ?4, ?5, ?6, ?7,
                ?8, ?9, ?10, ?11, ?12, ?13, ?14,
                ?15, ?16, ?17, ?18
             )",
            params![
                &business_id,
                "Demo Cafe & Retail",
                "Demo Cafe & Retail LLP",
                "DEMO-001",
                "Cafe",
                "INR",
                "exclusive",
                "+91-90000-00000",
                "demo@localbusiness.test",
                "12 Market Street",
                "Near Central Square",
                "Bengaluru",
                "Karnataka",
                "560001",
                "India",
                &now,
                &now,
                Option::<String>::None,
            ],
        )?;

        conn.execute(
            "INSERT INTO business_settings (
                business_id, timezone, locale, date_format, theme, tax_label,
                default_tax_rate, prices_include_tax, receipt_footer,
                receipt_show_address, receipt_show_phone, auto_backup_enabled,
                backup_directory, module_restaurant_enabled, module_retail_enabled,
                module_inventory_enabled, module_services_enabled, updated_at
            ) VALUES (
                ?1, ?2, ?3, ?4, ?5, ?6,
                ?7, ?8, ?9,
                ?10, ?11, ?12,
                ?13, ?14, ?15,
                ?16, ?17, ?18
            )",
            params![
                &business_id,
                "Asia/Kolkata",
                "en-IN",
                "DD-MM-YYYY",
                "system",
                "GST",
                5.0_f64,
                0_i64,
                "Thank you for supporting local business.",
                1_i64,
                1_i64,
                0_i64,
                Option::<String>::None,
                1_i64,
                1_i64,
                1_i64,
                0_i64,
                &now,
            ],
        )?;

        upsert_meta(conn, "active_business_id", &business_id)?;
        upsert_meta(conn, "seeded_demo_data", "true")?;

        for (level, category, message) in [
            ("INFO", "patching", "Patch 1 foundation registered"),
            (
                "INFO",
                "patching",
                "Patch 2 multi-business workspace registered",
            ),
            ("INFO", "patching", "Patch 3 catalog core registered"),
            ("INFO", "patching", "Patch 4 inventory ledger core registered"),
            ("INFO", "patching", "Patch 5 POS checkout core registered"),
            ("INFO", "business", "Demo business profile created"),
            ("INFO", "storage", "Local storage directories prepared"),
        ] {
            conn.execute(
                "INSERT INTO app_logs (id, level, category, message, payload_json, created_at)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
                params![
                    Uuid::new_v4().to_string(),
                    level,
                    category,
                    message,
                    Option::<String>::None,
                    Utc::now().to_rfc3339(),
                ],
            )?;
        }
    }

    ensure_workspace_support_foundation(conn)?;
    catalog::ensure_system_units(conn)?;
    pos::ensure_pos_support_foundation(conn)?;
    seed_demo_catalog_foundation(conn)?;
    seed_demo_pos_foundation(conn)?;
    Ok(())
}

```

## files/src-tauri/src/domain/bootstrap.rs

```rust
use super::models::{
    AppBootstrap, AppInfo, BackupRecord, BusinessProfile, BusinessSettings,
    BusinessWorkspaceSummary, CatalogSummary, DashboardShellData, InventorySummary, KpiCard,
    ModuleFlags, ModuleStatus, PatchRecord, PosSummary, ReceiptProfile, RecentActivity,
    SequenceCounter, StorageStatus, TaxProfile,
};

fn active_module_count(module_flags: &ModuleFlags) -> usize {
    [
        module_flags.restaurant_enabled,
        module_flags.retail_enabled,
        module_flags.inventory_enabled,
        module_flags.services_enabled,
        module_flags.customers_enabled,
        module_flags.suppliers_enabled,
        module_flags.expenses_enabled,
        module_flags.reporting_enabled,
        module_flags.data_center_enabled,
    ]
    .into_iter()
    .filter(|enabled| *enabled)
    .count()
}

pub fn compose_dashboard(
    business_workspaces: &[BusinessWorkspaceSummary],
    active_business: &BusinessProfile,
    active_modules: &ModuleFlags,
    active_sequences: &[SequenceCounter],
    backups: &[BackupRecord],
    recent_activity: Vec<RecentActivity>,
    patch_history: &[PatchRecord],
    storage: &StorageStatus,
    catalog_summary: &CatalogSummary,
    inventory_summary: &InventorySummary,
    pos_summary: &PosSummary,
) -> DashboardShellData {
    DashboardShellData {
        hero_title: "Local checkout foundation is ready".into(),
        hero_body: format!(
            "Patch 5 adds a real offline checkout workspace for {} with held carts, completed sales, partial payments, receipt-ready sale history, and stock deduction wired into the local inventory ledger.",
            active_business.name
        ),
        kpis: vec![
            KpiCard {
                id: "workspace-count".into(),
                label: "Business workspaces".into(),
                value: business_workspaces.len().to_string(),
                note: "Each business keeps isolated profiles, settings, sequences, and local data boundaries.".into(),
            },
            KpiCard {
                id: "today-sales".into(),
                label: "Sales today".into(),
                value: pos_summary.today_sale_count.to_string(),
                note: format!(
                    "{} held carts are waiting in the local POS workspace.",
                    pos_summary.held_sale_count
                ),
            },
            KpiCard {
                id: "today-gross".into(),
                label: "Gross today".into(),
                value: format!("{:.2}", pos_summary.today_gross_sales),
                note: "Gross sales totals, collected amounts, and due balances stay inside the local database.".into(),
            },
            KpiCard {
                id: "catalog-items".into(),
                label: "Catalog items".into(),
                value: catalog_summary.active_items.to_string(),
                note: format!(
                    "{} categories and {} active stock items are available to the checkout flow.",
                    catalog_summary.category_count, catalog_summary.stock_item_count
                ),
            },
            KpiCard {
                id: "tracked-stock".into(),
                label: "Tracked stock items".into(),
                value: inventory_summary.total_tracked_items.to_string(),
                note: format!(
                    "{} low-stock items remain visible while POS sales consume inventory locally.",
                    inventory_summary.low_stock_items
                ),
            },
            KpiCard {
                id: "movement-count".into(),
                label: "Inventory movements".into(),
                value: inventory_summary.movement_count.to_string(),
                note: "Manual adjustments, opening balances, catalog syncs, and POS deductions share one local movement history.".into(),
            },
            KpiCard {
                id: "module-count".into(),
                label: "Active modules".into(),
                value: active_module_count(active_modules).to_string(),
                note: "Workspace, catalog, inventory, POS, and data-center foundations are all now active locally.".into(),
            },
            KpiCard {
                id: "backup-count".into(),
                label: "Local backups".into(),
                value: backups.len().to_string(),
                note: format!(
                    "{} export bundles have been recorded in {}.",
                    storage.export_count, storage.export_dir
                ),
            },
            KpiCard {
                id: "sequence-count".into(),
                label: "Sequence counters".into(),
                value: active_sequences.len().to_string(),
                note: "Sale numbering now drives real checkout records while future purchasing and returns can reuse the same foundation.".into(),
            },
            KpiCard {
                id: "patch-count".into(),
                label: "Applied patches".into(),
                value: patch_history.len().to_string(),
                note: "Patch history remains inside the local database for upgrade traceability and rollback planning.".into(),
            },
        ],
        recent_activity,
        module_statuses: vec![
            ModuleStatus {
                id: "workspace".into(),
                label: "Workspace core".into(),
                status: "active-foundation".into(),
                note: "Multi-business profiles, settings, tax defaults, receipts, and sequence counters remain active.".into(),
            },
            ModuleStatus {
                id: "catalog".into(),
                label: "Catalog".into(),
                status: "active-foundation".into(),
                note: "Products, menu items, services, categories, units, and barcodes are available locally.".into(),
            },
            ModuleStatus {
                id: "inventory".into(),
                label: "Inventory ledger".into(),
                status: "active-foundation".into(),
                note: "Stock movements, on-hand balances, reorder alerts, and POS stock deductions are all tracked locally per business.".into(),
            },
            ModuleStatus {
                id: "pos".into(),
                label: "POS / billing".into(),
                status: "active-foundation".into(),
                note: "Cart building, held carts, sale completion, payment capture, receipt rendering, and recent sale history are now available offline.".into(),
            },
            ModuleStatus {
                id: "customers".into(),
                label: "Customers".into(),
                status: "coming-next".into(),
                note: "The next patch can add customer profiles, sale linking, and repeat-buyer support on top of the new checkout layer.".into(),
            },
        ],
    }
}

#[allow(clippy::too_many_arguments)]
pub fn build_app_bootstrap(
    app_info: AppInfo,
    active_business: BusinessProfile,
    business_settings: BusinessSettings,
    active_tax_profile: TaxProfile,
    active_receipt_profile: ReceiptProfile,
    active_module_flags: ModuleFlags,
    active_sequences: Vec<SequenceCounter>,
    businesses: Vec<BusinessProfile>,
    business_workspaces: Vec<BusinessWorkspaceSummary>,
    patch_history: Vec<PatchRecord>,
    backups: Vec<BackupRecord>,
    storage: StorageStatus,
    recent_activity: Vec<RecentActivity>,
    catalog_summary: CatalogSummary,
    inventory_summary: InventorySummary,
    pos_summary: PosSummary,
) -> AppBootstrap {
    let dashboard = compose_dashboard(
        &business_workspaces,
        &active_business,
        &active_module_flags,
        &active_sequences,
        &backups,
        recent_activity,
        &patch_history,
        &storage,
        &catalog_summary,
        &inventory_summary,
        &pos_summary,
    );

    AppBootstrap {
        app_info,
        active_business,
        business_settings,
        active_tax_profile,
        active_receipt_profile,
        active_module_flags,
        active_sequences,
        businesses,
        business_workspaces,
        patch_history,
        backups,
        storage,
        catalog_summary,
        inventory_summary,
        pos_summary,
        dashboard,
    }
}

```

## files/src-tauri/src/domain/models.rs

```rust
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BusinessProfile {
    pub id: String,
    pub name: String,
    pub legal_name: Option<String>,
    pub code: String,
    pub business_type: String,
    pub currency_code: String,
    pub tax_mode: String,
    pub phone: Option<String>,
    pub email: Option<String>,
    pub address_line1: Option<String>,
    pub address_line2: Option<String>,
    pub city: Option<String>,
    pub state: Option<String>,
    pub postal_code: Option<String>,
    pub country: Option<String>,
    pub created_at: String,
    pub updated_at: String,
    pub archived_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BusinessSettings {
    pub business_id: String,
    pub timezone: String,
    pub locale: String,
    pub date_format: String,
    pub theme: String,
    pub tax_label: String,
    pub default_tax_rate: f64,
    pub prices_include_tax: bool,
    pub receipt_footer: Option<String>,
    pub receipt_show_address: bool,
    pub receipt_show_phone: bool,
    pub auto_backup_enabled: bool,
    pub backup_directory: Option<String>,
    pub module_restaurant_enabled: bool,
    pub module_retail_enabled: bool,
    pub module_inventory_enabled: bool,
    pub module_services_enabled: bool,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TaxProfile {
    pub id: String,
    pub business_id: String,
    pub name: String,
    pub tax_label: String,
    pub default_rate: f64,
    pub prices_include_tax: bool,
    pub is_default: bool,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ReceiptProfile {
    pub id: String,
    pub business_id: String,
    pub name: String,
    pub footer_text: Option<String>,
    pub show_address: bool,
    pub show_phone: bool,
    pub show_email: bool,
    pub show_business_code: bool,
    pub paper_width: String,
    pub is_default: bool,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ModuleFlags {
    pub business_id: String,
    pub restaurant_enabled: bool,
    pub retail_enabled: bool,
    pub inventory_enabled: bool,
    pub services_enabled: bool,
    pub customers_enabled: bool,
    pub suppliers_enabled: bool,
    pub expenses_enabled: bool,
    pub reporting_enabled: bool,
    pub data_center_enabled: bool,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SequenceCounter {
    pub id: String,
    pub business_id: String,
    pub scope: String,
    pub prefix: String,
    pub next_number: i64,
    pub padding: i64,
    pub reset_policy: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NewBusinessWorkspaceInput {
    pub name: String,
    pub legal_name: Option<String>,
    pub code: String,
    pub business_type: String,
    pub currency_code: String,
    pub tax_mode: String,
    pub timezone: String,
    pub locale: String,
    pub activate_now: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WorkspaceConfigurationInput {
    pub business_settings: BusinessSettings,
    pub tax_profile: TaxProfile,
    pub receipt_profile: ReceiptProfile,
    pub module_flags: ModuleFlags,
    pub sequence_counters: Vec<SequenceCounter>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BusinessWorkspaceSummary {
    pub business_id: String,
    pub name: String,
    pub code: String,
    pub business_type: String,
    pub currency_code: String,
    pub theme: String,
    pub timezone: String,
    pub tax_label: String,
    pub default_tax_rate: f64,
    pub next_sale_sequence: String,
    pub active_modules: Vec<String>,
    pub archived_at: Option<String>,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AppInfo {
    pub app_name: String,
    pub product_name: String,
    pub version: String,
    pub schema_version: i64,
    pub patch_level: String,
    pub initialized_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PatchRecord {
    pub patch_id: String,
    pub patch_name: String,
    pub schema_version: i64,
    pub applied_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BackupRecord {
    pub id: String,
    pub business_id: Option<String>,
    pub file_name: String,
    pub file_path: String,
    pub checksum: Option<String>,
    pub status: String,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ExportJobRecord {
    pub id: String,
    pub business_id: Option<String>,
    pub format: String,
    pub status: String,
    pub target_path: Option<String>,
    pub created_at: String,
    pub completed_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ImportPreview {
    pub file_path: String,
    pub valid: bool,
    pub manifest_version: Option<String>,
    pub bundle_type: Option<String>,
    pub source_patch_level: Option<String>,
    pub business_count: usize,
    pub category_count: usize,
    pub item_count: usize,
    pub stock_balance_count: usize,
    pub movement_count: usize,
    pub sale_count: usize,
    pub held_sale_count: usize,
    pub generated_at: Option<String>,
    pub warnings: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RecentActivity {
    pub id: String,
    pub level: String,
    pub category: String,
    pub message: String,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct KpiCard {
    pub id: String,
    pub label: String,
    pub value: String,
    pub note: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ModuleStatus {
    pub id: String,
    pub label: String,
    pub status: String,
    pub note: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DashboardShellData {
    pub hero_title: String,
    pub hero_body: String,
    pub kpis: Vec<KpiCard>,
    pub recent_activity: Vec<RecentActivity>,
    pub module_statuses: Vec<ModuleStatus>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct StorageStatus {
    pub data_dir: String,
    pub config_dir: String,
    pub log_dir: String,
    pub backup_dir: String,
    pub export_dir: String,
    pub database_path: String,
    pub database_exists: bool,
    pub backup_count: usize,
    pub export_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogCategory {
    pub id: String,
    pub business_id: String,
    pub name: String,
    pub code: String,
    pub parent_id: Option<String>,
    pub item_scope: String,
    pub sort_order: i64,
    pub notes: Option<String>,
    pub created_at: String,
    pub updated_at: String,
    pub archived_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogUnit {
    pub id: String,
    pub business_id: Option<String>,
    pub name: String,
    pub code: String,
    pub symbol: String,
    pub allow_fractional: bool,
    pub is_system: bool,
    pub updated_at: String,
    pub archived_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogItem {
    pub id: String,
    pub business_id: String,
    pub category_id: Option<String>,
    pub unit_id: Option<String>,
    pub tax_profile_id: Option<String>,
    pub item_kind: String,
    pub name: String,
    pub display_name: Option<String>,
    pub sku: Option<String>,
    pub primary_barcode: Option<String>,
    pub description: Option<String>,
    pub selling_price: f64,
    pub cost_price: f64,
    pub track_stock: bool,
    pub stock_quantity: f64,
    pub reorder_level: f64,
    pub image_path: Option<String>,
    pub is_active: bool,
    pub created_at: String,
    pub updated_at: String,
    pub archived_at: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogBarcode {
    pub id: String,
    pub item_id: String,
    pub barcode: String,
    pub label: Option<String>,
    pub is_primary: bool,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogItemView {
    pub item: CatalogItem,
    pub category_name: Option<String>,
    pub unit_code: Option<String>,
    pub tax_label: Option<String>,
    pub barcodes: Vec<CatalogBarcode>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogSummary {
    pub total_items: usize,
    pub active_items: usize,
    pub archived_items: usize,
    pub category_count: usize,
    pub menu_item_count: usize,
    pub stock_item_count: usize,
    pub service_item_count: usize,
    pub low_stock_candidates: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CatalogWorkspace {
    pub business_id: String,
    pub summary: CatalogSummary,
    pub categories: Vec<CatalogCategory>,
    pub units: Vec<CatalogUnit>,
    pub tax_profiles: Vec<TaxProfile>,
    pub items: Vec<CatalogItemView>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveCatalogCategoryInput {
    pub id: Option<String>,
    pub name: String,
    pub code: String,
    pub parent_id: Option<String>,
    pub item_scope: String,
    pub sort_order: i64,
    pub notes: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveCatalogUnitInput {
    pub id: Option<String>,
    pub name: String,
    pub code: String,
    pub symbol: String,
    pub allow_fractional: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveCatalogItemInput {
    pub id: Option<String>,
    pub category_id: Option<String>,
    pub unit_id: Option<String>,
    pub tax_profile_id: Option<String>,
    pub item_kind: String,
    pub name: String,
    pub display_name: Option<String>,
    pub sku: Option<String>,
    pub barcodes: Vec<String>,
    pub description: Option<String>,
    pub selling_price: f64,
    pub cost_price: f64,
    pub track_stock: bool,
    pub stock_quantity: f64,
    pub reorder_level: f64,
    pub image_path: Option<String>,
    pub is_active: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InventorySummary {
    pub total_tracked_items: usize,
    pub low_stock_items: usize,
    pub movement_count: usize,
    pub total_quantity_on_hand: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InventoryStockItem {
    pub item_id: String,
    pub item_name: String,
    pub item_kind: String,
    pub sku: Option<String>,
    pub category_name: Option<String>,
    pub unit_code: Option<String>,
    pub track_stock: bool,
    pub stock_quantity: f64,
    pub reorder_level: f64,
    pub low_stock: bool,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InventoryMovement {
    pub id: String,
    pub business_id: String,
    pub item_id: String,
    pub item_name: String,
    pub sku: Option<String>,
    pub unit_code: Option<String>,
    pub movement_type: String,
    pub quantity_delta: f64,
    pub quantity_after: f64,
    pub unit_cost: Option<f64>,
    pub note: Option<String>,
    pub occurred_at: String,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InventoryWorkspace {
    pub business_id: String,
    pub summary: InventorySummary,
    pub stock_items: Vec<InventoryStockItem>,
    pub recent_movements: Vec<InventoryMovement>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveInventoryMovementInput {
    pub item_id: String,
    pub movement_type: String,
    pub quantity: f64,
    pub unit_cost: Option<f64>,
    pub note: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveInventoryStockRuleInput {
    pub item_id: String,
    pub track_stock: bool,
    pub reorder_level: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSummary {
    pub completed_sale_count: usize,
    pub today_sale_count: usize,
    pub held_sale_count: usize,
    pub today_gross_sales: f64,
    pub today_collected_amount: f64,
    pub today_due_amount: f64,
    pub average_sale_value: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSellableItem {
    pub item_id: String,
    pub name: String,
    pub display_name: Option<String>,
    pub item_kind: String,
    pub category_name: Option<String>,
    pub unit_code: Option<String>,
    pub allow_fractional: bool,
    pub sku: Option<String>,
    pub primary_barcode: Option<String>,
    pub selling_price: f64,
    pub track_stock: bool,
    pub on_hand_quantity: f64,
    pub tax_label: Option<String>,
    pub tax_rate: f64,
    pub prices_include_tax: bool,
    pub is_available: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosCartLineInput {
    pub item_id: String,
    pub quantity: f64,
    pub unit_price: Option<f64>,
    pub discount_amount: f64,
    pub notes: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosPaymentEntryInput {
    pub payment_mode: String,
    pub amount: f64,
    pub reference_value: Option<String>,
    pub notes: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SavePosHoldInput {
    pub id: Option<String>,
    pub hold_label: String,
    pub notes: Option<String>,
    pub cart_lines: Vec<PosCartLineInput>,
    pub cart_discount_amount: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CompletePosSaleInput {
    pub hold_id: Option<String>,
    pub notes: Option<String>,
    pub cart_lines: Vec<PosCartLineInput>,
    pub cart_discount_amount: f64,
    pub payments: Vec<PosPaymentEntryInput>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosHoldSummary {
    pub id: String,
    pub business_id: String,
    pub hold_code: String,
    pub hold_label: String,
    pub item_count: usize,
    pub subtotal_amount: f64,
    pub discount_amount: f64,
    pub tax_amount: f64,
    pub total_amount: f64,
    pub notes: Option<String>,
    pub cart_lines: Vec<PosCartLineInput>,
    pub cart_discount_amount: f64,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSaleRecord {
    pub id: String,
    pub business_id: String,
    pub register_session_id: Option<String>,
    pub sale_number: String,
    pub sale_status: String,
    pub payment_status: String,
    pub currency_code: String,
    pub subtotal_amount: f64,
    pub discount_amount: f64,
    pub tax_amount: f64,
    pub total_amount: f64,
    pub amount_paid: f64,
    pub balance_due: f64,
    pub item_count: usize,
    pub notes: Option<String>,
    pub completed_at: String,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSaleLine {
    pub id: String,
    pub sale_id: String,
    pub item_id: Option<String>,
    pub item_name: String,
    pub item_kind: String,
    pub category_name: Option<String>,
    pub sku: Option<String>,
    pub primary_barcode: Option<String>,
    pub unit_code: Option<String>,
    pub tax_label: Option<String>,
    pub tax_rate: f64,
    pub prices_include_tax: bool,
    pub quantity: f64,
    pub unit_price: f64,
    pub gross_amount: f64,
    pub discount_amount: f64,
    pub net_amount: f64,
    pub tax_amount: f64,
    pub total_amount: f64,
    pub notes: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSalePayment {
    pub id: String,
    pub sale_id: String,
    pub payment_mode: String,
    pub amount: f64,
    pub reference_value: Option<String>,
    pub notes: Option<String>,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosSaleDetail {
    pub sale: PosSaleRecord,
    pub lines: Vec<PosSaleLine>,
    pub payments: Vec<PosSalePayment>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PosWorkspace {
    pub business_id: String,
    pub summary: PosSummary,
    pub register_label: Option<String>,
    pub sellable_items: Vec<PosSellableItem>,
    pub held_sales: Vec<PosHoldSummary>,
    pub recent_sales: Vec<PosSaleRecord>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RegisterSession {
    pub id: String,
    pub business_id: String,
    pub label: String,
    pub status: String,
    pub opened_at: String,
    pub closed_at: Option<String>,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AppBootstrap {
    pub app_info: AppInfo,
    pub active_business: BusinessProfile,
    pub business_settings: BusinessSettings,
    pub active_tax_profile: TaxProfile,
    pub active_receipt_profile: ReceiptProfile,
    pub active_module_flags: ModuleFlags,
    pub active_sequences: Vec<SequenceCounter>,
    pub businesses: Vec<BusinessProfile>,
    pub business_workspaces: Vec<BusinessWorkspaceSummary>,
    pub patch_history: Vec<PatchRecord>,
    pub backups: Vec<BackupRecord>,
    pub storage: StorageStatus,
    pub catalog_summary: CatalogSummary,
    pub inventory_summary: InventorySummary,
    pub pos_summary: PosSummary,
    pub dashboard: DashboardShellData,
}

```

## files/src-tauri/src/lib.rs

```rust
mod commands;
mod core;
mod domain;

pub fn run() {
    tauri::Builder::default()
        .setup(|app| {
            let handle = app.handle().clone();
            core::db::initialize(&handle).expect("failed to initialize local workspace core");
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::bootstrap::bootstrap_app,
            commands::business::save_business_profile,
            commands::business::create_business_workspace,
            commands::business::switch_active_business,
            commands::settings::save_workspace_configuration,
            commands::catalog::load_catalog_workspace,
            commands::catalog::save_catalog_category,
            commands::catalog::save_catalog_unit,
            commands::catalog::save_catalog_item,
            commands::catalog::set_catalog_item_archived,
            commands::inventory::load_inventory_workspace,
            commands::inventory::record_inventory_movement,
            commands::inventory::save_inventory_stock_rule,
            commands::pos::load_pos_workspace,
            commands::pos::save_pos_hold,
            commands::pos::delete_pos_hold,
            commands::pos::complete_pos_sale,
            commands::data_center::create_backup_snapshot,
            commands::data_center::export_foundation_snapshot,
            commands::data_center::preview_import_bundle
        ])
        .run(tauri::generate_context!())
        .expect("error while running local business manager");
}

```

## files/src-tauri/tauri.conf.json

```json
{
  "$schema": "https://schema.tauri.app/config/2",
  "productName": "Local Business Manager",
  "version": "0.5.0",
  "identifier": "com.localfirst.businessmanager",
  "build": {
    "beforeBuildCommand": "npm run build",
    "beforeDevCommand": "npm run dev",
    "devUrl": "http://localhost:5173",
    "frontendDist": "../dist"
  },
  "app": {
    "windows": [
      {
        "label": "main",
        "title": "Local Business Manager",
        "width": 1380,
        "height": 860,
        "minWidth": 1100,
        "minHeight": 720,
        "resizable": true
      }
    ],
    "security": {
      "csp": null
    }
  },
  "bundle": {
    "active": false
  }
}

```

## migrations/MIGRATION_NOTES.md

```md
# Migration Notes - Patch 5

Schema version moves from `4` to `5`.

## Migration 005

Creates the POS foundation tables:

- `register_sessions`
- `sales`
- `sale_lines`
- `sale_payments`
- `sale_holds`

It also adds lookup indexes for sale number, completed time, line lookups, payment lookups, and held-cart lookups.

## Business workspace backfill behavior

At startup, each business receives POS support foundation if missing:

- sale sequence counter
- hold sequence counter
- default register session (`register-main:<business_id>`)

## Demo seed behavior

If the demo workspace exists and has no POS data yet, seed logic can create:

- one held cart
- one completed demo sale

## Destructive changes

This migration is additive only. No existing Patch 4 tables are dropped or renamed.

## Operational recommendation

Create a local backup before opening a live database with Patch 5 for the first time.

```

## patch-manifest.json

```json
{
  "patch_id": "P005_pos_checkout_core",
  "patch_name": "POS Checkout Core",
  "base_version": "0.4.0",
  "target_version": "0.5.0",
  "description": "Adds local POS checkout with cart, held sales, completed sales, payment capture, receipt-ready sale history, and stock deduction through the existing inventory ledger on top of Patch 4.",
  "dependencies": [
    "P004_inventory_ledger_core"
  ],
  "safe_on_empty_project": false,
  "migration_required": true,
  "rollback_supported": true,
  "files_root": "files",
  "files_added": [
    "scripts/validate-patch5.mjs",
    "src/modules/pos/PosPage.tsx",
    "src-tauri/src/commands/pos.rs",
    "src-tauri/src/core/pos.rs",
    "src-tauri/src/core/migrations/005_pos_checkout_core.sql"
  ],
  "files_updated": [
    "package.json",
    "src/app/AppProvider.tsx",
    "src/modules/dashboard/DashboardPage.tsx",
    "src/modules/data-center/DataCenterPage.tsx",
    "src/modules/shell/AppShell.tsx",
    "src/shared/api.ts",
    "src/shared/types.ts",
    "src/shared/utils.ts",
    "src/styles.css",
    "src-tauri/Cargo.toml",
    "src-tauri/tauri.conf.json",
    "src-tauri/src/commands/bootstrap.rs",
    "src-tauri/src/commands/data_center.rs",
    "src-tauri/src/commands/mod.rs",
    "src-tauri/src/core/db.rs",
    "src-tauri/src/core/migrations.rs",
    "src-tauri/src/core/mod.rs",
    "src-tauri/src/core/patching.rs",
    "src-tauri/src/core/seed.rs",
    "src-tauri/src/domain/bootstrap.rs",
    "src-tauri/src/domain/models.rs",
    "src-tauri/src/lib.rs"
  ],
  "files_deleted": [],
  "post_apply_steps": [
    "cd <target>",
    "npm install",
    "npm run validate:patch5",
    "npm run tauri dev"
  ]
}

```

## rollback.md

```md
# Rollback Notes - Patch 5

## Code rollback

1. Restore overwritten files from:
   - `.patch-backups/P005_pos_checkout_core/`
2. Remove any newly added Patch 5 files if you are fully reverting the code layer.
3. Remove Patch 5 entries from `.patch-meta/` only if you are performing a deliberate manual rollback.

## Database rollback

Migration 005 adds new tables and runtime startup support records.

If the patched app has already opened a live database, the safest rollback is:
- restore the SQLite database from a pre-Patch-5 backup snapshot
- then restore the Patch 4 codebase

Rolling back only the code without restoring the database can leave extra POS tables present in the SQLite file.

```

## validate.md

```md
# Validation Checklist - Patch 5

- [ ] Apply Patch 5 on top of a Patch 4 project
- [ ] `npm install` completes
- [ ] `npm run validate:patch5` passes
- [ ] `npm run tauri dev` opens the desktop shell
- [ ] POS appears in the left navigation
- [ ] POS page loads sellable items from the catalog
- [ ] Adding items updates the cart totals correctly
- [ ] Held cart save / resume / delete works locally
- [ ] Completing a sale creates sale header, lines, and payment rows
- [ ] Selling a tracked stock item decreases on-hand quantity
- [ ] Inventory history shows `pos_sale` movement rows for completed sales
- [ ] Data export includes sales, payments, held carts, and register sessions
- [ ] Import preview shows `stockBalanceCount`, `saleCount`, and `heldSaleCount`

```
